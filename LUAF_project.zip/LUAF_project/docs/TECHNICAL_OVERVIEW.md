# Technical overview

LUAF-SM2-FL studies limited-use anonymous admission for UAV federated edge intelligence. The source package separates federated-learning computation, protocol/state modeling, a persistent service prototype, and symbolic protocol models. Their assumptions differ and should be assessed component by component.

## Federated-learning and protocol computation

`simulation/src/config.py` defines `SimConfig`. `fl_core.py` implements the local models; `fl_simulator.py` coordinates client selection, local optimization, and aggregation. The implementation uses Python, NumPy and scikit-learn. `data_loader.py` prepares disjoint training/validation/test splits and fits feature scaling on training rows. Client partitioning supports observed UAV grouping, IID allocation and Dirichlet allocation; the default is `partition_mode="observed"`. `reproducibility.py` derives separate deterministic random streams from a root seed for splitting, model initialization, client selection, local batches, attacks, mobility and protocol jitter.

`luaf_protocol.py` models credential admission, nullifier use, revocation and update handling. `crypto_sim.py` provides modeled protocol cost. `crypto_backend/` separates the simulated interface from the optional Tongsuo CLI adapter. The Tongsuo adapter wires SM3 digest only; SM2 signing/encryption, SM4-GCM and a complete SM2-AKE explicitly report unsupported capabilities. Presence of this adapter does not establish implementation of the complete cryptographic protocol.

The `experiments/` modules are the project's computation entry points for FL utility, protocol overhead, nullifier synchronization, revocation, linkability, mobility, poisoning/audit, ablation and model comparison. They are retained as implementation code rather than saved execution records. FL computation can use an external prepared dataset. Protocol overhead and several state/network comparisons are parameterized models. `exp_08_ablation.py` contains a fixed illustrative effect table; its values are not measurements produced by feature-flag execution.

## Optional etcd state adapter

`simulation/src/state_backend/` defines the memory and etcd backends. The etcd backend uses compare-and-swap and leases and fails explicitly when etcd is unavailable. The optional container files under `simulation/prototype/state_service/` preserve the original Docker build context. That HTTP wrapper exposes a health endpoint and revocation-version status; the backend methods reside in the Python adapter. This component is separate from the Pi service below.

## Persistent Pi service

`hardware/app/main.py` exposes the state-service operations. `models.py` defines request schemas, `contract.py` defines canonical identity and message integrity, `database.py` handles SQLite transactions and event projection, and `schema.sql` defines the persistent tables. `hardware/client/api.py` implements HTTP requests and response handling.

The service tracks nullifier state with an owner/session, authorization identity, generation and lease. Operations establish a `commit_record`, followed by `update_admission` and `contribution`. Durable parent IDs connect these effects. Immutable identity and update-digest fields are checked against the parent record; repeated valid operations reuse the existing record ID. Expired generations and stale sessions cannot modify a replacement transaction. State changes and event-outbox records are written transactionally, with a JSONL projection of committed events.

The service distinguishes B2_GENERIC_RCA, B2A_RCA_AID and LUAF_C1C2_PROTO. B2A and LUAF use the same C1/C2 protection in this implementation. The generic B2 comparison intentionally has a weaker cross-instance update-binding guard; it is a comparison variant rather than a recommended deployment setting.

This is a single-service HTTP/SQLite hybrid prototype. HMAC-SHA256 authenticates controlled calls; it is separate from SM2 authentication or an anonymous-credential implementation. Request credential fields are protocol placeholders. The component does not implement SM2/SM4, anonymous credential issuance, C_open, C3, FL training, multi-device Edge deployment or power-failure recovery. Its lease/generation behavior is an implementation of the state protocol, not a proof of production deployment guarantees.

## Record-binding reference model

`record_binding/common.py` supplies canonical encoding, stable IDs and an ideal-signature abstraction. `state_sim.py` contains `StateSimulator`; `integrated_model.py` contains `IntegratedAdapter`; `independent_checker.py` reconstructs record relations and duplicate effects independently. The checker reads records supplied by its caller and is retained as a technical verification component. Standalone workload runners and saved executions are omitted.

The reference model connects consumption and commit records to update validation, update admission and contribution. It also models quarantine, evidence, warrant, opening and receipt relations. These are symbolic records and idealized authorization objects. Signature validity and signer authority are separate questions; update-submission signer authority is not fully specified. C3/opening objects in this model are synthetic and do not constitute a real credential-opening implementation. Details are in [RECORD_CONTRACT.md](RECORD_CONTRACT.md).

## Symbolic models

The Tamarin and Scyther files represent abstract protocol behavior. They do not execute the Python implementation or measure its cost. The seven Tamarin models isolate credential workflow, binding, audit, state synchronization, identifier unlinkability, a Fixed-Q negative case and an optional DH/signature AKE abstraction. Their assumptions and interpretation are stated in [FORMAL_MODELS.md](FORMAL_MODELS.md).
