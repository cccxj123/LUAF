# Record-binding contract

This contract summarizes the canonical record-binding reference implementation in `record_binding/`. The model uses ideal signatures and synthetic authorization/opening objects.

## Trusted parents and immutable inheritance

Contribution admission accepts an `update_admission_id` that resolves to exactly one durable admission. A validation ID, quarantine ID, unknown or missing ID is not an admission parent. The admission contains its validation/commit/consumption parents, authorization reference, checkpoint, update digest, nullifier, consumption domain, credential instance, request/session/owner, generation, committed context and logical timestamp.

The contribution derives immutable fields from that trusted admission. If the caller supplies those fields, they must match the parent. Changing child authorization or checkpoint cannot create a new contribution key. A parent timestamp may equal but cannot follow its child's timestamp.

The uniqueness key is `(checkpoint, authorization_ref)` as derived from the admission. Repeating the same valid parent returns its existing contribution ID with `IDEMPOTENT` and creates no additional durable effect. A distinct admission conflicting on that key is rejected. These shared rules apply to every `IntegratedAdapter` variant.

## Record chain

```text
Consumption → CommitRecord → UpdateValidation → UpdateAdmission → Contribution
                                  ↓
                              Quarantine → Evidence → Warrant → Opening → Receipt
```

Every child resolves its declared parents and inherits the applicable authorization, identity, context and digest fields. Evidence and quarantine must share the associated validation/commit relation; opening and receipt preserve the evidence/warrant relation and scope. IDs are unique within each record type and cannot collide across record types.

The independent checker validates schemas, parents, inherited fields, causal order and correspondence between durable records and effective events. Equal timestamps use event order when records share a stream; atomic co-events may share a sequence. Direct parent IDs establish cross-stream causality. Idempotent events do not add durable effects. Duplicate consumption uses `(consumption_domain, NF)`; multiple contributions per admission and receipts per opening are duplicate effects.

The checker reports `EVIDENCE_STRUCTURE_VALID`, `RELATION_VIOLATIONS`, `DUPLICATE_EFFECTS` and `EXPECTED_DIAGNOSTIC_MATCH` separately. Matching a declared diagnostic does not make the corresponding safety property true.

## Specification distinctions

Generation is a shared state-operation convention or specification supplement. `B2_CURRENT_COMMON_GUARDS` denotes the historical authorization/NF/credential-instance/digest guard set. B2A and LUAF share C1/C2 behavior. Ideal signature validity does not establish that a signer is authorized to submit an update; that authority is unspecified in the reference model. Synthetic C3 records do not implement credential opening.
