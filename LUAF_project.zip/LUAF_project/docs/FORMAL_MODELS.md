# Formal-model scope

The files in `formal/tamarin/` are standalone Tamarin models. They require an external Tamarin installation. `formal/scyther/luaf_sm2_fl.spdl` is the separate Scyther protocol model and requires Scyther. Proof logs, tool binaries and execution wrappers are omitted from this source package.

| Tamarin model | Scope |
|---|---|
| `01_LUAF_workflow_fast.spthy` | Bounded L=2 credential slots; slot/nullifier/update at-most-once properties, revocation ordering and aggregation reachability |
| `02_LUAF_binding_fast.spthy` | Transcript/KDF, confirmation, ciphertext and associated-data binding after an ideal authenticated AKE supplies a fresh base key |
| `03_LUAF_audit_fast.spthy` | Evidence, authorization, conditional opening, receipts and non-frameability |
| `04_LUAF_state_fast.spthy` | Local-cache duplicate spending, atomic pending locks, stale revocation views and repaired synchronized state |
| `05_LUAF_unlinkability_fast.spthy` | Protocol-identifier unlinkability with matched message shape and schedule |
| `06_LUAF_fixed_Q_attack_fast.spthy` | Negative case for distinguishing reused Q values |
| `07_LUAF_sm2_dh_optional.spthy` | Isolated minimal DH/signature AKE abstraction |

Existential attack lemmas in Model 04 establish an attack trace when satisfied; their success must not be described as successful defense. Model 06 is a negative ablation whose distinguishing trace demonstrates the consequence of reusing Q. Model 05 covers the protocol-identifier abstraction, not timing, packet size, IP/RF, participation frequency or mobility metadata. Model 07 is a symbolic structural check rather than a proof of an SM2 standard or cryptographic library implementation.

These models do not verify concrete cryptographic-library code, random-number generation, elliptic-curve implementation, side channels, memory safety, real-time performance, physical identifiers, UAV trajectories or federated-learning robustness. This source-only package makes no new proof-execution claim.
