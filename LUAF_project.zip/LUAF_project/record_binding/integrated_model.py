"""Small CommitRecord -> update -> conditional-accountability adapter.

The adapter deliberately has no second NF state machine.  A copied
``StateSimulator`` is run first; this module only consumes its durable
``commit_records`` and ledgers.  The accountability objects are synthetic
test-domain records signed by the existing ideal-signature abstraction.
"""

from __future__ import annotations

import copy
from collections import Counter
from typing import Any

from common import IdealSignatureOracle, canonical_json, stable_id


CORE_VARIANTS = ("B2_CURRENT_COMMON_GUARDS", "B2A_RECORD_CONTRACT", "LUAF_INTEGRATED")
ABLATIONS = ("A1_COMMIT_UPDATE_BINDING_OFF", "A2_CONFIRM_BINDING_OFF", "A3_ACCOUNTABILITY_BINDING_OFF")


def _without_auth(record: dict[str, Any]) -> dict[str, Any]:
    return {k: v for k, v in record.items() if k not in {"signer", "signature"}}


class IntegratedAdapter:
    def __init__(
        self,
        *,
        variant: str,
        run_id: str,
        seed: int,
        state: Any,
        auth_enabled: bool = True,
        confirm_binding_enabled: bool = True,
        accountability_binding_enabled: bool = True,
    ) -> None:
        if variant not in CORE_VARIANTS and variant not in ABLATIONS:
            raise ValueError(f"unknown integrated variant: {variant}")
        self.variant = variant
        self.run_id = run_id
        self.seed = seed
        self.state = state
        self.oracle = IdealSignatureOracle(seed)
        self.auth_enabled = auth_enabled
        self.confirm_binding_enabled = confirm_binding_enabled
        self.accountability_binding_enabled = accountability_binding_enabled
        self.events: list[dict[str, Any]] = []
        self.validations: dict[str, dict[str, Any]] = {}
        self.admissions: dict[str, dict[str, Any]] = {}
        self.contributions: dict[str, dict[str, Any]] = {}
        self.quarantines: dict[str, dict[str, Any]] = {}
        self.evidence: dict[str, dict[str, Any]] = {}
        self.warrants: dict[str, dict[str, Any]] = {}
        self.opening_objects: dict[str, dict[str, Any]] = {}
        self.receipts: dict[str, dict[str, Any]] = {}
        self._admission_by_domain_nf: dict[tuple[str, str], str] = {}
        self._last_logged_counts = self._counts()

    @property
    def strict_contract(self) -> bool:
        return self.variant in {"B2A_RECORD_CONTRACT", "LUAF_INTEGRATED"} or self.variant.startswith("A")

    @property
    def conditional_accountability(self) -> bool:
        return self.variant == "LUAF_INTEGRATED" or self.variant == "A3_ACCOUNTABILITY_BINDING_OFF"

    def _counts(self) -> dict[str, int]:
        return {
            "validation_count": len(self.validations),
            "admission_count": len(self.admissions),
            "contribution_count": len(self.contributions),
            "quarantine_count": len(self.quarantines),
            "evidence_count": len(self.evidence),
            "warrant_count": len(self.warrants),
            "opening_object_count": len(self.opening_objects),
            "receipt_count": len(self.receipts),
        }

    def _log(self, *, op: str, sim_time: float, result: str, reason: str, message: dict[str, Any] | None = None, **extra: Any) -> dict[str, Any]:
        before = copy.deepcopy(self._last_logged_counts)
        after = self._counts()
        row = {
            "event_seq": len(self.events) + 1,
            "event_id": f"{self.run_id}:integrated:{len(self.events) + 1}",
            "run_id": self.run_id,
            "variant": self.variant,
            "sim_time": sim_time,
            "event_type": op,
            "result": result,
            "reason": reason,
            "message": copy.deepcopy(message or {}),
            "state_before": before,
            "state_after": after,
            "parent_event_id": extra.pop("parent_event_id", ""),
            **extra,
        }
        self.events.append(row)
        self._last_logged_counts = copy.deepcopy(after)
        return row

    def _verify(self, message: dict[str, Any], actor: str | None = None) -> bool:
        if actor is not None and message.get("signer") != actor:
            return False
        return self.oracle.verify(
            str(message.get("signer", "")),
            _without_auth(message),
            str(message.get("signature", "")),
        )

    def _sign(self, actor: str, fields: dict[str, Any]) -> dict[str, Any]:
        return {**fields, "signer": actor, "signature": self.oracle.sign(actor, fields)}

    def _commit_for(self, message: dict[str, Any]) -> dict[str, Any] | None:
        tx = str(message.get("request_id", ""))
        commit = self.state.commit_records.get(tx)
        if not commit or str(message.get("commit_record_id", "")) != str(commit.get("record_id", "")):
            return None
        return commit

    def _binding_mismatches(self, message: dict[str, Any], commit: dict[str, Any]) -> list[str]:
        expected = {
            "authorization_ref": commit["authorization_ref"],
            "nf": commit["nf"],
            "consumption_domain": commit["consumption_domain"],
            "credential_instance": commit["credential_instance"],
            "request_id": commit["request_id"],
            "sid": commit["sid"],
            "owner": commit["owner"],
            "generation": commit["generation"],
            "committed_context": commit["committed_context"],
            "update_digest": commit["update_digest"],
            "checkpoint": commit["checkpoint"],
        }
        if not self.strict_contract:
            expected = {k: expected[k] for k in ("authorization_ref", "nf", "credential_instance", "update_digest")}
        return [key for key, value in expected.items() if message.get(key) != value]

    def _all_binding_mismatches(self, message: dict[str, Any], commit: dict[str, Any]) -> list[str]:
        expected = {
            "authorization_ref": commit["authorization_ref"],
            "nf": commit["nf"],
            "consumption_domain": commit["consumption_domain"],
            "credential_instance": commit["credential_instance"],
            "request_id": commit["request_id"],
            "sid": commit["sid"],
            "owner": commit["owner"],
            "generation": commit["generation"],
            "committed_context": commit["committed_context"],
            "update_digest": commit["update_digest"],
            "checkpoint": commit["checkpoint"],
        }
        return [key for key, value in expected.items() if message.get(key) != value]

    def submit_update(self, message: dict[str, Any], *, sim_time: float, abnormal: bool = False, test_case: str = "") -> dict[str, Any]:
        if not self._verify(message):
            return self._log(op="UpdateValidate", sim_time=sim_time, result="REJECTED", reason="invalid_origin_or_integrity", message=message, test_case=test_case, illegal_relation=False)
        commit = self._commit_for(message)
        if commit is None:
            return self._log(op="UpdateValidate", sim_time=sim_time, result="REJECTED", reason="missing_commit_record_parent", message=message, test_case=test_case, illegal_relation=False)
        mismatches = self._binding_mismatches(message, commit)
        all_mismatches = self._all_binding_mismatches(message, commit)
        if mismatches and self.auth_enabled:
            return self._log(op="UpdateValidate", sim_time=sim_time, result="REJECTED", reason="record_contract_binding_mismatch", message=message, test_case=test_case, mismatches=mismatches, illegal_relation=False)
        validation_id = stable_id("update-validation", self.run_id, commit["record_id"], message.get("update_digest", ""), message.get("checkpoint", ""))
        validation = {
            "update_validation_id": validation_id,
            "commit_record_id": commit["record_id"],
            "consumption_record_id": commit["consumption_record_id"],
            "authorization_ref": message["authorization_ref"],
            "nf": message["nf"],
            "consumption_domain": message["consumption_domain"],
            "request_id": message["request_id"],
            "sid": message["sid"],
            "owner": message["owner"],
            "generation": message["generation"],
            "committed_context": message["committed_context"],
            "update_digest": message["update_digest"],
            "checkpoint": message["checkpoint"],
            "sim_time": sim_time,
            "abnormal": abnormal,
        }
        existing = self.validations.get(validation_id)
        if existing is None:
            self.validations[validation_id] = validation
        if abnormal:
            if not self.conditional_accountability:
                return self._log(op="Accountability", sim_time=sim_time, result="NOT_PROVIDED", reason="conditional_accountability_not_in_variant", message=message, test_case=test_case, update_validation_id=validation_id, illegal_relation=False)
            quarantine_id = stable_id("quarantine", self.run_id, validation_id)
            self.quarantines.setdefault(quarantine_id, {"quarantine_id": quarantine_id, "update_validation_id": validation_id, "commit_record_id": commit["record_id"], "sim_time": sim_time})
            return self._log(op="Quarantine", sim_time=sim_time, result="ACCEPTED", reason="abnormal_update_isolated", message=message, test_case=test_case, update_validation_id=validation_id, quarantine_id=quarantine_id, illegal_relation=bool(mismatches))
        key = (str(message["consumption_domain"]), str(message["nf"]))
        admission_id = stable_id("update-admission", self.run_id, *key)
        prior = self._admission_by_domain_nf.get(key)
        if prior is not None:
            old = self.admissions[prior]
            if old["update_digest"] == message["update_digest"] and old["commit_record_id"] == commit["record_id"]:
                return self._log(op="UpdateAdmit", sim_time=sim_time, result="IDEMPOTENT", reason="update_replay_deduplicated", message=message, test_case=test_case, update_validation_id=old["update_validation_id"], update_admission_id=prior, illegal_relation=bool(all_mismatches))
            return self._log(op="UpdateAdmit", sim_time=sim_time, result="REJECTED", reason="conflicting_update_for_consumption_domain_nf", message=message, test_case=test_case, update_validation_id=validation_id, illegal_relation=False)
        admission = {
            "update_admission_id": admission_id,
            "update_validation_id": validation_id,
            "commit_record_id": commit["record_id"],
            "consumption_record_id": commit["consumption_record_id"],
            "authorization_ref": message["authorization_ref"],
            "nf": message["nf"],
            "consumption_domain": message["consumption_domain"],
            "credential_instance": message["credential_instance"],
            "request_id": message["request_id"],
            "sid": message["sid"],
            "owner": message["owner"],
            "generation": message["generation"],
            "committed_context": message["committed_context"],
            "update_digest": message["update_digest"],
            "checkpoint": message["checkpoint"],
            "sim_time": sim_time,
        }
        self.admissions[admission_id] = admission
        self._admission_by_domain_nf[key] = admission_id
        return self._log(op="UpdateAdmit", sim_time=sim_time, result="ACCEPTED", reason="update_admitted", message=message, test_case=test_case, update_validation_id=validation_id, update_admission_id=admission_id, illegal_relation=bool(all_mismatches))

    def contribute(self, message: dict[str, Any], *, sim_time: float, test_case: str = "") -> dict[str, Any]:
        # The admission is the only trusted parent for a contribution.  Do not
        # construct a new contribution key from child-supplied checkpoint or
        # authorization fields: those fields are immutable parent attributes.
        raw_admission_id = message.get("update_admission_id")
        if not isinstance(raw_admission_id, str) or not raw_admission_id:
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="update_admission_parent_required", message=message, test_case=test_case, illegal_relation=False)
        admission_id = raw_admission_id
        admission = self.admissions.get(admission_id)
        if not isinstance(admission, dict):
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="update_admission_parent_required", message=message, test_case=test_case, illegal_relation=False)
        required_parent_fields = (
            "update_admission_id", "update_validation_id", "commit_record_id",
            "authorization_ref", "checkpoint", "update_digest", "nf",
            "consumption_domain", "consumption_record_id", "credential_instance",
            "request_id", "sid", "owner", "generation", "committed_context",
            "sim_time",
        )
        if any(field not in admission for field in required_parent_fields):
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="malformed_update_admission_parent", message=message, test_case=test_case, illegal_relation=False)
        string_parent_fields = tuple(field for field in required_parent_fields if field not in {"generation", "sim_time"})
        if any(not isinstance(admission[field], str) or not admission[field] for field in string_parent_fields):
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="malformed_update_admission_parent", message=message, test_case=test_case, illegal_relation=False)
        if isinstance(admission["generation"], bool) or not isinstance(admission["generation"], int):
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="malformed_update_admission_parent", message=message, test_case=test_case, illegal_relation=False)
        if isinstance(admission["sim_time"], bool) or not isinstance(admission["sim_time"], (int, float)) or admission["sim_time"] > sim_time:
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="malformed_update_admission_parent", message=message, test_case=test_case, illegal_relation=False)
        if admission["update_admission_id"] != admission_id:
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="malformed_update_admission_parent", message=message, test_case=test_case, illegal_relation=False)
        inherited_fields = tuple(field for field in required_parent_fields if field not in {"update_admission_id", "sim_time"})
        expected = {field: admission[field] for field in inherited_fields}
        # All supplied immutable fields must agree with the trusted parent.
        # Omitted child fields are derived below rather than guessed.
        supplied_mismatch = [field for field, value in expected.items() if field in message and message[field] != value]
        if supplied_mismatch:
            return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="contribution_parent_binding_mismatch", message=message, test_case=test_case, mismatches=supplied_mismatch, illegal_relation=False)
        key = (str(expected["checkpoint"]), str(expected["authorization_ref"]))
        for old in self.contributions.values():
            if (old["checkpoint"], old["authorization_ref"]) == key:
                if old["update_admission_id"] == admission_id:
                    return self._log(op="Contribution", sim_time=sim_time, result="IDEMPOTENT", reason="contribution_replay_deduplicated", message=message, test_case=test_case, contribution_id=old["contribution_id"], illegal_relation=False)
                return self._log(op="Contribution", sim_time=sim_time, result="REJECTED", reason="conflicting_contribution_key", message=message, test_case=test_case, illegal_relation=False)
        contribution_id = stable_id("contribution", self.run_id, key[0], key[1])
        self.contributions[contribution_id] = {
            "contribution_id": contribution_id,
            "update_admission_id": admission_id,
            "update_validation_id": expected["update_validation_id"],
            "commit_record_id": expected["commit_record_id"],
            "consumption_record_id": expected["consumption_record_id"],
            "credential_instance": expected["credential_instance"],
            "authorization_ref": expected["authorization_ref"],
            "checkpoint": expected["checkpoint"],
            "update_digest": expected["update_digest"],
            "nf": expected["nf"],
            "consumption_domain": expected["consumption_domain"],
            "request_id": expected["request_id"],
            "sid": expected["sid"],
            "owner": expected["owner"],
            "generation": expected["generation"],
            "committed_context": expected["committed_context"],
            "sim_time": sim_time,
        }
        return self._log(op="Contribution", sim_time=sim_time, result="ACCEPTED", reason="contribution_recorded", message=message, test_case=test_case, contribution_id=contribution_id, illegal_relation=False)

    def issue_evidence(self, *, validation_id: str, quarantine_id: str, case_id: str, opening_object_id: str, sim_time: float, test_case: str) -> dict[str, Any]:
        validation = self.validations[validation_id]
        evidence_id = stable_id("evidence", self.run_id, validation_id, case_id)
        fields = {
            "kind": "Evidence",
            "evidence_id": evidence_id,
            "update_validation_id": validation_id,
            "quarantine_id": quarantine_id,
            "commit_record_id": validation["commit_record_id"],
            "authorization_ref": validation["authorization_ref"],
            "case_id": case_id,
            "opening_object_id": opening_object_id,
            "scope": "synthetic-accountability-open",
            "subject_ref": "synthetic-subject-001",
        }
        evidence = self._sign("auditor", fields)
        self.evidence[evidence_id] = {**fields, "sim_time": sim_time, "signature": evidence["signature"], "signer": evidence["signer"]}
        return self._log(op="Evidence", sim_time=sim_time, result="ACCEPTED", reason="evidence_issued", message=evidence, test_case=test_case, evidence_id=evidence_id, update_validation_id=validation_id, quarantine_id=quarantine_id, illegal_relation=False)

    def issue_warrant(self, *, evidence: dict[str, Any], case_id: str, opening_object_id: str, sim_time: float, test_case: str, valid_until: float = 100.0) -> dict[str, Any]:
        warrant_id = stable_id("warrant", self.run_id, evidence.get("evidence_id", ""), case_id, opening_object_id)
        fields = {
            "kind": "Warrant",
            "warrant_id": warrant_id,
            "evidence_id": evidence.get("evidence_id", ""),
            "commit_record_id": evidence.get("commit_record_id", ""),
            "authorization_ref": evidence.get("authorization_ref", ""),
            "case_id": case_id,
            "opening_object_id": opening_object_id,
            "scope": "synthetic-accountability-open",
            "valid_from": 0.0,
            "valid_until": valid_until,
        }
        warrant = self._sign("authority", fields)
        self.warrants[warrant_id] = {**fields, "sim_time": sim_time, "signature": warrant["signature"], "signer": warrant["signer"]}
        return self._log(op="Warrant", sim_time=sim_time, result="ACCEPTED", reason="warrant_issued", message=warrant, test_case=test_case, warrant_id=warrant_id, evidence_id=evidence.get("evidence_id", ""), illegal_relation=False)

    def open_with_warrant(self, *, evidence: dict[str, Any], warrant: dict[str, Any], sim_time: float, test_case: str) -> dict[str, Any]:
        if not self._verify(evidence, "auditor") or not self._verify(warrant, "authority"):
            return self._log(op="Open", sim_time=sim_time, result="REJECTED", reason="invalid_evidence_or_warrant_origin", message={"evidence": evidence, "warrant": warrant}, test_case=test_case, illegal_relation=False)
        evidence_id = str(evidence.get("evidence_id", ""))
        warrant_id = str(warrant.get("warrant_id", ""))
        parent_ok = evidence_id in self.evidence and warrant_id in self.warrants and str(warrant.get("evidence_id", "")) == evidence_id
        scope_ok = evidence.get("scope") == warrant.get("scope") == "synthetic-accountability-open"
        validity_ok = float(warrant.get("valid_from", 1e9)) <= sim_time <= float(warrant.get("valid_until", -1))
        relation_ok = (
            parent_ok
            and evidence.get("commit_record_id") == warrant.get("commit_record_id")
            and evidence.get("authorization_ref") == warrant.get("authorization_ref")
            and evidence.get("case_id") == warrant.get("case_id")
            and evidence.get("opening_object_id") == warrant.get("opening_object_id")
        )
        if not (parent_ok and scope_ok and validity_ok and (relation_ok or not self.accountability_binding_enabled)):
            return self._log(op="Open", sim_time=sim_time, result="REJECTED", reason="evidence_warrant_open_binding_mismatch", message={"evidence": evidence, "warrant": warrant}, test_case=test_case, illegal_relation=False, parent_ok=parent_ok, scope_ok=scope_ok, validity_ok=validity_ok, relation_ok=relation_ok)
        opening_object_id = str(evidence.get("opening_object_id", ""))
        self.opening_objects[opening_object_id] = {
            "opening_object_id": opening_object_id,
            "evidence_id": evidence_id,
            "warrant_id": warrant_id,
            "authorization_ref": evidence.get("authorization_ref", ""),
            "sim_time": sim_time,
        }
        receipt_id = stable_id("receipt", self.run_id, opening_object_id)
        self.receipts[receipt_id] = {
            "receipt_id": receipt_id,
            "opening_object_id": opening_object_id,
            "evidence_id": evidence_id,
            "warrant_id": warrant_id,
            "case_id": evidence.get("case_id", ""),
            "authorization_ref": evidence.get("authorization_ref", ""),
            "sim_time": sim_time,
        }
        return self._log(op="Receipt", sim_time=sim_time, result="ACCEPTED", reason="conditional_accountability_receipt", message={"evidence": evidence, "warrant": warrant}, test_case=test_case, opening_object_id=opening_object_id, receipt_id=receipt_id, evidence_id=evidence_id, warrant_id=warrant_id, illegal_relation=not relation_ok)

    def ledgers(self) -> dict[str, Any]:
        return {
            "schema": "integrated-record-ledgers-v1",
            "variant": self.variant,
            "validations": list(self.validations.values()),
            "admissions": list(self.admissions.values()),
            "contributions": list(self.contributions.values()),
            "quarantines": list(self.quarantines.values()),
            "evidence": list(self.evidence.values()),
            "warrants": list(self.warrants.values()),
            "opening_objects": list(self.opening_objects.values()),
            "receipts": list(self.receipts.values()),
            "events": self.events,
        }


def make_update_message(oracle: IdealSignatureOracle, *, commit: dict[str, Any], actor: str, **overrides: Any) -> dict[str, Any]:
    fields = {
        "kind": "UpdateAdmit",
        "commit_record_id": commit["record_id"],
        "authorization_ref": commit["authorization_ref"],
        "nf": commit["nf"],
        "consumption_domain": commit["consumption_domain"],
        "credential_instance": commit["credential_instance"],
        "request_id": commit["request_id"],
        "sid": commit["sid"],
        "owner": commit["owner"],
        "generation": commit["generation"],
        "committed_context": commit["committed_context"],
        "update_digest": commit["update_digest"],
        "checkpoint": commit["checkpoint"],
        "subject_ref": "synthetic-subject-001",
    }
    fields.update(overrides)
    return {**fields, "signer": actor, "signature": oracle.sign(actor, fields)}


def make_confirm_mismatch_payload(oracle: IdealSignatureOracle, payload: dict[str, Any]) -> dict[str, Any]:
    changed = dict(payload)
    changed["ctx"] = f"{payload['ctx']}-mismatch"
    changed["signature"] = oracle.sign(changed["signer"], _without_auth(changed))
    return changed
