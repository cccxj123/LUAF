"""Common deterministic, path-safe helpers for the independent study."""

from __future__ import annotations

import csv
import hashlib
import hmac
import json
from dataclasses import asdict, is_dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_default(value: Any) -> Any:
    if is_dataclass(value):
        return asdict(value)
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, set):
        return sorted(value)
    raise TypeError(f"not JSON serializable: {type(value).__name__}")


def canonical_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=_json_default)


def stable_hash(value: Any) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def stable_id(prefix: str, *parts: Any, length: int = 20) -> str:
    body = stable_hash([prefix, *parts])[:length]
    return f"{prefix}-{body}"


def derive_int(seed: int, domain: str, *parts: Any) -> int:
    digest = hashlib.sha256(canonical_json([seed, domain, *parts]).encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def safe_path(study_root: Path, relative: str | Path) -> Path:
    root = study_root.resolve(strict=True)
    candidate = (root / relative).resolve(strict=False)
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"write path escapes study root: {candidate}") from exc
    return candidate


def _exclusive_path(study_root: Path, relative: str | Path) -> Path:
    path = safe_path(study_root, relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise FileExistsError(f"refusing to overwrite existing output: {path}")
    return path


def write_json_exclusive(study_root: Path, relative: str | Path, payload: Any) -> Path:
    path = _exclusive_path(study_root, relative)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True, default=_json_default)
        handle.write("\n")
    return path


def write_jsonl_exclusive(study_root: Path, relative: str | Path, rows: Iterable[Mapping[str, Any]]) -> Path:
    path = _exclusive_path(study_root, relative)
    with path.open("x", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(canonical_json(dict(row)))
            handle.write("\n")
    return path


def write_csv_exclusive(
    study_root: Path,
    relative: str | Path,
    rows: Sequence[Mapping[str, Any]],
    fieldnames: Sequence[str] | None = None,
) -> Path:
    path = _exclusive_path(study_root, relative)
    columns = list(fieldnames or (list(rows[0]) if rows else []))
    with path.open("x", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in columns})
    return path


def append_jsonl(study_root: Path, relative: str | Path, row: Mapping[str, Any]) -> Path:
    path = safe_path(study_root, relative)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8", newline="\n") as handle:
        handle.write(canonical_json(dict(row)))
        handle.write("\n")
    return path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def source_fingerprint(code_root: Path, module_names: Sequence[str]) -> str:
    """Fingerprint an explicit, ordered research-module set.

    Packaging, inventory, and later-added helper files therefore cannot alter
    the identity of an already executed research model.
    """
    names = sorted(set(module_names))
    if not names:
        raise ValueError("an explicit non-empty executable module list is required")
    digest = hashlib.sha256()
    for name in names:
        path = safe_path(code_root, name)
        if not path.is_file():
            raise FileNotFoundError(path)
        digest.update(name.encode("utf-8"))
        digest.update(b"\0")
        digest.update(bytes.fromhex(sha256_file(path)))
    return digest.hexdigest()


class IdealSignatureOracle:
    """Idealized origin/integrity oracle; this is deliberately not called SM2.

    Signing keys remain private to this object. Protocol code can request
    verification but never exports keys or includes them in logs.
    """

    def __init__(self, seed: int):
        self._master = hashlib.sha256(f"ideal-signature-oracle|{seed}".encode()).digest()

    def _key(self, actor: str) -> bytes:
        return hmac.new(self._master, actor.encode("utf-8"), hashlib.sha256).digest()

    def sign(self, actor: str, authenticated_fields: Mapping[str, Any]) -> str:
        body = canonical_json(dict(authenticated_fields)).encode("utf-8")
        return hmac.new(self._key(actor), body, hashlib.sha256).hexdigest()

    def verify(self, actor: str, authenticated_fields: Mapping[str, Any], signature: str) -> bool:
        expected = self.sign(actor, authenticated_fields)
        return hmac.compare_digest(expected, signature)
