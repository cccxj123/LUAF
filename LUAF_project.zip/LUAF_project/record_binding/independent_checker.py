"""Independent structural and relation checker for the record pilot.

The checker reconstructs facts from raw ledgers and event payloads. It does
not import adapter predicates and does not use ``reason`` or producer
``new_*`` flags to decide correctness. Declared ablation diagnostics never
remove observations from ``RELATION_VIOLATIONS``.
"""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path
from typing import Any


SUCCESS = {"ACCEPTED", "IDEMPOTENT"}
VALIDATION_EFFECT_RESULTS = SUCCESS | {"NOT_PROVIDED"}


def _read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def _read_jsonl(path: Path) -> list[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def _rows(payload: dict[str, Any], key: str, label: str, shape: list[dict[str, Any]]) -> list[Any]:
    value = payload.get(key, [])
    if not isinstance(value, list):
        shape.append({"kind": "invalid_collection_type", "record_type": label, "observed_type": type(value).__name__})
        return []
    return value


def _id_value(row: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if key in row:
            return row[key]
    return None


def _valid_type(value: Any, expected: str) -> bool:
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    return False


def _schema(rows: list[Any], label: str, fields: dict[str, tuple[str, bool]], id_keys: tuple[str, ...], shape: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for pos, row in enumerate(rows):
        if not isinstance(row, dict):
            shape.append({"kind": "invalid_record_type", "record_type": label, "index": pos, "observed_type": type(row).__name__})
            continue
        for field, (expected_type, nonempty) in fields.items():
            if field not in row:
                shape.append({"kind": "missing_field", "record_type": label, "index": pos, "field": field})
                continue
            value = row[field]
            if not _valid_type(value, expected_type):
                shape.append({"kind": "invalid_field_type", "record_type": label, "index": pos, "field": field, "expected": expected_type, "observed_type": type(value).__name__})
            elif nonempty and value == "":
                shape.append({"kind": "empty_required_field", "record_type": label, "index": pos, "field": field})
        identifier = _id_value(row, *id_keys)
        if not isinstance(identifier, str) or not identifier:
            shape.append({"kind": "missing_or_invalid_id", "record_type": label, "index": pos, "id_fields": list(id_keys), "observed": identifier})
            continue
        if identifier in result:
            shape.append({"kind": "duplicate_id", "record_type": label, "id": identifier})
        result.setdefault(identifier, row)
    return result


def _time(row: dict[str, Any]) -> float | None:
    value = row.get("sim_time")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def _append_relation(items: list[dict[str, Any]], kind: str, detail: str, *, severity: str = "critical", **extra: Any) -> None:
    items.append({"kind": kind, "detail": detail, "severity": severity, **extra})


def _mismatches(child: dict[str, Any], parent: dict[str, Any], mapping: tuple[tuple[str, str], ...]) -> list[str]:
    return [child_field for child_field, parent_field in mapping if child.get(child_field) != parent.get(parent_field)]


def _effect_order(label: str, row: dict[str, Any], state_events: list[dict[str, Any]], integrated_events: list[dict[str, Any]]) -> tuple[str, float, int] | None:
    specs: dict[str, tuple[str, str, set[str], set[str] | None]] = {
        "consumption": ("state", "consumption_record_id", SUCCESS, None),
        "commit": ("state", "commit_record_id", SUCCESS, None),
        "state_admission": ("state", "update_admission_id", SUCCESS, None),
        "state_contribution": ("state", "contribution_id", SUCCESS, None),
        "validation": ("integrated", "update_validation_id", VALIDATION_EFFECT_RESULTS, {"UpdateAdmit", "Quarantine", "Accountability"}),
        "admission": ("integrated", "update_admission_id", SUCCESS, {"UpdateAdmit"}),
        "contribution": ("integrated", "contribution_id", SUCCESS, {"Contribution"}),
        "quarantine": ("integrated", "quarantine_id", SUCCESS, {"Quarantine"}),
        "evidence": ("integrated", "evidence_id", SUCCESS, {"Evidence"}),
        "warrant": ("integrated", "warrant_id", SUCCESS, {"Warrant"}),
        "opening": ("integrated", "opening_object_id", SUCCESS, {"Receipt"}),
        "receipt": ("integrated", "receipt_id", SUCCESS, {"Receipt"}),
    }
    id_fields: dict[str, tuple[str, ...]] = {
        "consumption": ("record_id",), "commit": ("record_id", "commit_record_id"),
        "state_admission": ("record_id", "update_admission_id"), "state_contribution": ("contribution_id",),
        "validation": ("update_validation_id",), "admission": ("update_admission_id",),
        "contribution": ("contribution_id",), "quarantine": ("quarantine_id",),
        "evidence": ("evidence_id",), "warrant": ("warrant_id",),
        "opening": ("opening_object_id",), "receipt": ("receipt_id",),
    }
    source, event_field, results, event_types = specs[label]
    identifier = _id_value(row, *id_fields[label])
    events = state_events if source == "state" else integrated_events
    candidates = [event for event in events if isinstance(event, dict) and event.get(event_field) == identifier and event.get("result") in results and (event_types is None or event.get("event_type") in event_types)]
    ordered: list[tuple[str, float, int]] = []
    for event in candidates:
        try:
            ordered.append((source, float(event["sim_time"]), int(event["event_seq"])))
        except (KeyError, TypeError, ValueError):
            continue
    return min(ordered, key=lambda item: (item[1], item[2])) if ordered else None


def _recovery(events: list[dict[str, Any]], updates: list[dict[str, Any]], contributions: list[dict[str, Any]]) -> dict[str, Any]:
    retries = [event for event in events if event.get("event_type") == "Retry"]
    retry_success = [event for event in retries if event.get("result") in SUCCESS]
    retry_by_auth: dict[str, float] = {}
    for event in retries:
        auth, when = event.get("authorization_key"), event.get("sim_time")
        if isinstance(auth, str) and auth and isinstance(when, (int, float)) and not isinstance(when, bool):
            retry_by_auth.setdefault(auth, float(when))
    commit_recovered = False
    for event in retry_success:
        if event.get("retry_target") != "Commit":
            continue
        prior = [candidate for candidate in events if candidate.get("event_type") == "Commit" and candidate.get("request_id") == event.get("request_id") and candidate.get("result") == "ACCEPTED"]
        if prior and event.get("commit_record_id") == prior[0].get("commit_record_id"):
            commit_recovered = True
    update_after_retry = False
    for row in updates:
        auth, when = str(row.get("authorization_key", row.get("authorization_ref", ""))), _time(row)
        if auth in retry_by_auth and when is not None and when >= retry_by_auth[auth]:
            update_after_retry = True
    contribution_after_retry = False
    durations: list[float] = []
    for row in contributions:
        auth, when = str(row.get("authorization_key", row.get("authorization_ref", ""))), _time(row)
        if auth in retry_by_auth and when is not None and when >= retry_by_auth[auth]:
            contribution_after_retry = True
            durations.append(when - retry_by_auth[auth])
    return {"retry_response_success": bool(retry_success), "commit_receipt_recovered": commit_recovered, "update_admitted_after_retry": update_after_retry, "contribution_completed_after_retry": contribution_after_retry, "recovery_durations": durations}


def check_raw(*, state_events_path: Path, state_ledger_path: Path, integrated_ledger_path: Path | None = None, expected_recovery: dict[str, Any] | None = None, expected_diagnostics: dict[str, list[str]] | None = None) -> dict[str, Any]:
    state_events = _read_jsonl(state_events_path)
    state = _read_json(state_ledger_path)
    integrated = _read_json(integrated_ledger_path) if integrated_ledger_path else {}
    if not isinstance(state, dict) or not isinstance(integrated, dict):
        raise ValueError("ledger roots must be JSON objects")
    integrated_events_value = integrated.get("events", [])
    integrated_events = integrated_events_value if isinstance(integrated_events_value, list) else []
    shape: list[dict[str, Any]] = []
    if not isinstance(integrated_events_value, list):
        shape.append({"kind": "invalid_collection_type", "record_type": "integrated_event", "observed_type": type(integrated_events_value).__name__})
    for label, events in (("state_event", state_events), ("integrated_event", integrated_events)):
        for pos, event in enumerate(events):
            if not isinstance(event, dict):
                shape.append({"kind": "invalid_record_type", "record_type": label, "index": pos, "observed_type": type(event).__name__})

    consumptions = _rows(state, "consumption_history", "consumption", shape)
    commits = _rows(state, "commit_records", "commit", shape)
    state_admissions = _rows(state, "update_history", "state_admission", shape)
    state_contributions = _rows(state, "aggregate_history", "state_contribution", shape)
    validations = _rows(integrated, "validations", "validation", shape)
    admissions = _rows(integrated, "admissions", "admission", shape)
    contributions = _rows(integrated, "contributions", "contribution", shape)
    quarantines = _rows(integrated, "quarantines", "quarantine", shape)
    evidence = _rows(integrated, "evidence", "evidence", shape)
    warrants = _rows(integrated, "warrants", "warrant", shape)
    openings = _rows(integrated, "opening_objects", "opening", shape)
    receipts = _rows(integrated, "receipts", "receipt", shape)

    tm = {"sim_time": ("number", False)}
    consumption_by_id = _schema(consumptions, "consumption", {"record_id": ("string", True), "authorization_key": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), **tm}, ("record_id",), shape)
    commit_fields = {"record_id": ("string", True), "commit_record_id": ("string", True), "consumption_record_id": ("string", True), "authorization_key": ("string", True), "authorization_ref": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), "credential_instance": ("string", True), "request_id": ("string", True), "sid": ("string", True), "owner": ("string", True), "generation": ("integer", False), "committed_context": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), **tm}
    commit_by_id = _schema(commits, "commit", commit_fields, ("record_id", "commit_record_id"), shape)
    state_admission_fields = {"record_id": ("string", True), "update_admission_id": ("string", True), "update_validation_id": ("string", True), "commit_record_id": ("string", True), "consumption_record_id": ("string", True), "authorization_key": ("string", True), "authorization_ref": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), "request_id": ("string", True), "sid": ("string", True), "owner": ("string", True), "generation": ("integer", False), "committed_context": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), **tm}
    state_admission_by_id = _schema(state_admissions, "state_admission", state_admission_fields, ("record_id", "update_admission_id"), shape)
    state_contribution_fields = {"contribution_id": ("string", True), "update_admission_id": ("string", True), "update_validation_id": ("string", True), "commit_record_id": ("string", True), "authorization_key": ("string", True), "authorization_ref": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), **tm}
    state_contribution_by_id = _schema(state_contributions, "state_contribution", state_contribution_fields, ("contribution_id",), shape)
    validation_fields = {"update_validation_id": ("string", True), "commit_record_id": ("string", True), "consumption_record_id": ("string", True), "authorization_ref": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), "request_id": ("string", True), "sid": ("string", True), "owner": ("string", True), "generation": ("integer", False), "committed_context": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), "abnormal": ("boolean", False), **tm}
    validation_by_id = _schema(validations, "validation", validation_fields, ("update_validation_id",), shape)
    admission_fields = {"update_admission_id": ("string", True), "update_validation_id": ("string", True), "commit_record_id": ("string", True), "consumption_record_id": ("string", True), "authorization_ref": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), "credential_instance": ("string", True), "request_id": ("string", True), "sid": ("string", True), "owner": ("string", True), "generation": ("integer", False), "committed_context": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), **tm}
    admission_by_id = _schema(admissions, "admission", admission_fields, ("update_admission_id",), shape)
    contribution_fields = {"contribution_id": ("string", True), "update_admission_id": ("string", True), "update_validation_id": ("string", True), "commit_record_id": ("string", True), "consumption_record_id": ("string", True), "authorization_ref": ("string", True), "nf": ("string", True), "consumption_domain": ("string", True), "credential_instance": ("string", True), "request_id": ("string", True), "sid": ("string", True), "owner": ("string", True), "generation": ("integer", False), "committed_context": ("string", True), "update_digest": ("string", True), "checkpoint": ("string", True), **tm}
    contribution_by_id = _schema(contributions, "contribution", contribution_fields, ("contribution_id",), shape)
    quarantine_by_id = _schema(quarantines, "quarantine", {"quarantine_id": ("string", True), "update_validation_id": ("string", True), "commit_record_id": ("string", True), **tm}, ("quarantine_id",), shape)
    evidence_by_id = _schema(evidence, "evidence", {"evidence_id": ("string", True), "update_validation_id": ("string", True), "quarantine_id": ("string", True), "commit_record_id": ("string", True), "authorization_ref": ("string", True), "case_id": ("string", True), "opening_object_id": ("string", True), "scope": ("string", True), "signer": ("string", True), "signature": ("string", True), **tm}, ("evidence_id",), shape)
    warrant_by_id = _schema(warrants, "warrant", {"warrant_id": ("string", True), "evidence_id": ("string", True), "commit_record_id": ("string", True), "authorization_ref": ("string", True), "case_id": ("string", True), "opening_object_id": ("string", True), "scope": ("string", True), "signer": ("string", True), "signature": ("string", True), "valid_from": ("number", False), "valid_until": ("number", False), **tm}, ("warrant_id",), shape)
    opening_by_id = _schema(openings, "opening", {"opening_object_id": ("string", True), "evidence_id": ("string", True), "warrant_id": ("string", True), "authorization_ref": ("string", True), **tm}, ("opening_object_id",), shape)
    receipt_by_id = _schema(receipts, "receipt", {"receipt_id": ("string", True), "opening_object_id": ("string", True), "evidence_id": ("string", True), "warrant_id": ("string", True), "case_id": ("string", True), "authorization_ref": ("string", True), **tm}, ("receipt_id",), shape)

    indexes = {"consumption": consumption_by_id, "commit": commit_by_id, "state_admission": state_admission_by_id, "state_contribution": state_contribution_by_id, "validation": validation_by_id, "admission": admission_by_id, "contribution": contribution_by_id, "quarantine": quarantine_by_id, "evidence": evidence_by_id, "warrant": warrant_by_id, "opening": opening_by_id, "receipt": receipt_by_id}
    global_ids: dict[str, str] = {}
    for label, index in indexes.items():
        for identifier in index:
            prior = global_ids.get(identifier)
            if prior is not None and prior != label:
                shape.append({"kind": "cross_type_duplicate_id", "id": identifier, "record_types": [prior, label]})
            global_ids.setdefault(identifier, label)

    relation: list[dict[str, Any]] = []
    missing_parent_reference_count = 0

    def parent(child: dict[str, Any], field: str, parent_label: str, child_label: str) -> dict[str, Any] | None:
        nonlocal missing_parent_reference_count
        value = child.get(field)
        if not isinstance(value, str) or not value:
            missing_parent_reference_count += 1
            _append_relation(relation, "missing_parent_id", f"{child_label}.{field} is required", child_type=child_label, parent_type=parent_label, observed=value)
            return None
        result = indexes[parent_label].get(value)
        if result is None:
            missing_parent_reference_count += 1
            _append_relation(relation, "missing_parent", f"{child_label}.{field} does not resolve", child_type=child_label, parent_type=parent_label, parent_id=value)
            return None
        parent_time, child_time = _time(result), _time(child)
        if parent_time is None or child_time is None:
            _append_relation(relation, "invalid_causal_time", "parent or child has an invalid sim_time", child_type=child_label, parent_type=parent_label, parent_id=value)
        elif parent_time > child_time:
            _append_relation(relation, "parent_after_child", "parent sim_time is after child sim_time", child_type=child_label, parent_type=parent_label, parent_id=value, parent_time=parent_time, child_time=child_time)
        elif parent_time == child_time:
            po = _effect_order(parent_label, result, state_events, integrated_events)
            co = _effect_order(child_label, child, state_events, integrated_events)
            if po and co and po[0] == co[0] and po[2] > co[2]:
                _append_relation(relation, "parent_event_after_child", "same-time parent event sequence follows child", child_type=child_label, parent_type=parent_label, parent_id=value, parent_event_seq=po[2], child_event_seq=co[2])
        return result

    def check_mismatch(kind: str, detail: str, child: dict[str, Any], parent_row: dict[str, Any], mapping: tuple[tuple[str, str], ...], *, severity: str = "critical", **extra: Any) -> None:
        fields = _mismatches(child, parent_row, mapping)
        if fields:
            _append_relation(relation, kind, detail, severity=severity, fields=fields, **extra)

    consumption_map = (("authorization_key", "authorization_key"), ("authorization_ref", "authorization_key"), ("nf", "nf"), ("consumption_domain", "consumption_domain"))
    commit_map = (("consumption_record_id", "consumption_record_id"), ("authorization_ref", "authorization_ref"), ("nf", "nf"), ("consumption_domain", "consumption_domain"), ("request_id", "request_id"), ("sid", "sid"), ("owner", "owner"), ("generation", "generation"), ("committed_context", "committed_context"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"))
    for row in commits:
        if not isinstance(row, dict):
            continue
        if row.get("record_id") != row.get("commit_record_id"):
            _append_relation(relation, "commit_id_alias_mismatch", "record_id and commit_record_id differ", parent_id=row.get("record_id"))
        p = parent(row, "consumption_record_id", "consumption", "commit")
        if p:
            check_mismatch("commit_parent_field_mismatch", "CommitRecord disagrees with consumption parent", row, p, consumption_map, parent_id=row.get("consumption_record_id"))
    for row in state_admissions:
        if not isinstance(row, dict):
            continue
        if row.get("record_id") != row.get("update_admission_id"):
            _append_relation(relation, "state_admission_id_alias_mismatch", "record_id and update_admission_id differ", parent_id=row.get("record_id"))
        p = parent(row, "commit_record_id", "commit", "state_admission")
        if p:
            check_mismatch("state_admission_parent_field_mismatch", "state admission disagrees with CommitRecord", row, p, commit_map, parent_id=p.get("record_id"))
    state_contribution_map = (("update_validation_id", "update_validation_id"), ("commit_record_id", "commit_record_id"), ("authorization_key", "authorization_key"), ("authorization_ref", "authorization_ref"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"))
    for row in state_contributions:
        if not isinstance(row, dict):
            continue
        p = parent(row, "update_admission_id", "state_admission", "state_contribution")
        if p:
            check_mismatch("state_contribution_parent_field_mismatch", "state contribution disagrees with admission parent", row, p, state_contribution_map, parent_id=p.get("update_admission_id"))
    for row in validations:
        if not isinstance(row, dict):
            continue
        p = parent(row, "commit_record_id", "commit", "validation")
        if p:
            check_mismatch("validation_parent_field_mismatch", "validation is not derived from CommitRecord", row, p, commit_map, severity="diagnostic", parent_id=p.get("record_id"))
    validation_map = (("commit_record_id", "commit_record_id"), ("consumption_record_id", "consumption_record_id"), ("authorization_ref", "authorization_ref"), ("nf", "nf"), ("consumption_domain", "consumption_domain"), ("request_id", "request_id"), ("sid", "sid"), ("owner", "owner"), ("generation", "generation"), ("committed_context", "committed_context"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"))
    for row in admissions:
        if not isinstance(row, dict):
            continue
        cp = parent(row, "commit_record_id", "commit", "admission")
        if cp:
            check_mismatch("admission_parent_field_mismatch", "admission is not derived from CommitRecord", row, cp, commit_map + (("credential_instance", "credential_instance"),), severity="diagnostic", parent_id=cp.get("record_id"))
        vp = parent(row, "update_validation_id", "validation", "admission")
        if vp:
            check_mismatch("admission_validation_mismatch", "admission is not consistent with validation", row, vp, validation_map, severity="diagnostic", parent_id=vp.get("update_validation_id"))
    contribution_map = (("update_validation_id", "update_validation_id"), ("commit_record_id", "commit_record_id"), ("consumption_record_id", "consumption_record_id"), ("authorization_ref", "authorization_ref"), ("nf", "nf"), ("consumption_domain", "consumption_domain"), ("credential_instance", "credential_instance"), ("request_id", "request_id"), ("sid", "sid"), ("owner", "owner"), ("generation", "generation"), ("committed_context", "committed_context"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"))
    for row in contributions:
        if not isinstance(row, dict):
            continue
        p = parent(row, "update_admission_id", "admission", "contribution")
        if p:
            check_mismatch("contribution_parent_field_mismatch", "contribution fields do not equal trusted admission parent", row, p, contribution_map, parent_id=p.get("update_admission_id"))
    for row in quarantines:
        if not isinstance(row, dict):
            continue
        p = parent(row, "update_validation_id", "validation", "quarantine")
        if p and row.get("commit_record_id") != p.get("commit_record_id"):
            _append_relation(relation, "quarantine_validation_mismatch", "quarantine commit does not match validation", parent_id=p.get("update_validation_id"), fields=["commit_record_id"])
    for row in evidence:
        if not isinstance(row, dict):
            continue
        vp = parent(row, "update_validation_id", "validation", "evidence")
        qp = parent(row, "quarantine_id", "quarantine", "evidence")
        if vp:
            check_mismatch("evidence_validation_mismatch", "evidence does not inherit validation identity", row, vp, (("commit_record_id", "commit_record_id"), ("authorization_ref", "authorization_ref")), parent_id=vp.get("update_validation_id"))
        if qp and (qp.get("update_validation_id") != row.get("update_validation_id") or qp.get("commit_record_id") != row.get("commit_record_id")):
            _append_relation(relation, "evidence_quarantine_mismatch", "evidence and quarantine do not share validation/commit", parent_id=qp.get("quarantine_id"), fields=["update_validation_id", "commit_record_id"])
    warrant_mapping = (("commit_record_id", "commit_record_id"), ("authorization_ref", "authorization_ref"), ("case_id", "case_id"), ("opening_object_id", "opening_object_id"), ("scope", "scope"))
    for row in warrants:
        if not isinstance(row, dict):
            continue
        ep = parent(row, "evidence_id", "evidence", "warrant")
        if ep:
            check_mismatch("warrant_evidence_mismatch", "warrant does not inherit evidence identity", row, ep, warrant_mapping, severity="diagnostic", parent_id=ep.get("evidence_id"))
    for row in openings:
        if not isinstance(row, dict):
            continue
        ep = parent(row, "evidence_id", "evidence", "opening")
        wp = parent(row, "warrant_id", "warrant", "opening")
        if ep:
            check_mismatch("opening_evidence_mismatch", "opening does not inherit evidence identity", row, ep, (("opening_object_id", "opening_object_id"), ("authorization_ref", "authorization_ref")), severity="diagnostic", parent_id=ep.get("evidence_id"))
        if wp:
            check_mismatch("opening_warrant_mismatch", "opening does not inherit warrant identity", row, wp, (("opening_object_id", "opening_object_id"), ("authorization_ref", "authorization_ref")), severity="diagnostic", parent_id=wp.get("warrant_id"))
        if ep and wp and _mismatches(ep, wp, warrant_mapping):
            _append_relation(relation, "opening_parent_relation_mismatch", "opening joins non-matching evidence and warrant", severity="diagnostic", parent_id=row.get("opening_object_id"))
    for row in receipts:
        if not isinstance(row, dict):
            continue
        op = parent(row, "opening_object_id", "opening", "receipt")
        ep = parent(row, "evidence_id", "evidence", "receipt")
        wp = parent(row, "warrant_id", "warrant", "receipt")
        if op:
            check_mismatch("receipt_opening_mismatch", "receipt does not inherit opening identity", row, op, (("evidence_id", "evidence_id"), ("warrant_id", "warrant_id"), ("authorization_ref", "authorization_ref")), severity="diagnostic", parent_id=op.get("opening_object_id"))
        if ep:
            check_mismatch("receipt_evidence_mismatch", "receipt does not inherit evidence identity", row, ep, (("case_id", "case_id"), ("authorization_ref", "authorization_ref"), ("opening_object_id", "opening_object_id")), severity="diagnostic", parent_id=ep.get("evidence_id"))
        if wp:
            check_mismatch("receipt_warrant_mismatch", "receipt does not inherit warrant identity", row, wp, (("case_id", "case_id"), ("authorization_ref", "authorization_ref"), ("opening_object_id", "opening_object_id")), severity="diagnostic", parent_id=wp.get("warrant_id"))

    record_sets = {"consumption": consumptions, "commit": commits, "state_admission": state_admissions, "state_contribution": state_contributions, "validation": validations, "admission": admissions, "contribution": contributions, "quarantine": quarantines, "evidence": evidence, "warrant": warrants, "opening": openings, "receipt": receipts}
    id_candidates = ("record_id", "update_validation_id", "update_admission_id", "contribution_id", "quarantine_id", "evidence_id", "warrant_id", "opening_object_id", "receipt_id")
    for label, rows in record_sets.items():
        for row in rows:
            if not isinstance(row, dict) or _effect_order(label, row, state_events, integrated_events) is not None:
                continue
            id_field = next((key for key in id_candidates if key in row), "")
            severity = "diagnostic" if label == "validation" else "critical"
            _append_relation(relation, "record_without_effective_event", f"{label} has no corresponding effective event", severity=severity, child_type=label, parent_id=row.get(id_field), accepted_effect=False)

    for event in state_events:
        if not isinstance(event, dict) or event.get("result") not in SUCCESS:
            continue
        for field, label in (("consumption_record_id", "consumption"), ("commit_record_id", "commit"), ("update_admission_id", "state_admission"), ("contribution_id", "state_contribution")):
            value = event.get(field)
            if isinstance(value, str) and value and value not in indexes[label]:
                _append_relation(relation, "successful_event_without_record", f"successful state event references absent {label}", event_id=event.get("event_id"), parent_id=value)
        if event.get("event_type") == "Confirm":
            session = (event.get("state_before") or {}).get("session") if isinstance(event.get("state_before"), dict) else None
            if isinstance(session, dict):
                mapping = (("authorization_key", "authorization_key"), ("nf", "nf"), ("sid", "sid"), ("edge_id", "edge_id"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"), ("ctx", "context"))
                fields = [left for left, right in mapping if session.get(left) != event.get(right)]
                if fields:
                    _append_relation(relation, "accepted_confirm_binding_mismatch", "accepted Confirm disagrees with reserved session", severity="diagnostic", event_id=event.get("event_id"), fields=fields, accepted_effect=True)

    integrated_effects = {"UpdateAdmit": (("update_admission_id", "admission"),), "Contribution": (("contribution_id", "contribution"),), "Quarantine": (("quarantine_id", "quarantine"),), "Evidence": (("evidence_id", "evidence"),), "Warrant": (("warrant_id", "warrant"),), "Receipt": (("opening_object_id", "opening"), ("receipt_id", "receipt"))}
    update_event_map = (("authorization_ref", "authorization_ref"), ("nf", "nf"), ("consumption_domain", "consumption_domain"), ("credential_instance", "credential_instance"), ("request_id", "request_id"), ("sid", "sid"), ("owner", "owner"), ("generation", "generation"), ("committed_context", "committed_context"), ("update_digest", "update_digest"), ("checkpoint", "checkpoint"))
    for event in integrated_events:
        if not isinstance(event, dict) or event.get("result") not in SUCCESS:
            continue
        message = event.get("message") if isinstance(event.get("message"), dict) else {}
        for field, label in integrated_effects.get(str(event.get("event_type")), ()):
            value = event.get(field)
            if not isinstance(value, str) or not value:
                _append_relation(relation, "successful_event_without_record_id", f"successful {event.get('event_type')} lacks {field}", event_id=event.get("event_id"), accepted_effect=True)
            elif value not in indexes[label]:
                _append_relation(relation, "successful_event_without_record", f"successful event references absent {label}", event_id=event.get("event_id"), parent_id=value, accepted_effect=True)
        if event.get("event_type") == "UpdateAdmit":
            commit_id = message.get("commit_record_id")
            cp = commit_by_id.get(commit_id) if isinstance(commit_id, str) and commit_id else None
            if cp is None:
                _append_relation(relation, "successful_event_without_parent", "accepted UpdateAdmit has no CommitRecord", event_id=event.get("event_id"), parent_id=commit_id, accepted_effect=True)
            else:
                fields = _mismatches(message, cp, update_event_map)
                if fields:
                    _append_relation(relation, "accepted_update_parent_field_mismatch", "accepted UpdateAdmit message disagrees with CommitRecord", severity="diagnostic", event_id=event.get("event_id"), fields=fields, accepted_effect=True)
        elif event.get("event_type") == "Contribution":
            admission_id = message.get("update_admission_id")
            ap = admission_by_id.get(admission_id) if isinstance(admission_id, str) and admission_id else None
            if ap is None:
                _append_relation(relation, "successful_event_without_parent", "accepted Contribution has no admission parent", event_id=event.get("event_id"), parent_id=admission_id, accepted_effect=True)
            else:
                fields = [field for field in ("authorization_ref", "checkpoint", "update_validation_id", "commit_record_id", "consumption_record_id", "credential_instance", "update_digest") if field in message and message.get(field) != ap.get(field)]
                if fields:
                    _append_relation(relation, "accepted_contribution_parent_field_mismatch", "accepted Contribution message disagrees with admission", event_id=event.get("event_id"), fields=fields, accepted_effect=True)
        elif event.get("event_type") == "Receipt":
            em = message.get("evidence") if isinstance(message.get("evidence"), dict) else {}
            wm = message.get("warrant") if isinstance(message.get("warrant"), dict) else {}
            fields = [field for field in ("evidence_id", "commit_record_id", "authorization_ref", "case_id", "opening_object_id", "scope") if em.get(field) != wm.get(field)]
            if fields:
                _append_relation(relation, "accepted_receipt_relation_mismatch", "accepted Receipt joins mismatched evidence and warrant", severity="diagnostic", event_id=event.get("event_id"), fields=fields, accepted_effect=True)

    duplicate_items: list[dict[str, Any]] = []
    consumption_domain_nf = Counter((str(row.get("consumption_domain", "")), str(row.get("nf", ""))) for row in consumptions if isinstance(row, dict))
    for key, count in consumption_domain_nf.items():
        if count > 1:
            duplicate_items.append({"kind": "consumption_domain_nf", "key": list(key), "count": count})
    all_admissions = [row for row in state_admissions + admissions if isinstance(row, dict)]
    admission_domain_nf = Counter((str(row.get("consumption_domain", "")), str(row.get("nf", ""))) for row in all_admissions)
    for key, count in admission_domain_nf.items():
        if count > 1:
            duplicate_items.append({"kind": "admission_domain_nf", "key": list(key), "count": count})
    all_contributions = [row for row in state_contributions + contributions if isinstance(row, dict)]
    contribution_parent = Counter(str(row.get("update_admission_id", "")) for row in all_contributions)
    for key, count in contribution_parent.items():
        if key and count > 1:
            duplicate_items.append({"kind": "same_admission_multiple_contributions", "parent_id": key, "count": count})
    contribution_key = Counter((str(row.get("checkpoint", "")), str(row.get("authorization_key", row.get("authorization_ref", "")))) for row in all_contributions)
    for key, count in contribution_key.items():
        if count > 1:
            duplicate_items.append({"kind": "contribution_round_authorization", "key": list(key), "count": count})
    receipt_opening = Counter(str(row.get("opening_object_id", "")) for row in receipts if isinstance(row, dict))
    for key, count in receipt_opening.items():
        if key and count > 1:
            duplicate_items.append({"kind": "same_opening_multiple_receipts", "opening_object_id": key, "count": count})

    recovery = _recovery(state_events, all_admissions, all_contributions)
    recovery_ok = True
    if expected_recovery:
        for key, value in expected_recovery.items():
            if key == "duration":
                recovery_ok = recovery_ok and any(abs(float(item) - float(value)) < 1e-12 for item in recovery["recovery_durations"])
            elif key in recovery:
                recovery_ok = recovery_ok and recovery[key] == value
    diagnostic_items = [item for item in relation if item.get("severity") == "diagnostic"]
    critical_items = [item for item in relation if item.get("severity") != "diagnostic"]
    observed_diagnostics = Counter(str(item.get("kind")) for item in diagnostic_items)
    policy = expected_diagnostics or {}
    allowed, required = set(policy.get("allowed_kinds", [])), set(policy.get("required_kinds", []))
    unexpected = sorted(kind for kind in observed_diagnostics if kind not in allowed)
    missing_required = sorted(kind for kind in required if observed_diagnostics.get(kind, 0) == 0)
    diagnostic_match = not unexpected and not missing_required and recovery_ok

    structure = {"passed": not shape, "violation_count": len(shape), "violations": shape}
    relations = {"passed": not relation, "safety_properties_passed": not relation, "violation_count": len(relation), "critical_violation_count": len(critical_items), "diagnostic_violation_count": len(diagnostic_items), "violations": relation}
    duplicates = {"passed": not duplicate_items, "violation_count": len(duplicate_items), "effects": duplicate_items}
    diagnostics = {"passed": diagnostic_match, "allowed_kinds": sorted(allowed), "required_kinds": sorted(required), "observed_by_kind": dict(sorted(observed_diagnostics.items())), "unexpected_kinds": unexpected, "missing_required_kinds": missing_required, "expected_recovery": expected_recovery or {}, "observed_recovery": recovery, "recovery_match": recovery_ok}
    count_by_domain_nf = Counter(f"{row.get('consumption_domain', '')}|{row.get('nf', '')}" for row in consumptions if isinstance(row, dict))
    commit_count_by_domain_nf = Counter(f"{row.get('consumption_domain', '')}|{row.get('nf', '')}" for row in commits if isinstance(row, dict))
    update_ids = {_id_value(row, "record_id", "update_admission_id") for row in all_admissions}
    contribution_count = Counter(f"{row.get('checkpoint', '')}|{row.get('authorization_key', row.get('authorization_ref', ''))}" for row in all_contributions)
    metrics = {
        "consumption_count_by_domain_nf": dict(sorted(count_by_domain_nf.items())),
        "commit_record_count_by_domain_nf": dict(sorted(commit_count_by_domain_nf.items())),
        "update_admission_count": len({value for value in update_ids if isinstance(value, str) and value}),
        "contribution_count_by_round_and_authorization": dict(sorted(contribution_count.items())),
        "effective_receipt_count": len(receipt_by_id),
        "illegal_relation_accept_count": sum(bool(item.get("accepted_effect")) for item in diagnostic_items),
        "missing_parent_reference_count": missing_parent_reference_count,
        "recovery": recovery,
        "expected_recovery": expected_recovery or {},
        "expected_recovery_pass": recovery_ok,
        "raw_event_count": len(state_events),
    }
    passed = bool(structure["passed"] and not critical_items and duplicates["passed"] and diagnostic_match)
    return {"schema": "independent-record-link-check-v2", "PASS": passed, "EVIDENCE_STRUCTURE_VALID": structure, "RELATION_VIOLATIONS": relations, "DUPLICATE_EFFECTS": duplicates, "EXPECTED_DIAGNOSTIC_MATCH": diagnostics, "metrics": metrics}


def check_paths(**kwargs: Any) -> dict[str, Any]:
    return check_raw(**kwargs)


if __name__ == "__main__":
    raise SystemExit("use check_raw from the fixed runner")
