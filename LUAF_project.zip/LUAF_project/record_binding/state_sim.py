"""Event-driven fixed-trace comparison for legacy and paper-order B3.

The module models logical state transitions, not wall-clock deployment time.
All schemes share the same message validation, revocation policy, and
downstream update/aggregate deduplication. Only their declared NF transition
rules differ.
"""

from __future__ import annotations

import copy
import heapq
import math
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any, Iterable

from common import IdealSignatureOracle, canonical_json, stable_hash, stable_id


VARIANTS = (
    "B0_LOCAL_CACHE",
    "B1_ATOMIC_AFTER_CONFIRM",
    "B2_GENERIC_RCA",
    "B3_LEGACY_CONSUME_AT_REQUEST",
    "B3_PAPER_ORDER",
)
SCENARIOS = ("S0", "S1", "S2", "S3", "S4", "S5", "S6")
REQUIRED_EVENT_FIELDS = (
    "run_id",
    "attempt_id",
    "config_hash",
    "source_hash",
    "seed",
    "scenario",
    "variant",
    "event_seq",
    "sim_time",
    "request_id",
    "authorization_key",
    "nf",
    "sid",
    "edge_id",
    "reservation_generation",
    "revocation_version",
    "update_digest",
    "event_type",
    "state_before",
    "state_after",
    "result",
    "reason",
    "parent_event_id",
    "update_admission_id",
)


@dataclass(order=True)
class Action:
    sim_time: float
    order: int
    kind: str = field(compare=False)
    payload: dict[str, Any] = field(compare=False, default_factory=dict)
    parent_event_id: str = field(compare=False, default="")


@dataclass
class Workload:
    scenario: str
    seed: int
    authorization_count: int
    actions: list[Action]
    authorization_keys: list[str]
    schedule_hash: str


def _signed_payload(
    oracle: IdealSignatureOracle,
    actor: str,
    kind: str,
    *,
    auth: str,
    nf: str,
    credential: str,
    ctx: str,
    tx_id: str,
    sid: str,
    edge_id: str,
    update_digest: str,
    reservation_generation: int = 0,
    **extra: Any,
) -> dict[str, Any]:
    fields = {
        "kind": kind,
        "authorization_key": auth,
        "nf": nf,
        "credential_instance": credential,
        "ctx": ctx,
        "tx_id": tx_id,
        "sid": sid,
        "edge_id": edge_id,
        "update_digest": update_digest,
        "reservation_generation": reservation_generation,
    }
    fields.update(extra)
    return {**fields, "signer": actor, "signature": oracle.sign(actor, fields)}


def _action_dict(action: Action) -> dict[str, Any]:
    return {
        "sim_time": action.sim_time,
        "order": action.order,
        "kind": action.kind,
        "payload": action.payload,
        "parent_event_id": action.parent_event_id,
    }


def generate_workload(scenario: str, seed: int, authorization_count: int) -> Workload:
    if scenario not in SCENARIOS:
        raise ValueError(f"unknown scenario: {scenario}")
    if authorization_count <= 0:
        raise ValueError("authorization_count must be positive")
    oracle = IdealSignatureOracle(seed)
    actions: list[Action] = []
    auth_keys: list[str] = []
    order = 0

    def add(time: float, kind: str, payload: dict[str, Any]) -> None:
        nonlocal order
        order += 1
        actions.append(Action(time, order, kind, payload))

    for index in range(authorization_count):
        base = float(index * 50)
        credential = f"credential-{seed}-{index:04d}"
        ctx = stable_id("ctx", seed, scenario, index)
        nf = stable_id("nf", credential, ctx, 1, length=32)
        auth = stable_id("auth", credential, ctx, nf, length=28)
        digest = stable_id("update", auth, "payload-v1", length=32)
        checkpoint = f"checkpoint-{scenario}-{index:04d}"
        tx_old = stable_id("tx", auth, "old")
        tx_new = stable_id("tx", auth, "new")
        auth_keys.append(auth)

        def msg(kind: str, tx: str, edge: str, generation: int = 0, **extra: Any) -> dict[str, Any]:
            sid = stable_id("sid", tx)
            actor = "authority" if kind == "Revoke" else f"uav:{credential}"
            payload = _signed_payload(
                oracle,
                actor,
                kind,
                auth=auth,
                nf=nf,
                credential=credential,
                ctx=ctx,
                tx_id=tx,
                sid=sid,
                edge_id=edge,
                update_digest=digest,
                reservation_generation=generation,
                checkpoint=checkpoint,
                case_id=f"{scenario}-{index:04d}",
                **extra,
            )
            return payload

        if scenario == "S0":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 1, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 2, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 3, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 4, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
        elif scenario == "S1":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 0, "Request", msg("Request", tx_new, "edge-1"))
            add(base + 1, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 1, "Confirm", msg("Confirm", tx_new, "edge-1"))
            add(base + 2, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 2, "Commit", msg("Commit", tx_new, "edge-1"))
            add(base + 3, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 3, "UpdateAdmit", msg("UpdateAdmit", tx_new, "edge-1"))
            add(base + 4, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
            add(base + 4, "Aggregate", msg("Aggregate", tx_new, "edge-1"))
        elif scenario == "S2":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 1, "Abort", msg("Abort", tx_old, "edge-0", session_only=True))
            add(base + 2, "Retry", msg("Retry", tx_old, "edge-0", retry_target="Request"))
            add(base + 3, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 4, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 5, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 6, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
        elif scenario == "S3":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 1, "Revoke", msg("Revoke", tx_old, "authority"))
            add(base + 2, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 3, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 4, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 5, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
        elif scenario == "S4":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 1, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 2, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 2.1, "ReplyLost", msg("ReplyLost", tx_old, "edge-0"))
            add(base + 3, "Crash", msg("Crash", tx_old, "edge-0"))
            add(base + 5, "Restart", msg("Restart", tx_old, "edge-0"))
            add(base + 6, "Retry", msg("Retry", tx_old, "edge-0", retry_target="Commit"))
            add(base + 7, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 8, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
        elif scenario == "S5":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 5, "LeaseExpire", msg("LeaseExpire", tx_old, "edge-0", generation=1))
            add(base + 6, "Request", msg("Request", tx_new, "edge-1"))
            add(base + 7, "Confirm", msg("Confirm", tx_new, "edge-1"))
            add(base + 8, "Commit", msg("Commit", tx_new, "edge-1"))
            add(base + 9, "Confirm", msg("Confirm", tx_old, "edge-0", generation=1))
            add(base + 10, "Commit", msg("Commit", tx_old, "edge-0", generation=1))
            add(base + 11, "Abort", msg("Abort", tx_old, "edge-0", generation=1))
            add(base + 12, "UpdateAdmit", msg("UpdateAdmit", tx_new, "edge-1"))
            add(base + 13, "Aggregate", msg("Aggregate", tx_new, "edge-1"))
            add(base + 14, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 15, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
        elif scenario == "S6":
            add(base + 0, "Request", msg("Request", tx_old, "edge-0"))
            add(base + 1, "Confirm", msg("Confirm", tx_old, "edge-0"))
            add(base + 2, "Commit", msg("Commit", tx_old, "edge-0"))
            add(base + 3, "UpdateAdmit", msg("UpdateAdmit", tx_old, "edge-0"))
            add(base + 4, "Aggregate", msg("Aggregate", tx_old, "edge-0"))
            add(base + 5, "Crash", msg("Crash", tx_old, "edge-0"))
            add(base + 7, "Restart", msg("Restart", tx_old, "edge-0"))
            add(base + 8, "Retry", msg("Retry", tx_old, "edge-0", retry_target="UpdateAdmit"))
            add(base + 9, "Retry", msg("Retry", tx_old, "edge-0", retry_target="Aggregate"))

    actions.sort()
    schedule_material = [_action_dict(action) for action in actions]
    return Workload(scenario, seed, authorization_count, actions, auth_keys, stable_hash(schedule_material))


class StateSimulator:
    def __init__(
        self,
        *,
        variant: str,
        workload: Workload,
        run_id: str,
        attempt_id: str,
        config_hash: str,
        source_hash: str,
        lease_duration: float = 5.0,
        cutoff_per_case: float = 40.0,
        confirm_binding_enabled: bool = True,
    ):
        if variant not in VARIANTS:
            raise ValueError(f"unknown variant: {variant}")
        self.variant = variant
        self.workload = workload
        self.run_id = run_id
        self.attempt_id = attempt_id
        self.config_hash = config_hash
        self.source_hash = source_hash
        self.lease_duration = lease_duration
        self.cutoff_per_case = cutoff_per_case
        self.confirm_binding_enabled = confirm_binding_enabled
        self.oracle = IdealSignatureOracle(workload.seed)
        self.queue = list(copy.deepcopy(workload.actions))
        heapq.heapify(self.queue)
        self.events: list[dict[str, Any]] = []
        self.seq = 0

        self.global_nf: dict[str, dict[str, Any]] = {}
        self.local_nf: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
        self.generations: Counter[str] = Counter()
        self.sessions: dict[str, dict[str, dict[str, Any]]] = defaultdict(dict)
        self.revoked: set[str] = set()
        self.revocation_version = 0
        self.revoked_at: dict[str, float] = {}
        self.commit_records: dict[str, dict[str, Any]] = {}
        self.consumption_history: list[dict[str, Any]] = []
        self.update_ledger: dict[str, dict[str, Any]] = {}
        self.update_history: list[dict[str, Any]] = []
        self.aggregate_ledger: dict[tuple[str, str], dict[str, Any]] = {}
        self.aggregate_history: list[dict[str, Any]] = []
        self.retry_success: dict[str, float] = {}
        self.first_request_time: dict[str, float] = {}
        self.request_time_by_tx: dict[str, dict[str, float]] = defaultdict(dict)
        self.latest_request_time: dict[str, float] = {}
        self.retry_time: dict[str, float] = {}
        self.message_count = 0
        self.state_ops = 0
        self.handshakes = 0
        self.wrong_owner_state_changes = 0
        self.late_old_transaction_state_changes = 0
        self.rejection_reason_counts: Counter[str] = Counter()

    def _verified(self, payload: dict[str, Any], expected_kind: str | None = None) -> bool:
        fields = {key: value for key, value in payload.items() if key not in {"signer", "signature"}}
        if expected_kind is not None and fields.get("kind") != expected_kind:
            return False
        return self.oracle.verify(str(payload.get("signer", "")), fields, str(payload.get("signature", "")))

    def _snapshot(self, payload: dict[str, Any]) -> dict[str, Any]:
        nf = payload.get("nf", "")
        edge = payload.get("edge_id", "")
        tx = payload.get("tx_id", "")
        auth = payload.get("authorization_key", "")
        checkpoint = payload.get("checkpoint", "")
        return {
            "global_nf": copy.deepcopy(self.global_nf.get(nf)),
            "local_nf": copy.deepcopy(self.local_nf.get(edge, {}).get(nf)),
            "session": copy.deepcopy(self.sessions.get(edge, {}).get(tx)),
            "revoked": payload.get("credential_instance", "") in self.revoked,
            "commit_record": copy.deepcopy(self.commit_records.get(tx)),
            "update_record": copy.deepcopy(self.update_ledger.get(auth)),
            "aggregate_record": copy.deepcopy(self.aggregate_ledger.get((checkpoint, auth))),
        }

    def _base_outcome(self, *, result: str = "REJECTED", reason: str = "unspecified") -> dict[str, Any]:
        return {
            "result": result,
            "reason": reason,
            "message_count_delta": 0,
            "state_ops_delta": 0,
            "handshake_delta": 0,
            "new_consumption": False,
            "new_commit": False,
            "new_update": False,
            "new_aggregate": False,
            "state_mutation": False,
            "owner_authorized": True,
            "consumption_record_id": "",
            "commit_record_id": "",
            "update_admission_id": "",
            "update_validation_id": "",
            "contribution_id": "",
            "model_checkpoint_id": "",
            "retry_target": "",
            "late_old_transaction": False,
        }

    def _session_from_payload(self, payload: dict[str, Any], generation: int = 0) -> dict[str, Any]:
        return {
            "authorization_key": payload["authorization_key"],
            "authorization_ref": payload["authorization_key"],
            "nf": payload["nf"],
            "credential_instance": payload["credential_instance"],
            "ctx": payload["ctx"],
            "committed_context": payload["ctx"],
            "tx_id": payload["tx_id"],
            "request_id": payload["tx_id"],
            "owner": payload["tx_id"],
            "sid": payload["sid"],
            "edge_id": payload["edge_id"],
            "update_digest": payload["update_digest"],
            "checkpoint": payload["checkpoint"],
            "reservation_generation": generation,
            "confirmed": False,
        }

    def _consume_record(self, payload: dict[str, Any], sim_time: float, phase: str) -> dict[str, Any]:
        record_id = stable_id("consume", self.run_id, payload["tx_id"], len(self.consumption_history))
        record = {
            "record_id": record_id,
            "authorization_key": payload["authorization_key"],
            "nf": payload["nf"],
            "consumption_domain": (
                f"local_nf:{payload['edge_id']}" if self.variant == "B0_LOCAL_CACHE" else "global_nf"
            ),
            "tx_id": payload["tx_id"],
            "edge_id": payload["edge_id"],
            "phase": phase,
            "sim_time": sim_time,
        }
        self.consumption_history.append(record)
        return record

    def _request(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        out["message_count_delta"] = 1
        out["state_ops_delta"] = 1
        if not self._verified(payload, payload["kind"]):
            out["reason"] = "invalid_origin_or_integrity"
            return out
        credential = payload["credential_instance"]
        if credential in self.revoked:
            out["reason"] = "revoked"
            return out
        nf, tx, edge = payload["nf"], payload["tx_id"], payload["edge_id"]
        auth = payload["authorization_key"]
        self.request_time_by_tx[auth].setdefault(tx, sim_time)
        self.latest_request_time[auth] = max(sim_time, self.latest_request_time.get(auth, -math.inf))
        generation = 0
        if self.variant in {"B2_GENERIC_RCA", "B3_PAPER_ORDER"}:
            record = self.global_nf.get(nf)
            if record and record.get("status") == "PENDING" and record["lease_expires_at"] <= sim_time:
                self.global_nf.pop(nf)
                record = None
            if record is None:
                self.generations[nf] += 1
                generation = self.generations[nf]
                self.global_nf[nf] = {
                    "status": "PENDING",
                    "owner": tx,
                    "generation": generation,
                    "lease_expires_at": sim_time + self.lease_duration,
                }
                out.update(result="ACCEPTED", reason="reserved", state_mutation=True)
            elif record.get("status") == "PENDING" and record.get("owner") == tx:
                generation = int(record["generation"])
                out.update(result="IDEMPOTENT", reason="reservation_reused")
            else:
                out["reason"] = "nf_unavailable"
                return out
        elif self.variant == "B3_LEGACY_CONSUME_AT_REQUEST":
            if nf in self.global_nf:
                out["reason"] = "double_spending"
                return out
            consumed = self._consume_record(payload, sim_time, "request_verification")
            self.global_nf[nf] = {
                "status": "SPENT_PRECONFIRM",
                "owner": tx,
                "generation": 0,
                "consumption_record_id": consumed["record_id"],
            }
            out.update(
                result="ACCEPTED",
                reason="nf_consumed_at_request",
                new_consumption=True,
                state_mutation=True,
                consumption_record_id=consumed["record_id"],
            )
        else:
            out.update(result="ACCEPTED", reason="request_validated")
        self.sessions[edge][tx] = self._session_from_payload(payload, generation)
        self.first_request_time.setdefault(payload["authorization_key"], sim_time)
        return out

    def _confirm(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        if not self._verified(payload, payload["kind"]):
            out["reason"] = "invalid_origin_or_integrity"
            return out
        session = self.sessions.get(payload["edge_id"], {}).get(payload["tx_id"])
        if not session:
            out["reason"] = "no_live_session"
            return out
        required = (
            "authorization_key",
            "nf",
            "credential_instance",
            "ctx",
            "tx_id",
            "sid",
            "edge_id",
            "update_digest",
            "checkpoint",
        )
        if self.confirm_binding_enabled and any(session[key] != payload[key] for key in required):
            out["reason"] = "confirm_transaction_mismatch"
            return out
        if self.variant in {"B2_GENERIC_RCA", "B3_PAPER_ORDER"}:
            record = self.global_nf.get(payload["nf"])
            generation = int(session.get("reservation_generation", 0))
            if not record or record.get("status") != "PENDING":
                out["reason"] = "no_live_reservation"
                return out
            if record.get("owner") != payload["tx_id"] or int(record.get("generation", -1)) != generation:
                out.update(reason="reservation_owner_or_generation_mismatch", owner_authorized=False)
                return out
            if float(record["lease_expires_at"]) <= sim_time:
                out["reason"] = "reservation_expired"
                return out
        if session["confirmed"]:
            out.update(result="IDEMPOTENT", reason="already_confirmed")
            return out
        session["confirmed"] = True
        self.handshakes += 1
        out.update(result="ACCEPTED", reason="confirmed", handshake_delta=1, state_mutation=True)
        return out

    def _make_commit(self, session: dict[str, Any], sim_time: float, consumption_id: str) -> dict[str, Any]:
        commit_id = stable_id("commit", self.run_id, session["tx_id"])
        record = {
            "record_id": commit_id,
            "commit_record_id": commit_id,
            "authorization_key": session["authorization_key"],
            "authorization_ref": session["authorization_key"],
            "nf": session["nf"],
            "consumption_domain": "global_nf" if self.variant != "B0_LOCAL_CACHE" else f"local_nf:{session['edge_id']}",
            "credential_instance": session["credential_instance"],
            "tx_id": session["tx_id"],
            "request_id": session["tx_id"],
            "sid": session["sid"],
            "owner": session["owner"],
            "generation": int(session["reservation_generation"]),
            "edge_id": session["edge_id"],
            "ctx": session["ctx"],
            "committed_context": session["ctx"],
            "update_digest": session["update_digest"],
            "checkpoint": session["checkpoint"],
            "consumption_record_id": consumption_id,
            "sim_time": sim_time,
        }
        self.commit_records[session["tx_id"]] = record
        return record

    def _commit(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        out.update(message_count_delta=1, state_ops_delta=1)
        if not self._verified(payload, payload["kind"]):
            out["reason"] = "invalid_origin_or_integrity"
            return out
        tx = payload["tx_id"]
        existing_commit = self.commit_records.get(tx)
        if existing_commit:
            existing_binding = {
                "authorization_key": "authorization_key",
                "nf": "nf",
                "credential_instance": "credential_instance",
                "ctx": "ctx",
                "tx_id": "tx_id",
                "sid": "sid",
                "edge_id": "edge_id",
                "update_digest": "update_digest",
                "checkpoint": "checkpoint",
            }
            if any(existing_commit[record_key] != payload[payload_key] for payload_key, record_key in existing_binding.items()):
                out["reason"] = "existing_commit_binding_mismatch"
                return out
            out.update(
                result="IDEMPOTENT",
                reason="same_commit_result",
                commit_record_id=existing_commit["record_id"],
            )
            return out
        session = self.sessions.get(payload["edge_id"], {}).get(tx)
        if not session or not session.get("confirmed"):
            out["reason"] = "confirmation_required"
            return out
        commit_fields = (
            "authorization_key",
            "nf",
            "credential_instance",
            "ctx",
            "tx_id",
            "sid",
            "edge_id",
            "update_digest",
            "checkpoint",
        )
        if any(session[key] != payload[key] for key in commit_fields):
            out["reason"] = "commit_confirmed_session_mismatch"
            return out
        credential = payload["credential_instance"]
        if credential in self.revoked:
            out["reason"] = "revoked_at_commit"
            return out
        nf, edge = payload["nf"], payload["edge_id"]
        consumption_id = ""
        if self.variant == "B0_LOCAL_CACHE":
            record = self.local_nf[edge].get(nf)
            if record is not None:
                out["reason"] = "local_nf_spent"
                return out
            consumed = self._consume_record(payload, sim_time, "local_commit")
            consumption_id = consumed["record_id"]
            self.local_nf[edge][nf] = {"status": "SPENT", "owner": tx, "consumption_record_id": consumption_id}
            out.update(new_consumption=True, consumption_record_id=consumption_id)
        elif self.variant == "B1_ATOMIC_AFTER_CONFIRM":
            if nf in self.global_nf:
                out["reason"] = "global_nf_spent"
                return out
            consumed = self._consume_record(payload, sim_time, "atomic_after_confirm")
            consumption_id = consumed["record_id"]
            self.global_nf[nf] = {"status": "SPENT", "owner": tx, "generation": 0, "consumption_record_id": consumption_id}
            out.update(new_consumption=True, consumption_record_id=consumption_id)
        elif self.variant in {"B2_GENERIC_RCA", "B3_PAPER_ORDER"}:
            record = self.global_nf.get(nf)
            generation = int(session.get("reservation_generation", 0))
            if not record or record.get("status") != "PENDING":
                out["reason"] = "no_live_reservation"
                return out
            if record.get("owner") != tx or int(record.get("generation", -1)) != generation:
                out.update(reason="reservation_owner_or_generation_mismatch", owner_authorized=False)
                return out
            if float(record["lease_expires_at"]) <= sim_time:
                out["reason"] = "reservation_expired"
                return out
            phase = "paper_reserve_confirm_commit" if self.variant == "B3_PAPER_ORDER" else "reserve_confirm_commit"
            consumed = self._consume_record(payload, sim_time, phase)
            consumption_id = consumed["record_id"]
            self.global_nf[nf] = {
                "status": "SPENT",
                "owner": tx,
                "generation": generation,
                "consumption_record_id": consumption_id,
            }
            out.update(new_consumption=True, consumption_record_id=consumption_id)
        elif self.variant == "B3_LEGACY_CONSUME_AT_REQUEST":
            record = self.global_nf.get(nf)
            if not record or record.get("status") != "SPENT_PRECONFIRM" or record.get("owner") != tx:
                out["reason"] = "no_matching_preconfirm_consumption"
                return out
            consumption_id = str(record["consumption_record_id"])
            record["status"] = "SPENT"
        else:
            raise AssertionError(f"unhandled variant: {self.variant}")
        commit = self._make_commit(session, sim_time, consumption_id)
        auth = payload["authorization_key"]
        tx_request_time = self.request_time_by_tx.get(auth, {}).get(tx, sim_time)
        is_late_old = any(
            other_tx != tx and other_time > tx_request_time
            for other_tx, other_time in self.request_time_by_tx.get(auth, {}).items()
        )
        if is_late_old:
            self.late_old_transaction_state_changes += 1
        out.update(
            result="ACCEPTED",
            reason="commit_effective",
            new_commit=True,
            state_mutation=True,
            commit_record_id=commit["record_id"],
            late_old_transaction=is_late_old,
        )
        return out

    def _abort(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        del sim_time
        out = self._base_outcome()
        if not self._verified(payload, payload["kind"]):
            out["reason"] = "invalid_origin_or_integrity"
            return out
        edge, tx, nf = payload["edge_id"], payload["tx_id"], payload["nf"]
        session = self.sessions.get(edge, {}).get(tx)
        if payload.get("session_only"):
            self.sessions.get(edge, {}).pop(tx, None)
            out.update(result="ACCEPTED", reason="handshake_interrupted_session_cleared", state_mutation=bool(session))
            return out
        if self.variant not in {"B2_GENERIC_RCA", "B3_PAPER_ORDER"}:
            out.update(result="NO_EFFECT", reason="variant_has_no_reservation_abort")
            return out
        out["message_count_delta"] = 1
        out["state_ops_delta"] = 1
        record = self.global_nf.get(nf)
        generation = int(session.get("reservation_generation", 0) if session else payload.get("reservation_generation", 0))
        if not record or record.get("status") != "PENDING":
            out.update(result="NO_EFFECT", reason="no_pending_reservation")
            return out
        if record.get("owner") != tx or int(record.get("generation", -1)) != generation:
            out.update(reason="abort_owner_or_generation_mismatch", owner_authorized=False)
            return out
        self.global_nf.pop(nf)
        out.update(result="ACCEPTED", reason="reservation_aborted", state_mutation=True)
        return out

    def _lease_expire(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        if self.variant not in {"B2_GENERIC_RCA", "B3_PAPER_ORDER"}:
            out.update(result="NO_EFFECT", reason="variant_has_no_lease")
            return out
        out["state_ops_delta"] = 1
        record = self.global_nf.get(payload["nf"])
        if not record or record.get("status") != "PENDING":
            out.update(result="NO_EFFECT", reason="no_pending_reservation")
            return out
        requested_generation = int(payload.get("reservation_generation", 0))
        if int(record.get("generation", -1)) != requested_generation:
            out.update(result="NO_EFFECT", reason="stale_expiry_generation")
            return out
        if float(record["lease_expires_at"]) > sim_time:
            out.update(result="NO_EFFECT", reason="lease_not_expired")
            return out
        self.global_nf.pop(payload["nf"])
        out.update(result="ACCEPTED", reason="lease_expired", state_mutation=True)
        return out

    def _revoke(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        out.update(message_count_delta=1, state_ops_delta=1)
        if not self._verified(payload, payload["kind"]) or payload.get("signer") != "authority":
            out["reason"] = "invalid_authority_origin"
            return out
        credential = payload["credential_instance"]
        if credential in self.revoked:
            out.update(result="IDEMPOTENT", reason="already_revoked")
            return out
        self.revoked.add(credential)
        self.revocation_version += 1
        self.revoked_at[credential] = sim_time
        out.update(result="ACCEPTED", reason="revocation_linearized", state_mutation=True)
        return out

    def _update(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        out.update(message_count_delta=1, state_ops_delta=1)
        if not self._verified(payload, payload["kind"]):
            out["reason"] = "invalid_origin_or_integrity"
            return out
        commit = self.commit_records.get(payload["tx_id"])
        if not commit:
            out["reason"] = "commit_required"
            return out
        for key in (
            "authorization_key",
            "nf",
            "credential_instance",
            "tx_id",
            "sid",
            "edge_id",
            "ctx",
            "update_digest",
            "checkpoint",
        ):
            if commit[key] != payload[key]:
                out["reason"] = "authorization_update_binding_mismatch"
                return out
        auth = payload["authorization_key"]
        existing = self.update_ledger.get(auth)
        if existing:
            if existing["update_digest"] == payload["update_digest"]:
                out.update(
                    result="IDEMPOTENT",
                    reason="update_replay_deduplicated",
                    update_admission_id=existing["record_id"],
                    update_validation_id=existing["update_validation_id"],
                )
            else:
                out["reason"] = "conflicting_update_for_authorization"
            return out
        validation_id = stable_id("validate", self.run_id, commit["record_id"], payload["update_digest"])
        record = {
            "record_id": stable_id("admit", self.run_id, auth),
            "update_admission_id": stable_id("admit", self.run_id, auth),
            "update_validation_id": validation_id,
            "commit_record_id": commit["record_id"],
            "consumption_record_id": commit["consumption_record_id"],
            "authorization_key": auth,
            "authorization_ref": auth,
            "nf": payload["nf"],
            "consumption_domain": commit["consumption_domain"],
            "request_id": payload["tx_id"],
            "sid": payload["sid"],
            "owner": commit["owner"],
            "generation": commit["generation"],
            "committed_context": payload["ctx"],
            "update_digest": payload["update_digest"],
            "checkpoint": payload["checkpoint"],
            "tx_id": payload["tx_id"],
            "sim_time": sim_time,
        }
        self.update_ledger[auth] = record
        self.update_history.append(record)
        out.update(
            result="ACCEPTED",
            reason="update_admitted",
            new_update=True,
            state_mutation=True,
            update_admission_id=record["record_id"],
            update_validation_id=record["update_validation_id"],
        )
        return out

    def _aggregate(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        out = self._base_outcome()
        out["state_ops_delta"] = 1
        auth, checkpoint = payload["authorization_key"], payload["checkpoint"]
        update = self.update_ledger.get(auth)
        if (
            not update
            or update["update_digest"] != payload["update_digest"]
            or update["checkpoint"] != checkpoint
        ):
            out["reason"] = "admitted_update_required"
            return out
        key = (checkpoint, auth)
        existing = self.aggregate_ledger.get(key)
        if existing:
            out.update(
                result="IDEMPOTENT",
                reason="aggregate_replay_deduplicated",
                contribution_id=existing["contribution_id"],
                model_checkpoint_id=checkpoint,
            )
            return out
        record = {
            "contribution_id": stable_id("contribution", self.run_id, checkpoint, auth),
            "authorization_key": auth,
            "authorization_ref": auth,
            "update_digest": payload["update_digest"],
            "checkpoint": checkpoint,
            "update_admission_id": update["record_id"],
            "update_validation_id": update["update_validation_id"],
            "commit_record_id": update["commit_record_id"],
            "sim_time": sim_time,
        }
        self.aggregate_ledger[key] = record
        self.aggregate_history.append(record)
        out.update(
            result="ACCEPTED",
            reason="contribution_aggregated",
            new_aggregate=True,
            state_mutation=True,
            contribution_id=record["contribution_id"],
            model_checkpoint_id=checkpoint,
        )
        return out

    def _crash(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        del sim_time
        edge = payload["edge_id"]
        cleared = len(self.sessions.get(edge, {}))
        self.sessions[edge].clear()
        out = self._base_outcome(result="ACCEPTED", reason="volatile_sessions_cleared")
        out.update(state_mutation=bool(cleared), cleared_sessions=cleared)
        return out

    def _restart(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        del payload, sim_time
        return self._base_outcome(result="ACCEPTED", reason="durable_records_only_loaded")

    def _retry(self, payload: dict[str, Any], sim_time: float) -> dict[str, Any]:
        target = payload.get("retry_target", "")
        delegated = dict(payload)
        delegated["kind"] = target
        delegated["signature"] = self.oracle.sign(delegated["signer"], {k: v for k, v in delegated.items() if k not in {"signer", "signature"}})
        if target == "Request":
            out = self._request(delegated, sim_time)
        elif target == "Commit":
            out = self._commit(delegated, sim_time)
        elif target == "UpdateAdmit":
            out = self._update(delegated, sim_time)
        elif target == "Aggregate":
            out = self._aggregate(delegated, sim_time)
        else:
            out = self._base_outcome(reason="unknown_retry_target")
        out["retry_target"] = target
        auth = payload["authorization_key"]
        self.retry_time.setdefault(auth, sim_time)
        if out["result"] in {"ACCEPTED", "IDEMPOTENT"}:
            self.retry_success.setdefault(auth, sim_time)
        return out

    def _process(self, action: Action) -> dict[str, Any]:
        handlers = {
            "Request": self._request,
            "Confirm": self._confirm,
            "Commit": self._commit,
            "Abort": self._abort,
            "LeaseExpire": self._lease_expire,
            "Revoke": self._revoke,
            "UpdateAdmit": self._update,
            "Aggregate": self._aggregate,
            "Crash": self._crash,
            "Restart": self._restart,
            "Retry": self._retry,
            "ReplyLost": lambda payload, sim_time: self._base_outcome(result="ACCEPTED", reason="reply_dropped_by_schedule"),
        }
        if action.kind not in handlers:
            return self._base_outcome(reason="unknown_event_type")
        return handlers[action.kind](action.payload, action.sim_time)

    def _log(self, action: Action, before: dict[str, Any], after: dict[str, Any], out: dict[str, Any]) -> None:
        self.seq += 1
        payload = action.payload
        event_id = f"{self.run_id}:{self.seq}"
        row = {
            "run_id": self.run_id,
            "attempt_id": self.attempt_id,
            "config_hash": self.config_hash,
            "source_hash": self.source_hash,
            "seed": self.workload.seed,
            "scenario": self.workload.scenario,
            "variant": self.variant,
            "event_seq": self.seq,
            "event_id": event_id,
            "sim_time": action.sim_time,
            "request_id": payload.get("tx_id", ""),
            "authorization_key": payload.get("authorization_key", ""),
            "nf": payload.get("nf", ""),
            "sid": payload.get("sid", ""),
            "edge_id": payload.get("edge_id", ""),
            "reservation_generation": (
                (after.get("session") or {}).get("reservation_generation", payload.get("reservation_generation", 0))
            ),
            "revocation_version": self.revocation_version,
            "update_digest": payload.get("update_digest", ""),
            "event_type": action.kind,
            "state_before": before,
            "state_after": after,
            "result": out["result"],
            "reason": out["reason"],
            "parent_event_id": action.parent_event_id,
            "case_id": payload.get("case_id", ""),
            "warrant_id": payload.get("warrant_id", ""),
            "commit_record_id": out.get("commit_record_id", ""),
            "update_admission_id": out.get("update_admission_id", ""),
            "update_validation_id": out.get("update_validation_id", ""),
            "contribution_id": out.get("contribution_id", ""),
            "model_checkpoint_id": out.get("model_checkpoint_id", ""),
            "credential_instance": payload.get("credential_instance", ""),
            "checkpoint": payload.get("checkpoint", ""),
            "context": payload.get("ctx", ""),
            "new_consumption": bool(out.get("new_consumption")),
            "new_commit": bool(out.get("new_commit")),
            "new_update": bool(out.get("new_update")),
            "new_aggregate": bool(out.get("new_aggregate")),
            "state_mutation": bool(out.get("state_mutation")),
            "owner_authorized": bool(out.get("owner_authorized", True)),
            "consumption_record_id": out.get("consumption_record_id", ""),
            "retry_target": out.get("retry_target", ""),
            "late_old_transaction": bool(out.get("late_old_transaction")),
            "message_count_delta": int(out.get("message_count_delta", 0)),
            "state_ops_delta": int(out.get("state_ops_delta", 0)),
            "handshake_delta": int(out.get("handshake_delta", 0)),
            "schedule_hash": self.workload.schedule_hash,
            "ideal_crypto": True,
            "real_sm2": False,
        }
        missing = [key for key in REQUIRED_EVENT_FIELDS if key not in row]
        if missing:
            raise AssertionError(f"event is missing required fields: {missing}")
        self.message_count += row["message_count_delta"]
        self.state_ops += row["state_ops_delta"]
        if row["result"] == "REJECTED":
            self.rejection_reason_counts[row["reason"]] += 1
        self.events.append(row)

    def _log_boundary(self, kind: str, sim_time: float, metadata: dict[str, Any]) -> None:
        action = Action(sim_time, -1 if kind == "RunStart" else 10**12, kind, metadata)
        before: dict[str, Any] = {}
        out = self._base_outcome(result="ACCEPTED", reason=kind.lower())
        self._log(action, before, {}, out)

    @staticmethod
    def _rate(numerator: int, denominator: int) -> float | None:
        return numerator / denominator if denominator else None

    @staticmethod
    def _mean(values: Iterable[float]) -> float | None:
        materialized = list(values)
        return sum(materialized) / len(materialized) if materialized else None

    def _online_metrics(self) -> dict[str, Any]:
        authorization_keys = set(self.workload.authorization_keys)
        consumption_counts = Counter(item["authorization_key"] for item in self.consumption_history)
        update_counts = Counter(item["authorization_key"] for item in self.update_history)
        aggregate_counts = Counter(item["authorization_key"] for item in self.aggregate_history)
        successful = {item["authorization_key"] for item in self.aggregate_history}
        retry_auth = set(self.retry_time)
        completion_times: list[float] = []
        for auth in successful:
            first = self.first_request_time.get(auth)
            finished = min(item["sim_time"] for item in self.aggregate_history if item["authorization_key"] == auth)
            if first is not None:
                completion_times.append(finished - first)
        recovery_times = [self.retry_success[auth] - self.retry_time[auth] for auth in retry_auth & set(self.retry_success)]
        revoked_commit_accepts = sum(
            record["credential_instance"] in self.revoked_at
            and record["sim_time"] >= self.revoked_at[record["credential_instance"]]
            for record in self.commit_records.values()
        )
        success_count = len(successful)
        metrics = {
            "event_total": len(self.events) + 1,
            "authorization_instances": len(authorization_keys),
            "duplicate_consumption_instances": sum(count > 1 for count in consumption_counts.values()),
            "DS_commit": sum(count > 1 for count in consumption_counts.values()),
            "DS_update": sum(count > 1 for count in update_counts.values()),
            "DS_aggregate": sum(count > 1 for count in aggregate_counts.values()),
            "distinct_successful_contributions": success_count,
            "legal_completion_rate": self._rate(success_count, len(authorization_keys)),
            "failure_count": len(authorization_keys) - success_count,
            "failure_rate": self._rate(len(authorization_keys) - success_count, len(authorization_keys)),
            "revoked_commit_accepts": revoked_commit_accepts,
            "wrong_owner_state_changes": self.wrong_owner_state_changes,
            "late_old_transaction_state_changes": self.late_old_transaction_state_changes,
            "retry_instances": len(retry_auth),
            "recovery_successes": len(retry_auth & set(self.retry_success)),
            "recovery_completion_rate": self._rate(len(retry_auth & set(self.retry_success)), len(retry_auth)),
            "messages": self.message_count,
            "state_operations": self.state_ops,
            "handshakes": self.handshakes,
            "messages_per_success": self._rate(self.message_count, success_count),
            "state_operations_per_success": self._rate(self.state_ops, success_count),
            "handshakes_per_success": self._rate(self.handshakes, success_count),
            "mean_completion_latency_sim_units": self._mean(completion_times),
            "mean_recovery_latency_sim_units": self._mean(recovery_times),
            "cutoff_sim_units": self.cutoff_per_case,
            "simulation_time_unit": "logical_event_unit",
            "event_denominators": {
                "commit_consumptions": len(self.consumption_history),
                "update_admissions": len(self.update_history),
                "aggregate_contributions": len(self.aggregate_history),
            },
            "rejection_reason_counts": dict(sorted(self.rejection_reason_counts.items())),
        }
        return metrics

    def run(self) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        self._log_boundary(
            "RunStart",
            -1.0,
            {
                "authorization_key": "",
                "tx_id": "",
                "nf": "",
                "sid": "",
                "edge_id": "",
                "update_digest": "",
                "authorization_count": self.workload.authorization_count,
                "schedule_hash": self.workload.schedule_hash,
            },
        )
        while self.queue:
            action = heapq.heappop(self.queue)
            before = self._snapshot(action.payload)
            out = self._process(action)
            if out.get("state_mutation") and not out.get("owner_authorized", True):
                self.wrong_owner_state_changes += 1
            after = self._snapshot(action.payload)
            self._log(action, before, after, out)
        metrics = self._online_metrics()
        self._log_boundary(
            "RunEnd",
            float(self.workload.authorization_count * 50),
            {
                "authorization_key": "",
                "tx_id": "",
                "nf": "",
                "sid": "",
                "edge_id": "",
                "update_digest": "",
                "expected_event_count": metrics["event_total"],
                "schedule_hash": self.workload.schedule_hash,
            },
        )
        if metrics["event_total"] != len(self.events):
            raise AssertionError("online expected event count mismatch")
        summary = {
            "run_id": self.run_id,
            "attempt_id": self.attempt_id,
            "seed": self.workload.seed,
            "scenario": self.workload.scenario,
            "variant": self.variant,
            "schedule_hash": self.workload.schedule_hash,
            "config_hash": self.config_hash,
            "source_hash": self.source_hash,
            "RUN_STATUS": "COMPLETED",
            "METHOD_VALIDITY": "VALID",
            "CLAIM_OUTCOME": "NOT_ASSESSED",
            "online_metrics": metrics,
        }
        return self.events, summary


def run_state_simulation(
    *,
    variant: str,
    workload: Workload,
    run_id: str,
    attempt_id: str,
    config_hash: str,
    source_hash: str,
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    return StateSimulator(
        variant=variant,
        workload=workload,
        run_id=run_id,
        attempt_id=attempt_id,
        config_hash=config_hash,
        source_hash=source_hash,
    ).run()
