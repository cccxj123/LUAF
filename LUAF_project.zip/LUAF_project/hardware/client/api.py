from __future__ import annotations

import json
import os
import time
import uuid
from dataclasses import dataclass
from typing import Any, Callable

import requests

from app.contract import authorization_instance_id, canonical_json, test_signature


@dataclass
class CallResult:
    endpoint: str
    request: dict[str, Any]
    response: dict[str, Any] | None
    http_status: int | None
    elapsed_ns: int
    error: str

    def as_dict(self) -> dict[str, Any]:
        return {
            "endpoint": self.endpoint,
            "request_id": self.request.get("request_id", ""),
            "variant": self.request.get("variant", ""),
            "nf": self.request.get("nf", ""),
            "aid": self.request.get("aid", ""),
            "sid": self.request.get("sid", ""),
            "owner_edge": self.request.get("owner_edge", ""),
            "generation": self.request.get("generation", 0),
            "bound_update_digest": self.request.get("bound_update_digest", ""),
            "http_status": self.http_status,
            "elapsed_ns": self.elapsed_ns,
            "error": self.error,
            "response": self.response,
            "request": dict(self.request),
        }


class ApiClient:
    def __init__(self, base_url: str, timeout_s: float = 10.0,
                 on_call: Callable[[CallResult], None] | None = None):
        self.base_url = base_url.rstrip("/")
        self.timeout_s = timeout_s
        self.key = os.environ.get("LUAF_TEST_HMAC_KEY", "")
        if not self.key:
            raise RuntimeError("LUAF_TEST_HMAC_KEY is required")
        self.session = requests.Session()
        self.session.trust_env = False
        self.on_call = on_call

    def post(
        self, endpoint: str, payload: dict[str, Any], timeout_s: float | None = None
    ) -> CallResult:
        # Each HTTP attempt is distinct; the authorization identity is unchanged.
        payload = dict(payload)
        payload["request_id"] = f"{payload['request_id']}:{endpoint.strip('/')}:{uuid.uuid4().hex}"
        body = canonical_json(payload)
        headers = {
            "Content-Type": "application/json",
            "X-Test-Signature": test_signature(self.key, body),
        }
        started = time.perf_counter_ns()
        try:
            response = self.session.post(
                self.base_url + endpoint,
                data=body,
                headers=headers,
                timeout=self.timeout_s if timeout_s is None else timeout_s,
                allow_redirects=False,
            )
            elapsed = time.perf_counter_ns() - started
            try:
                decoded = response.json()
            except (json.JSONDecodeError, ValueError):
                decoded = {"parse_error": "response_is_not_json"}
            if not isinstance(decoded, dict):
                decoded = {"parse_error": "response_is_not_json_object"}
            result = CallResult(
                endpoint, payload, decoded, response.status_code, elapsed, ""
            )
        except requests.RequestException as exc:
            result = CallResult(
                endpoint,
                payload,
                None,
                None,
                time.perf_counter_ns() - started,
                type(exc).__name__,
            )
        if self.on_call is not None:
            self.on_call(result)
        return result


def authorization(
    *,
    tag: str,
    variant: str,
    nf: str,
    owner_edge: str,
    sid: str | None = None,
    digest_tag: str | None = None,
    lease_ms: int = 1500,
) -> dict[str, Any]:
    digest_label = digest_tag or tag
    payload: dict[str, Any] = {
        "request_id": tag,
        "variant": variant,
        "nf": nf,
        "aid": "pending",
        "sid": sid or f"sid-{tag}-{owner_edge}",
        "owner_edge": owner_edge,
        "generation": 0,
        "credential_commitment": f"cred-{tag}",
        "slot": f"slot-{tag}",
        "context": f"ctx-{tag}",
        "one_time_key_ref": f"otk-{tag}",
        "bound_update_digest": f"sha256-update-{digest_label}",
        "lease_ms": lease_ms,
    }
    payload["aid"] = authorization_instance_id(payload)
    return payload


def state_payload(auth: dict[str, Any], **extra: Any) -> dict[str, Any]:
    result = {
        key: auth[key]
        for key in (
            "request_id",
            "variant",
            "nf",
            "aid",
            "sid",
            "owner_edge",
            "generation",
            "bound_update_digest",
        )
    }
    result.update(extra)
    return result


def set_generation(auth: dict[str, Any], response: dict[str, Any] | None) -> None:
    if response and isinstance(response.get("generation"), int):
        auth["generation"] = response["generation"]
