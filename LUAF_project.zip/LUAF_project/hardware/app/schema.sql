PRAGMA journal_mode=WAL;
PRAGMA synchronous=FULL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS nf_state (
    nf TEXT PRIMARY KEY,
    variant TEXT NOT NULL,
    aid TEXT NOT NULL,
    sid TEXT NOT NULL,
    owner_edge TEXT NOT NULL,
    generation INTEGER NOT NULL CHECK (generation > 0),
    state TEXT NOT NULL CHECK (state IN ('PENDING','CONFIRMED','SPENT')),
    lease_expires_ns INTEGER NOT NULL,
    credential_commitment TEXT NOT NULL,
    slot TEXT NOT NULL,
    context TEXT NOT NULL,
    one_time_key_ref TEXT NOT NULL,
    bound_update_digest TEXT NOT NULL,
    updated_ns INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS commit_record (
    commit_record_id TEXT PRIMARY KEY,
    variant TEXT NOT NULL,
    nf TEXT NOT NULL,
    aid TEXT NOT NULL,
    sid TEXT NOT NULL,
    owner_edge TEXT NOT NULL,
    generation INTEGER NOT NULL,
    bound_update_digest TEXT NOT NULL,
    created_ns INTEGER NOT NULL,
    UNIQUE(nf, generation),
    FOREIGN KEY(nf) REFERENCES nf_state(nf)
);

CREATE TABLE IF NOT EXISTS update_admission (
    update_admission_id TEXT PRIMARY KEY,
    variant TEXT NOT NULL,
    nf TEXT NOT NULL,
    aid TEXT NOT NULL,
    sid TEXT NOT NULL,
    owner_edge TEXT NOT NULL,
    generation INTEGER NOT NULL,
    bound_update_digest TEXT NOT NULL,
    commit_record_id TEXT NOT NULL UNIQUE,
    created_ns INTEGER NOT NULL,
    FOREIGN KEY(commit_record_id) REFERENCES commit_record(commit_record_id)
);

CREATE TABLE IF NOT EXISTS contribution (
    contribution_id TEXT PRIMARY KEY,
    variant TEXT NOT NULL,
    nf TEXT NOT NULL,
    aid TEXT NOT NULL,
    sid TEXT NOT NULL,
    owner_edge TEXT NOT NULL,
    generation INTEGER NOT NULL,
    bound_update_digest TEXT NOT NULL,
    commit_record_id TEXT NOT NULL,
    update_admission_id TEXT NOT NULL UNIQUE,
    created_ns INTEGER NOT NULL,
    FOREIGN KEY(commit_record_id) REFERENCES commit_record(commit_record_id),
    FOREIGN KEY(update_admission_id) REFERENCES update_admission(update_admission_id)
);

CREATE TABLE IF NOT EXISTS revocation_state (
    credential_commitment TEXT PRIMARY KEY,
    revoked_ns INTEGER NOT NULL,
    request_id TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS event_outbox (
    event_seq INTEGER PRIMARY KEY AUTOINCREMENT,
    event_json TEXT NOT NULL,
    created_ns INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_event_created ON event_outbox(created_ns);
CREATE INDEX IF NOT EXISTS idx_commit_nf ON commit_record(nf);
CREATE INDEX IF NOT EXISTS idx_admit_nf ON update_admission(nf);
CREATE INDEX IF NOT EXISTS idx_contribution_nf ON contribution(nf);

