from __future__ import annotations

import json
import os
import sqlite3
import threading
from pathlib import Path
from typing import Any


_export_lock = threading.Lock()


def db_path() -> Path:
    return Path(os.environ.get("LUAF_DB_PATH", "data/state.sqlite3")).resolve()


def events_path() -> Path:
    return Path(os.environ.get("LUAF_EVENTS_PATH", "data/hardware_events.jsonl")).resolve()


def connect() -> sqlite3.Connection:
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=30.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=30000")
    return conn


def initialize() -> None:
    schema = Path(__file__).with_name("schema.sql").read_text(encoding="utf-8")
    with connect() as conn:
        conn.executescript(schema)
    export_events()


def insert_event(conn: sqlite3.Connection, event: dict[str, Any]) -> int:
    cursor = conn.execute(
        "INSERT INTO event_outbox(event_json, created_ns) VALUES(?, ?)",
        (json.dumps(event, ensure_ascii=False, sort_keys=True), event["server_time_ns"]),
    )
    return int(cursor.lastrowid)


def append_committed_event(event_seq: int) -> None:
    """Append one already-committed event to the non-authoritative projection."""
    with _export_lock:
        with connect() as conn:
            row = conn.execute(
                "SELECT event_json FROM event_outbox WHERE event_seq=?", (event_seq,)
            ).fetchone()
        if row is None:
            return
        event = json.loads(row["event_json"])
        event["event_seq"] = event_seq
        target = events_path()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("a", encoding="utf-8", newline="\n") as out:
            out.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")


def export_events() -> None:
    """Rewrite the JSONL projection from committed outbox rows.

    The outbox is authoritative. This routine is called only after a database
    commit, so a JSONL write can never announce success before durable state.
    """
    with _export_lock:
        target = events_path()
        target.parent.mkdir(parents=True, exist_ok=True)
        tmp = target.with_suffix(target.suffix + ".tmp")
        with connect() as conn, tmp.open("w", encoding="utf-8", newline="\n") as out:
            for row in conn.execute(
                "SELECT event_seq, event_json FROM event_outbox ORDER BY event_seq"
            ):
                event = json.loads(row["event_json"])
                event["event_seq"] = row["event_seq"]
                out.write(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n")
        os.replace(tmp, target)


def row_dict(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None
