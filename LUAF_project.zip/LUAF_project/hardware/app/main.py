from __future__ import annotations

import os
import sqlite3
import time
import uuid
from contextlib import asynccontextmanager
from typing import Any

import psutil
from fastapi import Depends, FastAPI, Header, HTTPException, Request

from .contract import (
    CONTRACT_VARIANTS,
    SERVER_VARIANTS,
    authorization_instance_id,
    stable_id,
    verify_test_signature,
)
from .database import (
    append_committed_event,
    connect,
    db_path,
    export_events,
    initialize,
    insert_event,
    row_dict,
)
from .models import (
    AdmitRequest,
    CommitRequest,
    ContributionRequest,
    ReserveRequest,
    RevokeRequest,
    StateRequest,
)


PROCESS = psutil.Process()
BOOT_ID = uuid.uuid4().hex
PROCESS.cpu_percent(None)


async def authenticate(
    request: Request, x_test_signature: str = Header(default="")
) -> None:
    key = os.environ.get("LUAF_TEST_HMAC_KEY", "")
    body = await request.body()
    if not verify_test_signature(key, body, x_test_signature):
        raise HTTPException(status_code=401, detail="invalid_test_hmac")


def _validate_variant(variant: str) -> None:
    if variant not in SERVER_VARIANTS:
        raise HTTPException(status_code=422, detail="unsupported_variant")


def _base(
    payload: Any,
    *,
    operation: str,
    state_before: str,
    state_after: str,
    result: str,
    reason: str,
    started_ns: int,
    commit_record_id: str = "",
    update_admission_id: str = "",
    contribution_id: str = "",
    sqlite_write_count: int = 1,
) -> dict[str, Any]:
    now = time.time_ns()
    return {
        "attempt_id": os.environ.get("LUAF_ATTEMPT_ID", ""),
        "request_id": getattr(payload, "request_id", ""),
        "variant": getattr(payload, "variant", ""),
        "nf": getattr(payload, "nf", ""),
        "aid": getattr(payload, "aid", ""),
        "sid": getattr(payload, "sid", ""),
        "owner_edge": getattr(payload, "owner_edge", ""),
        "generation": int(getattr(payload, "generation", 0)),
        "bound_update_digest": getattr(payload, "bound_update_digest", ""),
        "operation": operation,
        "state_before": state_before,
        "state_after": state_after,
        "commit_record_id": commit_record_id,
        "update_admission_id": update_admission_id,
        "contribution_id": contribution_id,
        "result": result,
        "reason": reason,
        "server_time_ns": now,
        "server_processing_ns": time.perf_counter_ns() - started_ns,
        "sqlite_write_count": sqlite_write_count,
    }


def _record_event(conn: sqlite3.Connection, event: dict[str, Any]) -> int:
    # The post-operation state is read within the same short transaction. This
    # is durable evidence for offline generation/lease checks, not a new guard.
    current = conn.execute(
        "SELECT * FROM nf_state WHERE nf=?", (event["nf"],)
    ).fetchone()
    event["nf_state_after"] = row_dict(current)
    event["lease_expires_ns"] = current["lease_expires_ns"] if current else None
    return insert_event(conn, event)


def _finish(event: dict[str, Any], event_seq: int) -> dict[str, Any]:
    append_committed_event(event_seq)
    event["event_seq"] = event_seq
    return event


def _same_state_identity(row: sqlite3.Row, request: StateRequest) -> bool:
    return (
        row["sid"] == request.sid
        and row["owner_edge"] == request.owner_edge
        and int(row["generation"]) == request.generation
        and row["aid"] == request.aid
        and row["bound_update_digest"] == request.bound_update_digest
        and row["variant"] == request.variant
    )


def _state_name(row: sqlite3.Row | None) -> str:
    return row["state"] if row is not None else "ABSENT"


@asynccontextmanager
async def lifespan(_: FastAPI):
    if not os.environ.get("LUAF_TEST_HMAC_KEY"):
        raise RuntimeError("LUAF_TEST_HMAC_KEY must be supplied by the environment")
    initialize()
    yield
    export_events()


app = FastAPI(title="LUAF authorization-instance prototype", lifespan=lifespan)


@app.get("/health")
def health() -> dict[str, Any]:
    with connect() as conn:
        db_ok = conn.execute("PRAGMA quick_check").fetchone()[0] == "ok"
        counts = {
            table: conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            for table in (
                "nf_state",
                "commit_record",
                "update_admission",
                "contribution",
                "event_outbox",
            )
        }
    memory = PROCESS.memory_info()
    return {
        "status": "ok" if db_ok else "error",
        "attempt_id": os.environ.get("LUAF_ATTEMPT_ID", ""),
        "source_sha256": os.environ.get("LUAF_SOURCE_SHA256", ""),
        "database_name": db_path().name,
        "boot_id": BOOT_ID,
        "sqlite_quick_check": "ok" if db_ok else "failed",
        "counts": counts,
        "cpu_percent": PROCESS.cpu_percent(None),
        "cpu_process_seconds": sum(PROCESS.cpu_times()[:2]),
        "memory_rss_bytes": memory.rss,
        "server_time_ns": time.time_ns(),
        "real_sm2": False,
        "test_auth": "HMAC-SHA256",
    }


@app.post("/reserve", dependencies=[Depends(authenticate)])
def reserve(request: ReserveRequest) -> dict[str, Any]:
    started = time.perf_counter_ns()
    _validate_variant(request.variant)
    expected_aid = authorization_instance_id(request.model_dump())
    if request.variant in CONTRACT_VARIANTS and request.aid != expected_aid:
        with connect() as conn:
            conn.execute("BEGIN IMMEDIATE")
            event = _base(
                request,
                operation="Reserve",
                state_before="ABSENT",
                state_after="ABSENT",
                result="REJECTED",
                reason="aid_canonicalization_mismatch",
                started_ns=started,
            )
            seq = _record_event(conn, event)
            conn.commit()
        return _finish(event, seq)

    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM nf_state WHERE nf=?", (request.nf,)).fetchone()
        revoked = conn.execute(
            "SELECT 1 FROM revocation_state WHERE credential_commitment=?",
            (request.credential_commitment,),
        ).fetchone()
        before = _state_name(row)
        writes = 1
        if revoked is not None:
            event = _base(
                request, operation="Reserve", state_before=before, state_after=before,
                result="REJECTED", reason="credential_revoked", started_ns=started,
            )
        elif row is not None and row["state"] == "SPENT":
            event = _base(
                request, operation="Reserve", state_before=before, state_after=before,
                result="REJECTED", reason="nf_already_spent", started_ns=started,
            )
        elif (
            row is not None
            and row["lease_expires_ns"] > now
            and row["sid"] == request.sid
            and row["owner_edge"] == request.owner_edge
            and row["aid"] == request.aid
            and row["bound_update_digest"] == request.bound_update_digest
            and row["variant"] == request.variant
        ):
            request.generation = int(row["generation"])
            event = _base(
                request, operation="Reserve", state_before=before, state_after=before,
                result="IDEMPOTENT", reason="reservation_replayed", started_ns=started,
            )
        elif row is not None and row["lease_expires_ns"] > now:
            request.generation = int(row["generation"])
            event = _base(
                request, operation="Reserve", state_before=before, state_after=before,
                result="REJECTED", reason="nf_reserved_by_other_transaction", started_ns=started,
            )
        else:
            generation = int(row["generation"]) + 1 if row is not None else 1
            request.generation = generation
            conn.execute(
                """INSERT INTO nf_state(
                    nf,variant,aid,sid,owner_edge,generation,state,lease_expires_ns,
                    credential_commitment,slot,context,one_time_key_ref,
                    bound_update_digest,updated_ns
                ) VALUES(?,?,?,?,?,?, 'PENDING',?,?,?,?,?,?,?)
                ON CONFLICT(nf) DO UPDATE SET
                    variant=excluded.variant, aid=excluded.aid, sid=excluded.sid,
                    owner_edge=excluded.owner_edge, generation=excluded.generation,
                    state='PENDING', lease_expires_ns=excluded.lease_expires_ns,
                    credential_commitment=excluded.credential_commitment,
                    slot=excluded.slot, context=excluded.context,
                    one_time_key_ref=excluded.one_time_key_ref,
                    bound_update_digest=excluded.bound_update_digest,
                    updated_ns=excluded.updated_ns""",
                (
                    request.nf, request.variant, request.aid, request.sid,
                    request.owner_edge, generation, now + request.lease_ms * 1_000_000,
                    request.credential_commitment, request.slot, request.context,
                    request.one_time_key_ref, request.bound_update_digest, now,
                ),
            )
            writes += 1
            event = _base(
                request, operation="Reserve", state_before=before, state_after="PENDING",
                result="ACCEPTED", reason="reservation_created", started_ns=started,
                sqlite_write_count=writes,
            )
        seq = _record_event(conn, event)
        conn.commit()
    return _finish(event, seq)


def _transition(request: StateRequest, operation: str) -> dict[str, Any]:
    started = time.perf_counter_ns()
    _validate_variant(request.variant)
    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM nf_state WHERE nf=?", (request.nf,)).fetchone()
        before = _state_name(row)
        writes = 1
        result, reason, after = "REJECTED", "current_reservation_required", before
        if row is not None and _same_state_identity(row, request):
            if row["lease_expires_ns"] <= now and row["state"] != "SPENT":
                reason = "reservation_lease_expired"
            elif operation == "Confirm" and row["state"] == "PENDING":
                conn.execute(
                    "UPDATE nf_state SET state='CONFIRMED', updated_ns=? WHERE nf=?",
                    (now, request.nf),
                )
                writes += 1
                result, reason, after = "ACCEPTED", "reservation_confirmed", "CONFIRMED"
            elif operation == "Confirm" and row["state"] == "CONFIRMED":
                result, reason, after = "IDEMPOTENT", "confirmation_replayed", "CONFIRMED"
            elif operation == "Abort" and row["state"] in {"PENDING", "CONFIRMED"}:
                conn.execute("DELETE FROM nf_state WHERE nf=?", (request.nf,))
                writes += 1
                result, reason, after = "ACCEPTED", "reservation_aborted", "ABSENT"
            elif operation == "Abort" and row["state"] == "SPENT":
                reason = "committed_transaction_cannot_abort"
            else:
                reason = "invalid_state_transition"
        event = _base(
            request, operation=operation, state_before=before, state_after=after,
            result=result, reason=reason, started_ns=started,
            sqlite_write_count=writes,
        )
        seq = _record_event(conn, event)
        conn.commit()
    return _finish(event, seq)


@app.post("/confirm", dependencies=[Depends(authenticate)])
def confirm(request: StateRequest) -> dict[str, Any]:
    return _transition(request, "Confirm")


@app.post("/abort", dependencies=[Depends(authenticate)])
def abort(request: StateRequest) -> dict[str, Any]:
    return _transition(request, "Abort")


@app.post("/commit", dependencies=[Depends(authenticate)])
def commit(request: CommitRequest) -> dict[str, Any]:
    started = time.perf_counter_ns()
    _validate_variant(request.variant)
    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT * FROM nf_state WHERE nf=?", (request.nf,)).fetchone()
        before = _state_name(row)
        existing = conn.execute(
            "SELECT * FROM commit_record WHERE nf=? AND generation=?",
            (request.nf, request.generation),
        ).fetchone()
        writes = 1
        commit_id = ""
        if existing is not None:
            commit_id = existing["commit_record_id"]
            exact = all(
                existing[key] == getattr(request, key)
                for key in ("variant", "aid", "sid", "owner_edge", "bound_update_digest")
            )
            if exact:
                result, reason = "IDEMPOTENT", "commit_replayed"
            else:
                result, reason = "REJECTED", "conflicting_commit_retry"
            after = before
        elif row is None or not _same_state_identity(row, request):
            result, reason, after = "REJECTED", "current_reservation_required", before
        elif row["lease_expires_ns"] <= now:
            result, reason, after = "REJECTED", "reservation_lease_expired", before
        elif row["state"] != "CONFIRMED":
            result, reason, after = "REJECTED", "confirmation_required", before
        else:
            commit_id = stable_id("commit", request.nf, request.generation)
            conn.execute(
                """INSERT INTO commit_record(
                    commit_record_id,variant,nf,aid,sid,owner_edge,generation,
                    bound_update_digest,created_ns
                ) VALUES(?,?,?,?,?,?,?,?,?)""",
                (
                    commit_id, request.variant, request.nf, request.aid, request.sid,
                    request.owner_edge, request.generation,
                    request.bound_update_digest, now,
                ),
            )
            conn.execute(
                "UPDATE nf_state SET state='SPENT', updated_ns=? WHERE nf=?",
                (now, request.nf),
            )
            writes += 2
            result, reason, after = "ACCEPTED", "commit_persisted", "SPENT"
        event = _base(
            request, operation="Commit", state_before=before, state_after=after,
            result=result, reason=reason, started_ns=started,
            commit_record_id=commit_id, sqlite_write_count=writes,
        )
        seq = _record_event(conn, event)
        conn.commit()
    response = _finish(event, seq)
    if request.delay_after_commit_ms:
        time.sleep(request.delay_after_commit_ms / 1000.0)
    return response


@app.get("/status/{nf}")
def status(nf: str) -> dict[str, Any]:
    with connect() as conn:
        state = row_dict(conn.execute("SELECT * FROM nf_state WHERE nf=?", (nf,)).fetchone())
        commit_row = row_dict(
            conn.execute(
                "SELECT * FROM commit_record WHERE nf=? ORDER BY generation DESC LIMIT 1", (nf,)
            ).fetchone()
        )
        admission = row_dict(
            conn.execute(
                "SELECT * FROM update_admission WHERE nf=? ORDER BY created_ns DESC LIMIT 1", (nf,)
            ).fetchone()
        )
        contribution = row_dict(
            conn.execute(
                "SELECT * FROM contribution WHERE nf=? ORDER BY created_ns DESC LIMIT 1", (nf,)
            ).fetchone()
        )
    current = (state or {}).get("state", "ABSENT")
    return {
        "request_id": "",
        "variant": (state or {}).get("variant", ""),
        "nf": nf,
        "aid": (state or {}).get("aid", ""),
        "sid": (state or {}).get("sid", ""),
        "owner_edge": (state or {}).get("owner_edge", ""),
        "generation": (state or {}).get("generation", 0),
        "bound_update_digest": (state or {}).get("bound_update_digest", ""),
        "state_before": current,
        "state_after": current,
        "commit_record_id": (commit_row or {}).get("commit_record_id", ""),
        "update_admission_id": (admission or {}).get("update_admission_id", ""),
        "contribution_id": (contribution or {}).get("contribution_id", ""),
        "result": "ACCEPTED",
        "reason": "status_read",
        "state": state,
        "server_time_ns": time.time_ns(),
    }


@app.post("/admit-update", dependencies=[Depends(authenticate)])
def admit_update(request: AdmitRequest) -> dict[str, Any]:
    started = time.perf_counter_ns()
    _validate_variant(request.variant)
    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        parent = conn.execute(
            "SELECT * FROM commit_record WHERE commit_record_id=?", (request.commit_record_id,)
        ).fetchone()
        existing = conn.execute(
            "SELECT * FROM update_admission WHERE commit_record_id=?", (request.commit_record_id,)
        ).fetchone()
        writes = 1
        admission_id = ""
        before, after = "COMMIT_ABSENT", "COMMIT_ABSENT"
        if parent is None:
            result, reason = "REJECTED", "commit_record_required"
        else:
            before = after = "COMMITTED"
            binding_fields = (
                "variant", "nf", "aid", "sid", "owner_edge", "generation",
                "bound_update_digest",
            )
            binding_ok = all(parent[key] == getattr(request, key) for key in binding_fields)
            if request.variant in CONTRACT_VARIANTS and not binding_ok:
                result, reason = "REJECTED", "authorization_instance_parent_mismatch"
            elif existing is not None:
                admission_id = existing["update_admission_id"]
                exact = all(existing[key] == getattr(request, key) for key in binding_fields)
                if exact:
                    result, reason = "IDEMPOTENT", "update_admission_replayed"
                else:
                    result, reason = "REJECTED", "conflicting_update_for_commit"
            else:
                admission_id = stable_id("admit", request.commit_record_id)
                conn.execute(
                    """INSERT INTO update_admission(
                        update_admission_id,variant,nf,aid,sid,owner_edge,generation,
                        bound_update_digest,commit_record_id,created_ns
                    ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        admission_id, request.variant, request.nf, request.aid, request.sid,
                        request.owner_edge, request.generation,
                        request.bound_update_digest, request.commit_record_id, now,
                    ),
                )
                writes += 1
                result, reason, after = "ACCEPTED", "update_admitted", "UPDATE_ADMITTED"
        event = _base(
            request, operation="UpdateAdmit", state_before=before, state_after=after,
            result=result, reason=reason, started_ns=started,
            commit_record_id=request.commit_record_id,
            update_admission_id=admission_id, sqlite_write_count=writes,
        )
        seq = _record_event(conn, event)
        conn.commit()
    return _finish(event, seq)


@app.post("/apply-contribution", dependencies=[Depends(authenticate)])
def apply_contribution(request: ContributionRequest) -> dict[str, Any]:
    started = time.perf_counter_ns()
    _validate_variant(request.variant)
    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        parent = conn.execute(
            "SELECT * FROM update_admission WHERE update_admission_id=?",
            (request.update_admission_id,),
        ).fetchone()
        existing = conn.execute(
            "SELECT * FROM contribution WHERE update_admission_id=?",
            (request.update_admission_id,),
        ).fetchone()
        writes = 1
        contribution_id = ""
        before, after = "ADMISSION_ABSENT", "ADMISSION_ABSENT"
        inherited = (
            "variant", "nf", "aid", "sid", "owner_edge", "generation",
            "bound_update_digest", "commit_record_id",
        )
        if parent is None:
            result, reason = "REJECTED", "update_admission_required"
        elif not all(parent[key] == getattr(request, key) for key in inherited):
            before = after = "UPDATE_ADMITTED"
            result, reason = "REJECTED", "contribution_parent_mismatch"
        elif existing is not None:
            before = after = "CONTRIBUTED"
            contribution_id = existing["contribution_id"]
            result, reason = "IDEMPOTENT", "contribution_replayed"
        else:
            before, after = "UPDATE_ADMITTED", "CONTRIBUTED"
            contribution_id = stable_id("contribution", request.update_admission_id)
            conn.execute(
                """INSERT INTO contribution(
                    contribution_id,variant,nf,aid,sid,owner_edge,generation,
                    bound_update_digest,commit_record_id,update_admission_id,created_ns
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    contribution_id, request.variant, request.nf, request.aid,
                    request.sid, request.owner_edge, request.generation,
                    request.bound_update_digest, request.commit_record_id,
                    request.update_admission_id, now,
                ),
            )
            writes += 1
            result, reason = "ACCEPTED", "contribution_applied"
        event = _base(
            request, operation="Contribution", state_before=before, state_after=after,
            result=result, reason=reason, started_ns=started,
            commit_record_id=request.commit_record_id,
            update_admission_id=request.update_admission_id,
            contribution_id=contribution_id, sqlite_write_count=writes,
        )
        seq = _record_event(conn, event)
        conn.commit()
    return _finish(event, seq)


@app.post("/revoke", dependencies=[Depends(authenticate)])
def revoke(request: RevokeRequest) -> dict[str, Any]:
    started = time.perf_counter_ns()
    now = time.time_ns()
    with connect() as conn:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute(
            "SELECT * FROM revocation_state WHERE credential_commitment=?",
            (request.credential_commitment,),
        ).fetchone()
        writes = 1
        if row is None:
            conn.execute(
                "INSERT INTO revocation_state VALUES(?,?,?)",
                (request.credential_commitment, now, request.request_id),
            )
            writes += 1
            result, reason = "ACCEPTED", "credential_revoked"
        else:
            result, reason = "IDEMPOTENT", "revocation_replayed"
        event = _base(
            request, operation="Revoke", state_before="ACTIVE" if row is None else "REVOKED",
            state_after="REVOKED", result=result, reason=reason, started_ns=started,
            sqlite_write_count=writes,
        )
        seq = _record_event(conn, event)
        conn.commit()
    return _finish(event, seq)
