from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Authorization(StrictModel):
    request_id: str = Field(min_length=1)
    variant: str = Field(min_length=1)
    nf: str = Field(min_length=1)
    aid: str = Field(min_length=1)
    sid: str = Field(min_length=1)
    owner_edge: str = Field(min_length=1)
    generation: int = Field(ge=0)
    credential_commitment: str = Field(min_length=1)
    slot: str = Field(min_length=1)
    context: str = Field(min_length=1)
    one_time_key_ref: str = Field(min_length=1)
    bound_update_digest: str = Field(min_length=1)


class ReserveRequest(Authorization):
    lease_ms: int = Field(default=1500, ge=10, le=60000)


class StateRequest(StrictModel):
    request_id: str = Field(min_length=1)
    variant: str = Field(min_length=1)
    nf: str = Field(min_length=1)
    aid: str = Field(min_length=1)
    sid: str = Field(min_length=1)
    owner_edge: str = Field(min_length=1)
    generation: int = Field(ge=1)
    bound_update_digest: str = Field(min_length=1)


class CommitRequest(StateRequest):
    delay_after_commit_ms: int = Field(default=0, ge=0, le=10000)


class AdmitRequest(StateRequest):
    commit_record_id: str = Field(min_length=1)


class ContributionRequest(AdmitRequest):
    update_admission_id: str = Field(min_length=1)


class RevokeRequest(StrictModel):
    request_id: str = Field(min_length=1)
    credential_commitment: str = Field(min_length=1)

