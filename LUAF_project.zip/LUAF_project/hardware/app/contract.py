from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any


CONTRACT_VARIANTS = {"B2A_RCA_AID", "LUAF_C1C2_PROTO"}
SERVER_VARIANTS = {"B2_GENERIC_RCA", *CONTRACT_VARIANTS}
AID_FIELDS = (
    "credential_commitment",
    "slot",
    "context",
    "one_time_key_ref",
    "nf",
    "bound_update_digest",
)


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")


def authorization_instance_id(payload: dict[str, Any]) -> str:
    material = {field: payload[field] for field in AID_FIELDS}
    return hashlib.sha256(canonical_json(material)).hexdigest()


def stable_id(prefix: str, *parts: object) -> str:
    body = canonical_json([prefix, *parts])
    return f"{prefix}_{hashlib.sha256(body).hexdigest()[:32]}"


def test_signature(key: str, body: bytes) -> str:
    return hmac.new(key.encode("utf-8"), body, hashlib.sha256).hexdigest()


def verify_test_signature(key: str, body: bytes, supplied: str) -> bool:
    if not key or not supplied:
        return False
    return hmac.compare_digest(test_signature(key, body), supplied)

