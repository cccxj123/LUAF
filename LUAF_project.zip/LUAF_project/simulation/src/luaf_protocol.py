from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Set, Tuple

import numpy as np

from .crypto_sim import hex_hash, rand_bytes, sm3_hash


@dataclass
class AFCredential:
    """限次匿名飞行凭证 AFC 的仿真对象。

    这里只保留实验需要的状态：
    - cred_id: 凭证内部编号，真实协议中不公开。
    - uav_id: 真实 UAV 身份，只有 TA/CAA 和 Auditor 可见。
    - s_nf: 生成 NF 的秘密种子。
    - limit_L: 一个 ctx 下最多使用次数。
    - revoked: 是否撤销。
    """

    cred_id: str
    uav_id: str
    s_nf: bytes
    limit_L: int
    epoch: int
    revoked: bool = False
    used_indices: Set[int] = field(default_factory=set)


@dataclass
class M1Message:
    """UAV -> Edge/BS 的匿名接入请求 M1。"""

    uav_id_hidden: str
    cred_id_hidden: str
    asid: str
    q: str
    r_u: str
    nf: str
    ctx: str
    pi: str
    c_open: str
    j: int


@dataclass
class VerifyResult:
    """Edge/BS 验证 M1 后的结果。"""

    accept: bool
    reason: str


class TACAA:
    """可信机构 TA/CAA：注册、发行 AFC、撤销凭证。"""

    def __init__(self, limit_L: int = 20, rng: np.random.Generator | None = None):
        self.limit_L = limit_L
        self.credentials: Dict[str, AFCredential] = {}
        self.uav_to_cred: Dict[str, str] = {}
        self.rng = rng if rng is not None else np.random.default_rng(0)

    def issue_credential(self, uav_id: str, epoch: int = 0) -> AFCredential:
        """给 UAV 发行限次匿名飞行凭证。"""
        nonce = rand_bytes(8, self.rng).hex()
        cred_id = hex_hash(f"cred|{uav_id}|{epoch}|{nonce}".encode(), n=16)
        cred = AFCredential(
            cred_id=cred_id,
            uav_id=uav_id,
            s_nf=rand_bytes(32, self.rng),
            limit_L=self.limit_L,
            epoch=epoch,
        )
        self.credentials[cred_id] = cred
        self.uav_to_cred[uav_id] = cred_id
        return cred

    def revoke_uav(self, uav_id: str) -> None:
        """撤销某 UAV 当前凭证。"""
        cred_id = self.uav_to_cred.get(uav_id)
        if cred_id and cred_id in self.credentials:
            self.credentials[cred_id].revoked = True

    def get_credential(self, uav_id: str) -> AFCredential:
        cred_id = self.uav_to_cred[uav_id]
        return self.credentials[cred_id]


class NFStateCache:
    """NF/RL 状态缓存。

    Edge/BS 通过这个对象检查 NF 是否已被使用、凭证是否被撤销。
    如果多个 Edge/BS 共享该对象，则模拟 EdgeGroup 内全局同步；
    如果每个 Edge/BS 持有独立对象，则可模拟跨 Edge 双花窗口。
    """

    def __init__(self):
        self.used_nf: Set[str] = set()
        self.revoked_creds: Set[str] = set()
        self.audit_hashes: Set[str] = set()

    def publish_revocation(self, cred_id: str) -> None:
        self.revoked_creds.add(cred_id)

    def check_and_insert_nf(self, nf: str) -> bool:
        """若 NF 未使用则插入并返回 True；若已使用则返回 False。"""
        if nf in self.used_nf:
            return False
        self.used_nf.add(nf)
        return True

    def is_revoked(self, cred_id: str) -> bool:
        return cred_id in self.revoked_creds


class UAVClientProtocol:
    """UAV 侧协议逻辑：生成 ASID、Q、R_U、NF、π、C_open。"""

    def __init__(self, uav_id: str, credential: AFCredential, rng: np.random.Generator | None = None):
        self.uav_id = uav_id
        self.credential = credential
        self.rng = rng if rng is not None else np.random.default_rng(0)

    def make_nullifier(self, ctx: str, j: int) -> str:
        raw = b"LUAF-NF|" + self.credential.s_nf + ctx.encode() + str(j).encode()
        return sm3_hash(raw).hex()

    def generate_m1(self, ctx: str, j: Optional[int] = None) -> M1Message:
        """生成 M1。

        j 表示第 j 次匿名额度；若不指定，则自动选择未使用的最小 j。
        """
        if j is None:
            for cand in range(1, self.credential.limit_L + 1):
                if cand not in self.credential.used_indices:
                    j = cand
                    break
            if j is None:
                # 超限时仍生成 j=L+1，Edge 应拒绝。
                j = self.credential.limit_L + 1

        # ASID、Q、R_U、π、C_open 在真实协议中由随机数、一次性密钥和证明生成。
        asid = hex_hash(b"ASID|" + rand_bytes(16, self.rng) + ctx.encode(), n=24)
        q = "Q_" + hex_hash(b"Q|" + rand_bytes(32, self.rng), n=32)
        r_u = "RU_" + hex_hash(b"RU|" + rand_bytes(32, self.rng), n=32)
        nf = self.make_nullifier(ctx, j)
        pi = "PI_" + hex_hash(b"proof|" + self.credential.cred_id.encode() + nf.encode(), n=32)
        # C_open 是追责密文；这里用哈希模拟，不暴露真实身份。
        c_open = "COPEN_" + hex_hash(b"open|" + self.uav_id.encode() + ctx.encode() + nf.encode(), n=32)

        return M1Message(
            uav_id_hidden="hidden",
            cred_id_hidden=self.credential.cred_id,
            asid=asid,
            q=q,
            r_u=r_u,
            nf=nf,
            ctx=ctx,
            pi=pi,
            c_open=c_open,
            j=j,
        )


class EdgeVerifier:
    """Edge/BS 侧验证逻辑。"""

    def __init__(self, nf_cache: NFStateCache, ta: TACAA):
        self.nf_cache = nf_cache
        self.ta = ta

    def verify_m1(self, m1: M1Message) -> VerifyResult:
        """验证 M1。返回 accept/reject 和原因。"""
        cred = self.ta.credentials.get(m1.cred_id_hidden)
        if cred is None:
            return VerifyResult(False, "invalid_credential")
        if cred.revoked or self.nf_cache.is_revoked(cred.cred_id):
            return VerifyResult(False, "revoked")
        if not (1 <= m1.j <= cred.limit_L):
            return VerifyResult(False, "over_limit")

        # 检查 NF 是否与 cred、ctx、j 一致。
        expected_nf = sm3_hash(b"LUAF-NF|" + cred.s_nf + m1.ctx.encode() + str(m1.j).encode()).hex()
        if expected_nf != m1.nf:
            return VerifyResult(False, "nf_mismatch")

        # 插入 NF，若已存在则说明双花或重放。
        if not self.nf_cache.check_and_insert_nf(m1.nf):
            return VerifyResult(False, "double_spending")

        # 简化处理：真实协议中还应验证 π、C_open、ctx 策略和设备绑定。
        return VerifyResult(True, "accept")


class Auditor:
    """审计方：异常事件下打开身份。"""

    def __init__(self, ta: TACAA):
        self.ta = ta

    def open_identity(self, m1: M1Message) -> Tuple[str, str]:
        """根据 C_open / cred_id 找回 UAV 身份。

        这里用 TA 的映射模拟；真实协议中由 Auditor 私钥解密 C_open。
        """
        cred = self.ta.credentials.get(m1.cred_id_hidden)
        if cred is None:
            return ("unknown", "invalid")
        return (cred.uav_id, cred.cred_id)


def make_ctx(airspace: str, epoch: int, mission: str, edge_group: str, round_id: int) -> str:
    """生成飞行与 FL 轮次上下文 ctx。"""
    raw = f"{airspace}|{epoch}|{mission}|{edge_group}|round={round_id}".encode()
    return sm3_hash(raw).hex()[:32]
