from dataclasses import dataclass


@dataclass
class SimConfig:
    """集中管理仿真参数。

    这些参数不是密码学安全参数，而是用于论文仿真中的系统规模、协议时延和通信开销设置。
    后续如果接入真实 GmSSL/Tongsuo/硬件国密模块，可以只替换 crypto_sim.py 中的实现。
    """

    seed: int = 20260529
    num_clients: int = 30
    num_rounds: int = 20
    participation_rate: float = 0.5
    local_epochs: int = 2
    lr: float = 0.06
    batch_size: int = 32
    test_ratio: float = 0.25
    val_ratio: float = 0.10
    noniid_alpha: float = 0.5
    partition_mode: str = "observed"
    crypto_backend: str = "simulated"

    # 每个 AFC 在一个 ctx 下最大可用次数 L
    credential_limit_L: int = 20

    # 模型更新大小：仿真中的模型更新字节数。轻量模型通常是几十 KB 到数百 KB。
    model_update_bytes: int = 64 * 1024

    # 协议消息各字段近似字节数，用于通信开销统计
    bytes_asid: int = 32
    bytes_q: int = 64
    bytes_ru: int = 64
    bytes_re: int = 64
    bytes_nf: int = 32
    bytes_ctx: int = 32
    bytes_pi: int = 512
    bytes_copen: int = 128
    bytes_cert_edge: int = 512
    bytes_confirm: int = 32
    bytes_timestamp: int = 8

    # 仿真时延参数，单位 ms。正式论文中可替换为真实国密库实测值。
    latency_hash_ms: float = 0.02
    latency_m1_gen_ms: float = 0.60
    latency_m1_verify_ms: float = 1.40
    latency_nf_lookup_ms: float = 0.03
    latency_rl_lookup_ms: float = 0.05
    latency_sm2_ake_ms: float = 4.00
    latency_sm2_ake_dynpid_ms: float = 3.20
    latency_sm4_per_kb_ms: float = 0.006
    latency_edge_aggregate_ms: float = 1.20

    # 移动接入仿真参数
    area_size_m: int = 1000
    edge_radio_m: int = 350
    packet_loss_default: float = 0.05
