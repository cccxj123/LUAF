"""Deterministic experiment streams and evidence helpers.

The experiment code deliberately derives independent streams from a root seed
instead of sharing a mutable process-global RNG. This keeps client selection,
local shuffling, attacks, protocol jitter, and metadata generation isolated.
"""

from __future__ import annotations

import dataclasses
import hashlib
import json
import platform
import sys
from pathlib import Path
from typing import Any

import numpy as np


FORMAL_SEEDS = [20260529, 20260611, 20260623, 20260705, 20260717]
STREAM_NAMES = (
    "split",
    "partition",
    "model_init",
    "client_selection",
    "local_batch",
    "attack",
    "metadata",
    "mobility",
    "protocol_jitter",
    "crypto",
)


def _uint32_words(*parts: object) -> list[int]:
    raw = "|".join(str(part) for part in parts).encode("utf-8")
    digest = hashlib.sha256(raw).digest()
    return [int.from_bytes(digest[i : i + 4], "big") for i in range(0, 32, 4)]


def seed_sequence(seed: int, stream: str, *parts: object) -> np.random.SeedSequence:
    if stream not in STREAM_NAMES:
        raise ValueError(f"Unknown reproducibility stream: {stream}")
    return np.random.SeedSequence([int(seed) & 0xFFFFFFFF, *_uint32_words(stream, *parts)])


def make_rng(seed: int, stream: str, *parts: object) -> np.random.Generator:
    return np.random.default_rng(seed_sequence(seed, stream, *parts))


def stable_digest(value: Any) -> str:
    if isinstance(value, bytes):
        payload = value
    else:
        payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def model_digest(model: Any) -> str:
    params = model.get_params()
    digest = hashlib.sha256()
    for key in sorted(params):
        array = np.ascontiguousarray(params[key])
        digest.update(key.encode("utf-8"))
        digest.update(str(array.dtype).encode("ascii"))
        digest.update(repr(array.shape).encode("ascii"))
        digest.update(array.tobytes())
    return digest.hexdigest()


def run_id(dataset: str, scheme: str, model: str, seed: int) -> str:
    safe = "|".join(str(value) for value in (dataset, scheme, model, seed))
    return hashlib.sha256(safe.encode("utf-8")).hexdigest()[:16]


def config_dict(config: Any) -> dict[str, Any]:
    if dataclasses.is_dataclass(config):
        return dataclasses.asdict(config)
    return dict(vars(config))


def code_fingerprint(project_root: str | Path) -> str:
    root = Path(project_root).resolve()
    digest = hashlib.sha256()
    paths = sorted(
        path
        for path in root.rglob("*.py")
        if "__pycache__" not in path.parts and ".staging" not in path.parts
    )
    for path in paths:
        relative = path.relative_to(root).as_posix()
        digest.update(relative.encode("utf-8"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(path.read_bytes()).digest())
    return digest.hexdigest()


def environment_snapshot() -> dict[str, Any]:
    snapshot: dict[str, Any] = {
        "python": sys.version,
        "python_version": platform.python_version(),
        "os": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "processor": platform.processor(),
        "numpy": np.__version__,
    }
    try:
        import pandas as pd

        snapshot["pandas"] = pd.__version__
    except Exception:
        snapshot["pandas"] = None
    try:
        import sklearn

        snapshot["scikit_learn"] = sklearn.__version__
    except Exception:
        snapshot["scikit_learn"] = None
    try:
        import torch

        snapshot["torch"] = torch.__version__
        snapshot["cuda"] = getattr(torch.version, "cuda", None)
    except Exception:
        snapshot["torch"] = None
        snapshot["cuda"] = None
    return snapshot
