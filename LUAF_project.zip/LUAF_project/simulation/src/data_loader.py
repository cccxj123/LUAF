from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from .config import SimConfig
from .io_utils import read_csv_robust
from .make_synthetic_dataset import FEATURES, LABELS, generate_synthetic_uav_ids
from .reproducibility import make_rng, stable_digest
from .utils import DATA_DIR, ensure_dir


@dataclass
class FLDataset:
    """Prepared FL data plus auditable split and client-partition evidence."""

    train_by_client: Dict[str, Tuple[np.ndarray, np.ndarray]]
    X_val: np.ndarray
    y_val: np.ndarray
    X_test: np.ndarray
    y_test: np.ndarray
    feature_names: List[str]
    label_names: List[str]
    scaler: StandardScaler
    train_indices: np.ndarray
    val_indices: np.ndarray
    test_indices: np.ndarray
    client_partition: Dict[str, List[int]]
    split_hash: str
    partition_hash: str


def load_or_create_dataset(path: str | Path | None = None, seed: int = 20260529) -> pd.DataFrame:
    """Read a dataset, creating the documented demo dataset when absent."""
    if path is None:
        path = DATA_DIR / "synthetic_uav_ids.csv"
    path = Path(path)
    if not path.exists():
        ensure_dir(path.parent)
        df = generate_synthetic_uav_ids(seed=seed)
        df.to_csv(path, index=False, encoding="utf-8-sig")
    df, _used_encoding = read_csv_robust(path)
    if "label" not in df.columns and "label_id" not in df.columns:
        raise ValueError("Dataset must contain 'label' or 'label_id'. Please run prepare_real_dataset.py first.")
    return df


def infer_feature_columns(df: pd.DataFrame) -> List[str]:
    excluded = {"uav_id", "edge_id", "round_id", "label", "label_id"}
    numeric_cols = [c for c in df.columns if c not in excluded and pd.api.types.is_numeric_dtype(df[c])]
    if set(FEATURES).issubset(df.columns):
        return FEATURES
    return numeric_cols


def _split_indices(indices: np.ndarray, y: np.ndarray, test_size: float, seed: int) -> tuple[np.ndarray, np.ndarray]:
    try:
        return train_test_split(indices, test_size=test_size, random_state=seed, stratify=y[indices])
    except ValueError:
        return train_test_split(indices, test_size=test_size, random_state=seed)


def _build_assignments(
    y_train: np.ndarray,
    train_source_indices: np.ndarray,
    uav_train: np.ndarray,
    cfg: SimConfig,
) -> Dict[str, np.ndarray]:
    mode = cfg.partition_mode.lower()
    if mode == "observed":
        return {client: np.flatnonzero(uav_train == client) for client in sorted(set(uav_train))}
    if mode not in {"iid", "dirichlet"}:
        raise ValueError("partition_mode must be one of: observed, iid, dirichlet")

    client_names = [f"UAV_{i:03d}" for i in range(max(1, cfg.num_clients))]
    assignments = {client: np.array([], dtype=int) for client in client_names}
    rng = make_rng(cfg.seed, "partition", mode, cfg.noniid_alpha)
    if mode == "iid":
        positions = rng.permutation(len(train_source_indices))
        for client, part in zip(client_names, np.array_split(positions, len(client_names))):
            assignments[client] = np.asarray(part, dtype=int)
        return assignments

    for label in np.unique(y_train):
        positions = np.flatnonzero(y_train == label)
        rng.shuffle(positions)
        proportions = rng.dirichlet(np.full(len(client_names), max(cfg.noniid_alpha, 1e-6)))
        cuts = np.cumsum((proportions * len(positions)).astype(int))[:-1]
        for client, part in zip(client_names, np.split(positions, cuts)):
            assignments[client] = np.concatenate([assignments[client], part])
    return assignments


def prepare_fl_dataset(df: pd.DataFrame, cfg: SimConfig) -> FLDataset:
    """Create train/validation/test arrays and deterministic client data."""
    feature_cols = infer_feature_columns(df)
    if not feature_cols:
        raise ValueError("Dataset has no numeric feature columns after metadata/label exclusion.")

    if "label_id" in df.columns:
        y = pd.to_numeric(df["label_id"], errors="raise").astype(int).to_numpy()
        label_values = df["label"].astype(str).unique() if "label" in df.columns else []
        label_names = LABELS if set(label_values).issubset(set(LABELS)) else [str(i) for i in sorted(np.unique(y))]
    elif "label" in df.columns:
        labels = sorted(df["label"].astype(str).unique())
        label_map = {value: index for index, value in enumerate(labels)}
        y = df["label"].astype(str).map(label_map).to_numpy()
        label_names = labels
    else:
        raise ValueError("Dataset must contain 'label' or 'label_id' column.")

    if not 0 <= cfg.test_ratio < 1 or not 0 <= cfg.val_ratio < 1 or cfg.test_ratio + cfg.val_ratio >= 1:
        raise ValueError("test_ratio and val_ratio must be non-negative and sum to less than one.")
    X = df[feature_cols].apply(pd.to_numeric, errors="coerce").to_numpy(dtype=float)
    uav_ids = (
        df["uav_id"].astype(str).to_numpy()
        if "uav_id" in df.columns
        else np.array([f"UAV_{i % cfg.num_clients:03d}" for i in range(len(df))])
    )

    all_indices = np.arange(len(df), dtype=int)
    split_rng = make_rng(cfg.seed, "split")
    split_seed = int(split_rng.integers(0, 2**31 - 1))
    train_val_idx, test_idx = _split_indices(all_indices, y, cfg.test_ratio, split_seed)
    if cfg.val_ratio:
        relative_val = cfg.val_ratio / (1.0 - cfg.test_ratio)
        train_idx, val_idx = _split_indices(train_val_idx, y, relative_val, split_seed + 1)
    else:
        train_idx, val_idx = train_val_idx, np.array([], dtype=int)

    # Fit both the imputation values and the scaler on train rows only.
    train_raw = X[train_idx]
    medians = np.nanmedian(train_raw, axis=0)
    medians = np.where(np.isfinite(medians), medians, 0.0)
    X = np.where(np.isfinite(X), X, medians)
    scaler = StandardScaler()
    X_train = scaler.fit_transform(X[train_idx])
    X_val = scaler.transform(X[val_idx]) if len(val_idx) else np.empty((0, X.shape[1]), dtype=float)
    X_test = scaler.transform(X[test_idx])
    y_train, y_val, y_test = y[train_idx], y[val_idx], y[test_idx]
    uav_train = uav_ids[train_idx]

    assignments = _build_assignments(y_train, train_idx, uav_train, cfg)
    train_by_client: Dict[str, Tuple[np.ndarray, np.ndarray]] = {}
    client_partition: Dict[str, List[int]] = {}
    for client in sorted(assignments):
        positions = np.sort(np.asarray(assignments[client], dtype=int))
        if len(positions) >= 5:
            train_by_client[client] = (X_train[positions], y_train[positions])
            client_partition[client] = [int(train_idx[position]) for position in positions]

    selected = list(train_by_client)[: cfg.num_clients]
    train_by_client = {client: train_by_client[client] for client in selected}
    client_partition = {client: client_partition[client] for client in selected}
    split_payload = {
        "train": sorted(map(int, train_idx)),
        "val": sorted(map(int, val_idx)),
        "test": sorted(map(int, test_idx)),
    }
    return FLDataset(
        train_by_client=train_by_client,
        X_val=X_val,
        y_val=y_val,
        X_test=X_test,
        y_test=y_test,
        feature_names=feature_cols,
        label_names=label_names,
        scaler=scaler,
        train_indices=np.asarray(train_idx, dtype=int),
        val_indices=np.asarray(val_idx, dtype=int),
        test_indices=np.asarray(test_idx, dtype=int),
        client_partition=client_partition,
        split_hash=stable_digest(split_payload),
        partition_hash=stable_digest(client_partition),
    )
