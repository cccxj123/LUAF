"""生成可直接运行的 UAV 网络入侵检测演示数据集。

说明：
1. 真实论文实验建议使用 UAV-NIDD 或 UAV-GCS-IDS 等公开数据集。
2. 本脚本生成的小型数据集用于复现实验流程、调试联邦学习和协议仿真代码。
3. 数据特征模拟 UAV-GCS 通信中的流量、链路和遥测异常，不代表真实网络采样。
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from .utils import DATA_DIR, ensure_dir


LABELS = ["normal", "replay", "mitm", "dos", "fake_landing"]
FEATURES = [
    "pkt_rate",
    "avg_pkt_size",
    "jitter_ms",
    "rssi_dbm",
    "gps_dev_m",
    "cmd_rate",
    "retry_rate",
    "uplink_ratio",
    "control_entropy",
    "tcp_syn_rate",
    "udp_ratio",
    "payload_entropy",
]


# 每类攻击的特征均值。数值只是用于生成演示数据。
CLASS_MEANS = {
    "normal":       [55, 420,  8, -54,  1.2, 12, 0.02, 0.55, 0.45, 2, 0.60, 0.55],
    "replay":       [70, 410, 10, -55,  1.5, 20, 0.04, 0.70, 0.35, 4, 0.62, 0.48],
    "mitm":         [82, 460, 16, -63,  2.3, 18, 0.08, 0.62, 0.62, 8, 0.58, 0.70],
    "dos":          [180, 300, 26, -68,  3.0, 42, 0.18, 0.82, 0.80, 40, 0.76, 0.82],
    "fake_landing": [64, 430, 12, -56, 10.0, 30, 0.05, 0.58, 0.30, 3, 0.57, 0.45],
}

CLASS_STD = np.array([12, 55, 4, 4, 1.2, 5, 0.025, 0.08, 0.10, 3, 0.08, 0.10])


def generate_synthetic_uav_ids(n_rows: int = 6000, n_uavs: int = 60, n_edges: int = 5, seed: int = 20260529) -> pd.DataFrame:
    """生成带 UAV、Edge、轮次和攻击标签的演示数据。"""
    rng = np.random.default_rng(seed)
    rows = []

    # 每个 UAV 分配一个“偏好攻击分布”，用于模拟 non-IID。
    per_uav_bias = {}
    for u in range(n_uavs):
        # 正常样本占多数，少数 UAV 对某类攻击更敏感。
        base = np.array([0.62, 0.10, 0.10, 0.10, 0.08])
        hot = rng.integers(0, len(LABELS))
        base[hot] += rng.uniform(0.05, 0.20)
        base = base / base.sum()
        per_uav_bias[u] = base

    for idx in range(n_rows):
        uav_id = int(rng.integers(0, n_uavs))
        edge_id = int(rng.integers(0, n_edges))
        round_id = int(rng.integers(0, 40))
        label_idx = int(rng.choice(len(LABELS), p=per_uav_bias[uav_id]))
        label = LABELS[label_idx]
        mean = np.array(CLASS_MEANS[label])
        x = rng.normal(mean, CLASS_STD)

        # 合理截断，避免负值过多。
        x = np.maximum(x, [1, 64, 0.1, -95, 0, 0, 0, 0, 0, 0, 0, 0])
        x[3] = np.minimum(x[3], -30)  # RSSI 上界
        x[6] = np.clip(x[6], 0, 1)
        x[7] = np.clip(x[7], 0, 1)
        x[8] = np.clip(x[8], 0, 1)
        x[10] = np.clip(x[10], 0, 1)
        x[11] = np.clip(x[11], 0, 1)

        row = {name: float(val) for name, val in zip(FEATURES, x)}
        row.update(
            {
                "uav_id": f"UAV_{uav_id:03d}",
                "edge_id": f"EDGE_{edge_id:02d}",
                "round_id": round_id,
                "label": label,
                "label_id": label_idx,
            }
        )
        rows.append(row)

    df = pd.DataFrame(rows)
    return df


def main() -> None:
    ensure_dir(DATA_DIR)
    df = generate_synthetic_uav_ids()
    out = DATA_DIR / "synthetic_uav_ids.csv"
    df.to_csv(out, index=False, encoding="utf-8-sig")
    print(f"Synthetic dataset saved to {out} with shape={df.shape}")


if __name__ == "__main__":
    main()
