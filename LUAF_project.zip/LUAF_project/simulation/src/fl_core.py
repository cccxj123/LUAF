from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Union

import numpy as np
from sklearn.metrics import accuracy_score, f1_score, log_loss, precision_score, recall_score, roc_auc_score


def _stable_softmax(logits: np.ndarray) -> np.ndarray:
    """数值稳定版 Softmax：先减去每行最大值，避免 exp 溢出。"""
    z = logits - logits.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / np.clip(e.sum(axis=1, keepdims=True), 1e-12, None)


def _clip_gradients(grads: List[np.ndarray], max_norm: float = 5.0) -> List[np.ndarray]:
    """对一组梯度做全局范数裁剪，防止 MLP 反向传播时梯度爆炸。"""
    total_sq = 0.0
    for grad in grads:
        total_sq += float(np.sum(np.nan_to_num(grad) ** 2))
    total_norm = float(np.sqrt(total_sq))
    if not np.isfinite(total_norm) or total_norm <= max_norm:
        return [np.nan_to_num(grad) for grad in grads]
    scale = max_norm / (total_norm + 1e-12)
    return [np.nan_to_num(grad * scale) for grad in grads]


@dataclass
class SoftmaxModel:
    """轻量 Softmax 回归模型，用于表格型 UAV 入侵检测 FL baseline。"""

    W: np.ndarray
    b: np.ndarray

    @classmethod
    def init(cls, n_features: int, n_classes: int, rng: np.random.Generator) -> "SoftmaxModel":
        W = rng.normal(0, 0.01, size=(n_features, n_classes))
        b = np.zeros(n_classes)
        return cls(W=W, b=b)

    def copy(self) -> "SoftmaxModel":
        return self.clone()

    def clone(self) -> "SoftmaxModel":
        return SoftmaxModel(W=self.W.copy(), b=self.b.copy())

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        return _stable_softmax(X @ self.W + self.b)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)

    def local_train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        epochs: int,
        lr: float,
        batch_size: int,
        l2: float = 0.0,
        rng: np.random.Generator | None = None,
        seed: int | None = None,
    ) -> "SoftmaxModel":
        """Softmax 本地训练：交叉熵 + mini-batch SGD。"""
        local = self.clone()
        n_classes = local.b.shape[0]
        if len(X) == 0:
            return local
        if rng is None:
            rng = np.random.default_rng(0 if seed is None else seed)

        for _ in range(epochs):
            idx = rng.permutation(len(X))
            for start in range(0, len(X), batch_size):
                batch_idx = idx[start : start + batch_size]
                xb, yb = X[batch_idx], y[batch_idx]
                proba = local.predict_proba(xb)
                target = one_hot(yb, n_classes)
                grad_z = (proba - target) / len(xb)
                grad_W = xb.T @ grad_z + l2 * local.W
                grad_b = grad_z.sum(axis=0)
                grad_W, grad_b = _clip_gradients([grad_W, grad_b])
                local.W -= lr * grad_W
                local.b -= lr * grad_b
        return local

    def get_params(self) -> Dict[str, np.ndarray]:
        return {"W": self.W.copy(), "b": self.b.copy()}

    def set_params(self, params: Dict[str, np.ndarray]) -> None:
        self.W = params["W"].copy()
        self.b = params["b"].copy()

    def num_parameters(self) -> int:
        return int(self.W.size + self.b.size)


@dataclass
class MLPModel:
    """轻量 MLP：Input -> Dense(64) -> ReLU -> Dense(32) -> ReLU -> Softmax。"""

    W1: np.ndarray
    b1: np.ndarray
    W2: np.ndarray
    b2: np.ndarray
    W3: np.ndarray
    b3: np.ndarray

    @classmethod
    def init(cls, n_features: int, n_classes: int, rng: np.random.Generator) -> "MLPModel":
        """使用 He/Xavier 类缩放初始化，适配 ReLU 隐藏层并减少数值不稳定。"""
        h1, h2 = 64, 32
        W1 = rng.normal(0.0, np.sqrt(2.0 / max(1, n_features)), size=(n_features, h1))
        b1 = np.zeros(h1)
        W2 = rng.normal(0.0, np.sqrt(2.0 / h1), size=(h1, h2))
        b2 = np.zeros(h2)
        W3 = rng.normal(0.0, np.sqrt(2.0 / (h2 + n_classes)), size=(h2, n_classes))
        b3 = np.zeros(n_classes)
        return cls(W1=W1, b1=b1, W2=W2, b2=b2, W3=W3, b3=b3)

    def copy(self) -> "MLPModel":
        return self.clone()

    def clone(self) -> "MLPModel":
        return MLPModel(
            W1=self.W1.copy(),
            b1=self.b1.copy(),
            W2=self.W2.copy(),
            b2=self.b2.copy(),
            W3=self.W3.copy(),
            b3=self.b3.copy(),
        )

    @staticmethod
    def _relu(x: np.ndarray) -> np.ndarray:
        # ReLU 将负值截断为 0，为 MLP 引入非线性表达能力。
        return np.maximum(0.0, x)

    @staticmethod
    def _relu_grad(x: np.ndarray) -> np.ndarray:
        # ReLU 的反向传播梯度：正区间为 1，非正区间为 0。
        return (x > 0.0).astype(float)

    def _forward(self, X: np.ndarray) -> tuple[np.ndarray, Dict[str, np.ndarray]]:
        """前向传播：两层 ReLU 隐藏层后接 Softmax 输出类别概率。"""
        z1 = X @ self.W1 + self.b1
        a1 = self._relu(z1)
        z2 = a1 @ self.W2 + self.b2
        a2 = self._relu(z2)
        logits = a2 @ self.W3 + self.b3
        proba = _stable_softmax(logits)
        cache = {"z1": z1, "a1": a1, "z2": z2, "a2": a2, "proba": proba}
        return proba, cache

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        proba, _ = self._forward(X)
        return proba

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)

    def local_train(
        self,
        X: np.ndarray,
        y: np.ndarray,
        epochs: int,
        lr: float,
        batch_size: int,
        l2: float = 0.0,
        rng: np.random.Generator | None = None,
        seed: int | None = None,
    ) -> "MLPModel":
        """MLP 本地训练：交叉熵损失、mini-batch SGD、L2 正则和梯度裁剪。"""
        local = self.clone()
        n_classes = local.b3.shape[0]
        if len(X) == 0:
            return local
        if rng is None:
            rng = np.random.default_rng(0 if seed is None else seed)

        for _ in range(epochs):
            idx = rng.permutation(len(X))
            for start in range(0, len(X), batch_size):
                batch_idx = idx[start : start + batch_size]
                xb, yb = X[batch_idx], y[batch_idx]
                proba, cache = local._forward(xb)
                target = one_hot(yb, n_classes)

                # Softmax + 交叉熵的梯度可简化为 proba - one_hot(label)。
                grad_logits = (proba - target) / len(xb)

                # 反向传播依次计算输出层、第二隐藏层、第一隐藏层的参数梯度。
                grad_W3 = cache["a2"].T @ grad_logits + l2 * local.W3
                grad_b3 = grad_logits.sum(axis=0)
                grad_a2 = grad_logits @ local.W3.T
                grad_z2 = grad_a2 * local._relu_grad(cache["z2"])
                grad_W2 = cache["a1"].T @ grad_z2 + l2 * local.W2
                grad_b2 = grad_z2.sum(axis=0)
                grad_a1 = grad_z2 @ local.W2.T
                grad_z1 = grad_a1 * local._relu_grad(cache["z1"])
                grad_W1 = xb.T @ grad_z1 + l2 * local.W1
                grad_b1 = grad_z1.sum(axis=0)

                grad_W1, grad_b1, grad_W2, grad_b2, grad_W3, grad_b3 = _clip_gradients(
                    [grad_W1, grad_b1, grad_W2, grad_b2, grad_W3, grad_b3]
                )
                local.W1 -= lr * grad_W1
                local.b1 -= lr * grad_b1
                local.W2 -= lr * grad_W2
                local.b2 -= lr * grad_b2
                local.W3 -= lr * grad_W3
                local.b3 -= lr * grad_b3
        return local

    def get_params(self) -> Dict[str, np.ndarray]:
        return {
            "W1": self.W1.copy(),
            "b1": self.b1.copy(),
            "W2": self.W2.copy(),
            "b2": self.b2.copy(),
            "W3": self.W3.copy(),
            "b3": self.b3.copy(),
        }

    def set_params(self, params: Dict[str, np.ndarray]) -> None:
        self.W1 = params["W1"].copy()
        self.b1 = params["b1"].copy()
        self.W2 = params["W2"].copy()
        self.b2 = params["b2"].copy()
        self.W3 = params["W3"].copy()
        self.b3 = params["b3"].copy()

    def num_parameters(self) -> int:
        return int(self.W1.size + self.b1.size + self.W2.size + self.b2.size + self.W3.size + self.b3.size)


FLModel = Union[SoftmaxModel, MLPModel]


def one_hot(y: np.ndarray, n_classes: int) -> np.ndarray:
    Y = np.zeros((len(y), n_classes))
    Y[np.arange(len(y)), y.astype(int)] = 1
    return Y


def local_train(
    model: FLModel,
    X: np.ndarray,
    y: np.ndarray,
    lr: float,
    epochs: int,
    batch_size: int,
    rng: np.random.Generator,
    l2: float = 0.0,
) -> FLModel:
    """客户端本地训练入口：Softmax 与 MLP 都走模型自己的 local_train。"""
    return model.local_train(X, y, epochs=epochs, lr=lr, batch_size=batch_size, l2=l2, rng=rng)


def fedavg(global_model: FLModel, client_models: List[FLModel], weights: List[int]) -> FLModel:
    """FedAvg 聚合：对 Softmax 或 MLP 的每个参数矩阵/偏置按样本数加权平均。"""
    if not client_models:
        return global_model.clone()
    total = float(sum(weights))
    if total <= 0:
        return global_model.clone()

    keys = list(global_model.get_params().keys())
    averaged: Dict[str, np.ndarray] = {}
    for key in keys:
        # MLPModel 会分别聚合 W1/b1/W2/b2/W3/b3；SoftmaxModel 会聚合 W/b。
        averaged[key] = sum(m.get_params()[key] * (w / total) for m, w in zip(client_models, weights))

    new_model = global_model.clone()
    new_model.set_params(averaged)
    return new_model


def evaluate_model(model: FLModel, X: np.ndarray, y: np.ndarray) -> Dict[str, float]:
    """计算 Accuracy、weighted Precision/Recall/F1、AUC 和 Log Loss。"""
    pred = model.predict(X)
    proba = model.predict_proba(X)
    out = {
        "accuracy": accuracy_score(y, pred),
        "precision_weighted": precision_score(y, pred, average="weighted", zero_division=0),
        "recall_weighted": recall_score(y, pred, average="weighted", zero_division=0),
        "f1_weighted": f1_score(y, pred, average="weighted", zero_division=0),
        "f1_macro": f1_score(y, pred, average="macro", zero_division=0),
    }
    try:
        if len(np.unique(y)) > 2:
            out["auc_ovr_weighted"] = roc_auc_score(y, proba, multi_class="ovr", average="weighted")
        elif proba.shape[1] > 1:
            out["auc"] = roc_auc_score(y, proba[:, 1])
            out["auc_ovr_weighted"] = out["auc"]
        else:
            out["auc_ovr_weighted"] = np.nan
    except Exception:
        out["auc_ovr_weighted"] = np.nan
    try:
        out["log_loss"] = log_loss(y, proba, labels=np.arange(proba.shape[1]))
    except Exception:
        out["log_loss"] = np.nan
    return out


def model_delta_norm(old: FLModel, new: FLModel) -> float:
    """用于恶意更新检测的简单模型更新范数，兼容 Softmax 与 MLP 参数。"""
    old_params = old.get_params()
    new_params = new.get_params()
    total = 0.0
    for key in old_params:
        total += float(np.sum((new_params[key] - old_params[key]) ** 2))
    return float(np.sqrt(total))
