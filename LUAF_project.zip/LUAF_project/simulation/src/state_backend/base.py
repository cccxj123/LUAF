from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class StaleRevocationListError(RuntimeError):
    """Raised when a caller presents an RL version older than the service."""


class StateBackend(ABC):
    @abstractmethod
    def reserve(self, nf: str, owner: str, ttl_seconds: float = 30.0) -> bool:
        raise NotImplementedError

    @abstractmethod
    def commit(self, nf: str, owner: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def abort(self, nf: str, owner: str) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_nf_state(self, nf: str) -> dict[str, Any] | None:
        raise NotImplementedError

    @abstractmethod
    def revoke(self, cred_id: str) -> int:
        raise NotImplementedError

    @abstractmethod
    def is_revoked(self, cred_id: str, known_version: int | None = None) -> bool:
        raise NotImplementedError

    @abstractmethod
    def get_revocation_version(self) -> int:
        raise NotImplementedError
