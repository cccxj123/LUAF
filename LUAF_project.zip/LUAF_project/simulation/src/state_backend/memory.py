from __future__ import annotations

import threading
import time
from typing import Any

from .base import StateBackend, StaleRevocationListError


class MemoryStateBackend(StateBackend):
    """Thread-safe reference backend used for tests and local simulation."""

    def __init__(self):
        self._lock = threading.RLock()
        self._nf: dict[str, dict[str, Any]] = {}
        self._revoked: set[str] = set()
        self._rl_version = 0

    def _purge_expired(self, nf: str) -> None:
        record = self._nf.get(nf)
        if record and record["status"] == "PENDING" and record["lease_expires_at"] <= time.monotonic():
            self._nf.pop(nf, None)

    def reserve(self, nf: str, owner: str, ttl_seconds: float = 30.0) -> bool:
        if not nf or not owner or ttl_seconds <= 0:
            raise ValueError("nf, owner, and positive ttl_seconds are required")
        with self._lock:
            self._purge_expired(nf)
            if nf in self._nf:
                return False
            self._nf[nf] = {
                "nf": nf,
                "owner": owner,
                "status": "PENDING",
                "lease_expires_at": time.monotonic() + ttl_seconds,
            }
            return True

    def commit(self, nf: str, owner: str) -> bool:
        with self._lock:
            self._purge_expired(nf)
            record = self._nf.get(nf)
            if not record or record["status"] != "PENDING" or record["owner"] != owner:
                return False
            record["status"] = "COMMITTED"
            record["committed_at"] = time.monotonic()
            record.pop("lease_expires_at", None)
            return True

    def abort(self, nf: str, owner: str) -> bool:
        with self._lock:
            self._purge_expired(nf)
            record = self._nf.get(nf)
            if not record or record["status"] != "PENDING" or record["owner"] != owner:
                return False
            self._nf.pop(nf, None)
            return True

    def get_nf_state(self, nf: str) -> dict[str, Any] | None:
        with self._lock:
            self._purge_expired(nf)
            record = self._nf.get(nf)
            return dict(record) if record else None

    def revoke(self, cred_id: str) -> int:
        if not cred_id:
            raise ValueError("cred_id is required")
        with self._lock:
            self._revoked.add(cred_id)
            self._rl_version += 1
            return self._rl_version

    def get_revocation_version(self) -> int:
        with self._lock:
            return self._rl_version

    def is_revoked(self, cred_id: str, known_version: int | None = None) -> bool:
        with self._lock:
            if known_version is not None and known_version != self._rl_version:
                raise StaleRevocationListError(
                    f"stale RL version {known_version}; current version is {self._rl_version}"
                )
            return cred_id in self._revoked
