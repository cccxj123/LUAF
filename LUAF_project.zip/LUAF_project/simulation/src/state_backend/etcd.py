from __future__ import annotations

import hashlib
import json
import time
from typing import Any

from .base import StateBackend, StaleRevocationListError


class EtcdStateBackend(StateBackend):
    """CAS/lease backed state adapter; unavailable etcd fails explicitly."""

    def __init__(self, host: str = "127.0.0.1", port: int = 2379, prefix: str = "/luaf-sm2-fl"):
        try:
            import etcd3
        except ImportError as exc:
            raise RuntimeError("etcd3 is required for EtcdStateBackend; no memory fallback is allowed") from exc
        try:
            self.client = etcd3.client(host=host, port=port)
            self.client.status()
        except Exception as exc:
            raise RuntimeError(f"cannot connect to etcd at {host}:{port}") from exc
        self.prefix = prefix.rstrip("/")

    def _key(self, nf: str) -> str:
        digest = hashlib.sha256(nf.encode("utf-8")).hexdigest()
        return f"{self.prefix}/nf/{digest}"

    def _get(self, key: str) -> tuple[dict[str, Any] | None, Any]:
        value, metadata = self.client.get(key)
        if value is None:
            return None, metadata
        return json.loads(value.decode("utf-8")), metadata

    def reserve(self, nf: str, owner: str, ttl_seconds: float = 30.0) -> bool:
        if ttl_seconds <= 0:
            raise ValueError("ttl_seconds must be positive")
        key = self._key(nf)
        lease = self.client.lease(int(max(1, ttl_seconds)))
        value = {"nf": nf, "owner": owner, "status": "PENDING", "lease_expires_at": time.time() + ttl_seconds}
        tx = self.client.transactions
        succeeded, _ = self.client.transaction(
            compare=[tx.Version(key) == 0],
            success=[tx.Put(key, json.dumps(value, sort_keys=True), lease=lease)],
            failure=[],
        )
        if not succeeded:
            lease.revoke()
        return bool(succeeded)

    def commit(self, nf: str, owner: str) -> bool:
        key = self._key(nf)
        current, metadata = self._get(key)
        if not current or not metadata or current.get("status") != "PENDING" or current.get("owner") != owner:
            return False
        current["status"] = "COMMITTED"
        current.pop("lease_expires_at", None)
        current["committed_at"] = time.time()
        tx = self.client.transactions
        succeeded, _ = self.client.transaction(
            compare=[tx.ModRevision(key) == metadata.mod_revision],
            success=[tx.Put(key, json.dumps(current, sort_keys=True))],
            failure=[],
        )
        return bool(succeeded)

    def abort(self, nf: str, owner: str) -> bool:
        key = self._key(nf)
        current, metadata = self._get(key)
        if not current or not metadata or current.get("status") != "PENDING" or current.get("owner") != owner:
            return False
        tx = self.client.transactions
        succeeded, _ = self.client.transaction(
            compare=[tx.ModRevision(key) == metadata.mod_revision],
            success=[tx.Delete(key)],
            failure=[],
        )
        return bool(succeeded)

    def get_nf_state(self, nf: str) -> dict[str, Any] | None:
        current, _ = self._get(self._key(nf))
        return current

    def revoke(self, cred_id: str) -> int:
        key = f"{self.prefix}/rl/cred/{hashlib.sha256(cred_id.encode()).hexdigest()}"
        self.client.put(key, cred_id)
        version_key = f"{self.prefix}/rl/version"
        while True:
            value, metadata = self.client.get(version_key)
            current = int(value.decode()) if value else 0
            tx = self.client.transactions
            succeeded, _ = self.client.transaction(
                compare=[tx.Version(version_key) == (metadata.version if metadata else 0)],
                success=[tx.Put(version_key, str(current + 1))],
                failure=[],
            )
            if succeeded:
                return current + 1

    def get_revocation_version(self) -> int:
        value, _ = self.client.get(f"{self.prefix}/rl/version")
        return int(value.decode()) if value else 0

    def is_revoked(self, cred_id: str, known_version: int | None = None) -> bool:
        current = self.get_revocation_version()
        if known_version is not None and known_version != current:
            raise StaleRevocationListError(f"stale RL version {known_version}; current version is {current}")
        key = f"{self.prefix}/rl/cred/{hashlib.sha256(cred_id.encode()).hexdigest()}"
        value, _ = self.client.get(key)
        return value is not None
