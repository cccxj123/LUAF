from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import pandas as pd


# 真实数据集常见编码列表：优先尝试 UTF-8，再尝试中文 Windows 编码和西文兼容编码。
CSV_ENCODINGS = [
    "utf-8",
    "utf-8-sig",
    "gb18030",
    "gbk",
    "cp936",
    "cp1252",
    "latin1",
    "ISO-8859-1",
]


LABEL_CANDIDATES = [
    "label",
    "Label",
    "LABEL",
    "label_id",
    "Label_ID",
    "label id",
    "class",
    "Class",
    "CLASS",
    "target",
    "Target",
    "attack",
    "Attack",
    "Attack_Type",
    "Attack Type",
    "attack_type",
    "category",
    "Category",
    "type",
    "Type",
]


def read_csv_robust(path: str | Path, **kwargs: Any) -> tuple[pd.DataFrame, str]:
    """用多种编码读取 CSV，避免真实数据集在 Windows/Excel 导出后出现解码失败。

    返回：
        df: pandas DataFrame
        used_encoding: 实际成功使用的编码名称
    """
    csv_path = Path(path)
    read_kwargs = dict(kwargs)
    read_kwargs.pop("encoding", None)

    last_error: Exception | None = None

    # 第一轮：使用 pandas 默认 C engine，速度快，适合绝大多数标准 CSV。
    for encoding in CSV_ENCODINGS:
        try:
            df = pd.read_csv(csv_path, encoding=encoding, **read_kwargs)
            return df, encoding
        except Exception as exc:  # noqa: BLE001 - 这里需要保留最后一次异常用于清晰报错。
            last_error = exc

    # 第二轮：部分真实 CSV 分隔符不稳定，使用 python engine 自动猜测分隔符。
    fallback_kwargs = dict(read_kwargs)
    fallback_kwargs.pop("engine", None)
    fallback_kwargs.pop("sep", None)
    fallback_kwargs.pop("delimiter", None)
    fallback_kwargs.pop("low_memory", None)
    for encoding in CSV_ENCODINGS:
        try:
            df = pd.read_csv(csv_path, encoding=encoding, engine="python", sep=None, **fallback_kwargs)
            return df, encoding
        except Exception as exc:  # noqa: BLE001 - 同上，记录最后一次失败原因。
            last_error = exc

    raise UnicodeError(
        f"无法读取 CSV 文件：{csv_path}\n"
        f"已尝试编码：{', '.join(CSV_ENCODINGS)}；并尝试 engine='python', sep=None。\n"
        f"最后一次异常：{type(last_error).__name__}: {last_error}"
    ) from last_error


def read_table_robust(path: str | Path) -> tuple[pd.DataFrame, str, str | None]:
    """根据文件后缀读取 CSV 或 Excel，并返回来源类型和编码信息。"""
    table_path = Path(path)
    suffix = table_path.suffix.lower()
    magic = b""
    if table_path.exists():
        with table_path.open("rb") as file_obj:
            magic = file_obj.read(4)

    # 有些数据文件扩展名写成 .csv，但实际内容是 Excel/OpenXML 压缩包，文件头为 PK。
    # 这类文件不能按文本 CSV 解码，直接交给 pandas.read_excel。
    if magic.startswith(b"PK\x03\x04"):
        df = pd.read_excel(table_path)
        source_type = "excel" if suffix in {".xlsx", ".xls"} else "excel-mislabeled"
        return df, source_type, None

    if suffix == ".csv":
        df, used_encoding = read_csv_robust(table_path)
        return df, "csv", used_encoding

    if suffix in {".xlsx", ".xls"}:
        # Excel 文件本身不是文本编码；used_encoding 用 None 表示不适用。
        df = pd.read_excel(table_path)
        return df, "excel", None

    raise ValueError(f"不支持的文件类型：{table_path}。仅支持 .csv、.xlsx、.xls。")


def _normalize_label_name(name: str) -> str:
    """把列名规范化，便于匹配 Label、label id、Attack_Type 等写法。"""
    value = str(name).strip().replace("\ufeff", "")
    value = re.sub(r"[_\-]+", " ", value)
    value = re.sub(r"\s+", " ", value)
    return value.lower()


def guess_label_column(df: pd.DataFrame, user_label: str | None = None) -> str:
    """自动识别标签列；识别失败时提示用户用 --label 手动指定。"""
    columns = [str(col) for col in df.columns]

    if user_label:
        if user_label in df.columns:
            return user_label
        normalized_user_label = _normalize_label_name(user_label)
        for col in columns:
            if _normalize_label_name(col) == normalized_user_label:
                return col
        print("当前数据列名：")
        for col in columns:
            print(f"  - {col}")
        raise ValueError(f"用户指定的标签列不存在：{user_label}")

    for candidate in LABEL_CANDIDATES:
        if candidate in df.columns:
            return candidate

    normalized_candidates = {_normalize_label_name(candidate) for candidate in LABEL_CANDIDATES}
    for col in columns:
        if _normalize_label_name(col) in normalized_candidates:
            return col

    print("当前数据列名：")
    for col in columns:
        print(f"  - {col}")
    raise ValueError("无法自动识别标签列，请使用 --label 指定，例如 --label Label。")


def safe_filename(name: str | Path) -> str:
    """把路径或文件名转换为安全文件名片段，只保留字母、数字、下划线和短横线。"""
    raw_name = Path(str(name)).name
    suffix = Path(raw_name).suffix.lower()
    # 只有明确是数据/报告文件扩展名时才去掉后缀；字段名里的点号不能被误认为扩展名。
    stem = Path(raw_name).stem if suffix in {".csv", ".xlsx", ".xls", ".json", ".txt"} else raw_name
    safe = re.sub(r"[^A-Za-z0-9_-]+", "_", stem)
    safe = re.sub(r"_+", "_", safe).strip("_")
    return safe or "dataset"
