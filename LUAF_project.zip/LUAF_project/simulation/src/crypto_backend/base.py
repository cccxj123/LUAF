from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


class BackendUnavailableError(RuntimeError):
    """The requested external cryptographic backend is not installed."""


class BackendCapabilityError(RuntimeError):
    """The backend exists but cannot provide a requested primitive."""


@dataclass(frozen=True)
class BackendInfo:
    name: str
    version: str
    real_sm2_ake: bool
    simulated: bool


class CryptoBackend(ABC):
    @property
    @abstractmethod
    def info(self) -> BackendInfo:
        raise NotImplementedError

    @abstractmethod
    def sm3_digest(self, data: bytes) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def sm2_sign(self, message: bytes, private_key: bytes) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def sm2_verify(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        raise NotImplementedError

    @abstractmethod
    def sm2_encrypt(self, message: bytes, public_key: bytes) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def sm2_decrypt(self, ciphertext: bytes, private_key: bytes) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def sm4_gcm_encrypt(self, plaintext: bytes, key: bytes, nonce: bytes, aad: bytes = b"") -> tuple[bytes, bytes]:
        raise NotImplementedError

    @abstractmethod
    def sm4_gcm_decrypt(
        self, ciphertext: bytes, tag: bytes, key: bytes, nonce: bytes, aad: bytes = b""
    ) -> bytes:
        raise NotImplementedError

    @abstractmethod
    def derive_session_key(self, shared_secret: bytes, context: bytes, length: int = 32) -> bytes:
        raise NotImplementedError
