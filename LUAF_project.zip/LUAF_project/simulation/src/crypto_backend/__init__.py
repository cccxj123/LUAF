"""Explicit simulated and Tongsuo crypto backends."""

from .base import BackendCapabilityError, BackendUnavailableError, CryptoBackend
from .simulated import SimulatedCryptoBackend
from .tongsuo import TongsuoCryptoBackend


def create_backend(name: str = "simulated") -> CryptoBackend:
    normalized = name.lower()
    if normalized in {"simulated", "simulation"}:
        return SimulatedCryptoBackend()
    if normalized in {"tongsuo", "real"}:
        return TongsuoCryptoBackend()
    raise ValueError("crypto backend must be simulated or tongsuo")


__all__ = [
    "BackendCapabilityError",
    "BackendUnavailableError",
    "CryptoBackend",
    "SimulatedCryptoBackend",
    "TongsuoCryptoBackend",
    "create_backend",
]
