from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from .base import BackendCapabilityError, BackendInfo, BackendUnavailableError, CryptoBackend


class TongsuoCryptoBackend(CryptoBackend):
    """Fail-closed adapter for a Tongsuo/OpenSSL-compatible CLI.

    Only SM3 digest is wired because it has a stable streaming CLI contract.
    SM2 key operations, SM4-GCM, and a complete SM2-AKE need a version-pinned
    provider/key-format integration and therefore raise explicitly here.
    """

    def __init__(self, binary: str | None = None):
        requested = binary or os.environ.get("TONGSUO_BIN") or shutil.which("tongsuo")
        if not requested:
            raise BackendUnavailableError(
                "Tongsuo is unavailable; set TONGSUO_BIN to a version-pinned tongsuo executable. "
                "No simulated fallback is permitted for the real backend."
            )
        self.binary = str(Path(requested))
        try:
            result = subprocess.run([self.binary, "version"], capture_output=True, text=True, check=True, timeout=10)
        except (OSError, subprocess.SubprocessError) as exc:
            raise BackendUnavailableError(f"cannot execute Tongsuo binary {self.binary!r}: {exc}") from exc
        self.version = (result.stdout or result.stderr).strip().splitlines()[0]

    @property
    def info(self) -> BackendInfo:
        return BackendInfo("tongsuo", self.version, False, False)

    def _run(self, args: list[str], data: bytes) -> bytes:
        try:
            result = subprocess.run(
                [self.binary, *args], input=data, capture_output=True, check=True, timeout=30
            )
        except (OSError, subprocess.SubprocessError) as exc:
            raise BackendCapabilityError(f"Tongsuo command failed: {args!r}: {exc}") from exc
        return result.stdout

    def sm3_digest(self, data: bytes) -> bytes:
        return self._run(["dgst", "-sm3", "-binary"], data)

    def _unsupported(self, primitive: str) -> None:
        raise BackendCapabilityError(
            f"Tongsuo backend does not claim {primitive}; install the pinned provider/key integration "
            "before reporting real measurements."
        )

    def sm2_sign(self, message: bytes, private_key: bytes) -> bytes:
        self._unsupported("SM2 signing")

    def sm2_verify(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        self._unsupported("SM2 verification")

    def sm2_encrypt(self, message: bytes, public_key: bytes) -> bytes:
        self._unsupported("SM2 encryption")

    def sm2_decrypt(self, ciphertext: bytes, private_key: bytes) -> bytes:
        self._unsupported("SM2 decryption")

    def sm4_gcm_encrypt(self, plaintext: bytes, key: bytes, nonce: bytes, aad: bytes = b"") -> tuple[bytes, bytes]:
        self._unsupported("SM4-GCM")

    def sm4_gcm_decrypt(
        self, ciphertext: bytes, tag: bytes, key: bytes, nonce: bytes, aad: bytes = b""
    ) -> bytes:
        self._unsupported("SM4-GCM")

    def derive_session_key(self, shared_secret: bytes, context: bytes, length: int = 32) -> bytes:
        self._unsupported("complete SM2-AKE; real_sm2_ake=false")
