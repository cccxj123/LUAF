from __future__ import annotations

import hashlib
import hmac

from .base import BackendInfo, CryptoBackend


def _keystream(key: bytes, nonce: bytes, length: int) -> bytes:
    output = bytearray()
    counter = 0
    while len(output) < length:
        output.extend(hashlib.sha256(key + nonce + counter.to_bytes(4, "big")).digest())
        counter += 1
    return bytes(output[:length])


class SimulatedCryptoBackend(CryptoBackend):
    """Deterministic test primitive; it is not a compliant SM2/SM4 backend."""

    @property
    def info(self) -> BackendInfo:
        return BackendInfo("simulated", "project-simulation", False, True)

    def sm3_digest(self, data: bytes) -> bytes:
        try:
            return hashlib.new("sm3", data).digest()
        except ValueError:
            return hashlib.sha256(data).digest()

    def sm2_sign(self, message: bytes, private_key: bytes) -> bytes:
        return hmac.new(private_key, b"SIM-SM2-SIGN|" + message, hashlib.sha256).digest()

    def sm2_verify(self, message: bytes, signature: bytes, public_key: bytes) -> bool:
        return hmac.compare_digest(signature, self.sm2_sign(message, public_key))

    def sm2_encrypt(self, message: bytes, public_key: bytes) -> bytes:
        nonce = hashlib.sha256(b"SIM-SM2-NONCE|" + public_key + message).digest()[:12]
        stream = _keystream(public_key, nonce, len(message))
        ciphertext = bytes(left ^ right for left, right in zip(message, stream))
        tag = hmac.new(public_key, nonce + ciphertext, hashlib.sha256).digest()[:16]
        return nonce + tag + ciphertext

    def sm2_decrypt(self, ciphertext: bytes, private_key: bytes) -> bytes:
        if len(ciphertext) < 28:
            raise ValueError("invalid simulated ciphertext")
        nonce, tag, body = ciphertext[:12], ciphertext[12:28], ciphertext[28:]
        expected = hmac.new(private_key, nonce + body, hashlib.sha256).digest()[:16]
        if not hmac.compare_digest(tag, expected):
            raise ValueError("simulated ciphertext authentication failed")
        stream = _keystream(private_key, nonce, len(body))
        return bytes(left ^ right for left, right in zip(body, stream))

    def sm4_gcm_encrypt(self, plaintext: bytes, key: bytes, nonce: bytes, aad: bytes = b"") -> tuple[bytes, bytes]:
        stream = _keystream(key, nonce, len(plaintext))
        ciphertext = bytes(left ^ right for left, right in zip(plaintext, stream))
        tag = hmac.new(key, aad + nonce + ciphertext, hashlib.sha256).digest()[:16]
        return ciphertext, tag

    def sm4_gcm_decrypt(
        self, ciphertext: bytes, tag: bytes, key: bytes, nonce: bytes, aad: bytes = b""
    ) -> bytes:
        expected = hmac.new(key, aad + nonce + ciphertext, hashlib.sha256).digest()[:16]
        if not hmac.compare_digest(tag, expected):
            raise ValueError("simulated SM4 tag verification failed")
        stream = _keystream(key, nonce, len(ciphertext))
        return bytes(left ^ right for left, right in zip(ciphertext, stream))

    def derive_session_key(self, shared_secret: bytes, context: bytes, length: int = 32) -> bytes:
        if length <= 0:
            raise ValueError("length must be positive")
        return hashlib.sha256(b"SIM-SM2-AKE|" + shared_secret + context).digest()[:length]
