from __future__ import annotations

import hashlib
import os
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from .config import SimConfig
from .crypto_sim import message_size_bytes, simulate_protocol_latency
from .data_loader import FLDataset
from .fl_core import FLModel, MLPModel, SoftmaxModel, evaluate_model, fedavg, local_train, model_delta_norm
from .luaf_protocol import Auditor, EdgeVerifier, NFStateCache, TACAA, UAVClientProtocol, make_ctx
from .reproducibility import code_fingerprint, make_rng, model_digest, run_id


@dataclass
class FLRunResult:
    metrics_by_round: pd.DataFrame
    event_log: pd.DataFrame
    final_model: FLModel
    selected_clients_by_round: Dict[str, List[str]]
    malicious_clients_by_round: Dict[str, List[str]]
    initial_model_hash: str


def _stable_offset(*parts: object) -> int:
    raw = "|".join(str(part) for part in parts if part is not None).encode("utf-8")
    return int.from_bytes(hashlib.sha256(raw).digest()[:4], "big") % 10000


def _init_model(model_type: str, n_features: int, n_classes: int, rng: np.random.Generator) -> FLModel:
    if model_type.lower() == "mlp":
        return MLPModel.init(n_features, n_classes, rng)
    return SoftmaxModel.init(n_features, n_classes, rng)


def _model_update_bytes(model: FLModel, cfg: SimConfig, use_actual_model_update_bytes: bool) -> int:
    if use_actual_model_update_bytes:
        return int(model.num_parameters() * 8)
    return int(cfg.model_update_bytes)


def _training_compute_latency_ms(model: FLModel, n_samples: int, cfg: SimConfig) -> float:
    batches = max(1, int(np.ceil(max(1, n_samples) / max(1, cfg.batch_size)))) * max(1, cfg.local_epochs)
    params_k = model.num_parameters() / 1000.0
    return float(params_k * batches * 0.25)


def select_clients(client_ids: List[str], rate: float, rng: np.random.Generator) -> List[str]:
    if not client_ids:
        return []
    if not 0 < rate <= 1:
        raise ValueError("participation rate must be in (0, 1]")
    k = min(max(1, int(len(client_ids) * rate)), len(client_ids))
    return list(rng.choice(client_ids, size=k, replace=False))


def run_fl_simulation(
    dataset: FLDataset,
    cfg: SimConfig,
    scheme: str = "LUAF-SM2-FL",
    attack_mode: Optional[str] = None,
    revoked_fraction: float = 0.0,
    poisoning_fraction: float = 0.0,
    model_type: str = "softmax",
    l2: float = 0.0,
    include_training_in_round_latency: bool = False,
    use_actual_model_update_bytes: bool = False,
    dataset_name: str = "unknown",
) -> FLRunResult:
    """Run the FL simulator with independent deterministic RNG streams."""
    if not 0 <= poisoning_fraction <= 1:
        raise ValueError("poisoning_fraction must be between 0 and 1")
    if not 0 <= revoked_fraction <= 1:
        raise ValueError("revoked_fraction must be between 0 and 1")

    clients = list(dataset.train_by_client.keys())
    n_features = dataset.X_test.shape[1]
    n_classes = max(len(dataset.label_names), int(np.max(dataset.y_test)) + 1)
    # This stream is intentionally independent of scheme. It is the fairness
    # anchor shared by Plain, SM2, DynPID, and LUAF runs.
    model_rng = make_rng(cfg.seed, "model_init", model_type)
    global_model = _init_model(model_type, n_features, n_classes, model_rng)
    initial_model_hash = model_digest(global_model)
    update_bytes = _model_update_bytes(global_model, cfg, use_actual_model_update_bytes)
    runtime_cfg = replace(cfg, model_update_bytes=update_bytes)
    source_root = Path(__file__).resolve().parents[1]
    fingerprint = code_fingerprint(source_root)
    normalized_model_type = "MLP" if model_type.lower() == "mlp" else "Softmax"
    run_identifier = run_id(dataset_name, scheme, normalized_model_type, cfg.seed)
    timestamp_utc = datetime.now(timezone.utc).isoformat()

    ta = TACAA(limit_L=cfg.credential_limit_L, rng=make_rng(cfg.seed, "crypto", scheme, "ta"))
    nf_cache = NFStateCache()
    edge = EdgeVerifier(nf_cache=nf_cache, ta=ta)
    auditor = Auditor(ta)
    protocols: Dict[str, UAVClientProtocol] = {}
    for cid in clients:
        cred = ta.issue_credential(cid, epoch=0)
        protocols[cid] = UAVClientProtocol(cid, cred, rng=make_rng(cfg.seed, "crypto", scheme, cid))

    if revoked_fraction > 0 and clients:
        revoke_count = int(len(clients) * revoked_fraction)
        revoke_rng = make_rng(cfg.seed, "attack", "revocation")
        for cid in revoke_rng.choice(clients, size=revoke_count, replace=False):
            ta.revoke_uav(cid)
            nf_cache.publish_revocation(ta.get_credential(cid).cred_id)

    selection_rng = make_rng(cfg.seed, "client_selection")
    metrics_rows: list[dict] = []
    events: list[dict] = []
    selected_by_round: Dict[str, List[str]] = {}
    malicious_by_round: Dict[str, List[str]] = {}
    old_m1_by_client = {}

    def event_row(round_id: int, cid: str, event: str, reason: str, malicious: bool) -> dict:
        return {
            "round": round_id,
            "client": cid,
            "event": event,
            "reason": reason,
            "scheme": scheme,
            "model_type": normalized_model_type,
            "seed": cfg.seed,
            "run_id": run_identifier,
            "is_malicious": bool(malicious),
        }

    for round_id in range(cfg.num_rounds):
        ctx = make_ctx("ZONE-17", epoch=0, mission="uav_ids", edge_group="EG-01", round_id=round_id)
        selected = select_clients(clients, cfg.participation_rate, selection_rng)
        selected_by_round[str(round_id)] = list(selected)
        local_models = []
        weights = []
        accepted = 0
        rejected = 0
        protocol_latency_ms = 0.0
        train_latency_ms = 0.0
        total_comm_bytes = 0
        audit_open_count = 0
        malicious_clients: list[str] = []

        client_inputs: dict[str, tuple[np.ndarray, np.ndarray, bool, np.random.Generator]] = {}
        for cid in selected:
            X, y = dataset.train_by_client[cid]
            attack_rng = make_rng(cfg.seed, "attack", attack_mode or "none", round_id, cid)
            # Poisoning requires both the poisoning mode and the configured
            # Bernoulli draw. The previous OR predicate ignored the fraction.
            is_malicious = attack_mode == "poisoning" and attack_rng.random() < poisoning_fraction
            if is_malicious:
                malicious_clients.append(cid)
            train_y = (y + 1) % n_classes if is_malicious and len(y) else y.copy()
            client_inputs[cid] = (X, train_y, is_malicious, attack_rng)

        def train_client(cid: str) -> FLModel:
            X, train_y, _is_malicious, _attack_rng = client_inputs[cid]
            local_model = local_train(
                global_model,
                X,
                train_y,
                runtime_cfg.lr,
                runtime_cfg.local_epochs,
                runtime_cfg.batch_size,
                make_rng(cfg.seed, "local_batch", model_type, round_id, cid),
                l2=l2,
            )
            return local_model

        # Client local models are independent within a round. Parallelizing
        # this block keeps the exact per-client RNG and selected order while
        # avoiding a long serial loop on large prepared UAV datasets.
        worker_count = min(len(selected), max(1, min(8, os.cpu_count() or 1)))
        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            trained_models = dict(zip(selected, executor.map(train_client, selected)))

        for cid in selected:
            X, _train_y, is_malicious, attack_rng = client_inputs[cid]
            local_model = trained_models[cid]
            # Wall-clock timing is intentionally excluded from reported
            # simulation metrics; it is noisy and cannot be a WAN claim.
            train_latency_ms += _training_compute_latency_ms(local_model, len(X), runtime_cfg)
            protocol_rng = make_rng(cfg.seed, "protocol_jitter", scheme, model_type, round_id, cid)
            lat = simulate_protocol_latency(scheme, runtime_cfg, protocol_rng)
            protocol_latency_ms += lat.total_ms

            if scheme.lower() == "plain-fl":
                accepted += 1
                local_models.append(local_model)
                weights.append(len(X))
                total_comm_bytes += update_bytes
                events.append(event_row(round_id, cid, "accept", "accept", is_malicious))
                continue

            proto = protocols[cid]
            double_spend_rng = make_rng(cfg.seed, "attack", "double_spend", round_id, cid)
            if attack_mode == "double_spend" and cid in old_m1_by_client and double_spend_rng.random() < 0.6:
                m1 = old_m1_by_client[cid]
            else:
                m1 = proto.generate_m1(ctx)
                old_m1_by_client.setdefault(cid, m1)

            total_comm_bytes += message_size_bytes(scheme, runtime_cfg)
            if scheme.lower() in {"sm2-fl", "dynpid-sm2-fl"}:
                verify_accept = True
                reason = "accept"
            else:
                result = edge.verify_m1(m1)
                verify_accept = result.accept
                reason = result.reason

            if not verify_accept:
                rejected += 1
                events.append(event_row(round_id, cid, "reject", reason, is_malicious))
                if reason in {"double_spending", "revoked"}:
                    auditor.open_identity(m1)
                    audit_open_count += 1
                continue

            if is_malicious:
                delta_norm = model_delta_norm(global_model, local_model)
                detected = delta_norm > 1.5 or attack_rng.random() < 0.35
                if detected:
                    events.append(event_row(round_id, cid, "audit", "malicious_update", is_malicious))
                    auditor.open_identity(m1)
                    audit_open_count += 1
                    continue

            accepted += 1
            local_models.append(local_model)
            weights.append(len(X))
            total_comm_bytes += update_bytes
            events.append(event_row(round_id, cid, "accept", "accept", is_malicious))

        malicious_by_round[str(round_id)] = list(malicious_clients)
        if local_models:
            global_model = fedavg(global_model, local_models, weights)

        metrics = evaluate_model(global_model, dataset.X_test, dataset.y_test)
        round_latency_ms = protocol_latency_ms + train_latency_ms if include_training_in_round_latency else protocol_latency_ms
        selected_count = len(selected)
        metrics.update(
            {
                "round": round_id,
                "scheme": scheme,
                "model_type": normalized_model_type,
                "seed": cfg.seed,
                "run_id": run_identifier,
                "dataset": dataset_name,
                "timestamp_utc": timestamp_utc,
                "code_fingerprint": fingerprint,
                "accepted_updates": accepted,
                "rejected_requests": rejected,
                "accepted_clients": accepted,
                "rejected_clients": rejected,
                "audit_open_count": audit_open_count,
                "train_latency_ms": train_latency_ms,
                "protocol_latency_ms": protocol_latency_ms,
                "round_latency_ms": round_latency_ms,
                "round_comm_bytes": total_comm_bytes,
                "communication_bytes": total_comm_bytes,
                "model_update_bytes": update_bytes,
                "num_model_parameters": global_model.num_parameters(),
                "configured_poisoning_fraction": poisoning_fraction,
                "selected_clients": selected_count,
                "realized_malicious_clients": len(malicious_clients),
                "realized_poisoning_fraction": (len(malicious_clients) / selected_count if selected_count else 0.0),
                "poisoning_detection_delta_norm_threshold": 1.5,
                "isolation_rule": "audit_identity_opening_only_in_core_simulator",
            }
        )
        metrics_rows.append(metrics)

    return FLRunResult(
        pd.DataFrame(metrics_rows),
        pd.DataFrame(events),
        global_model,
        selected_clients_by_round=selected_by_round,
        malicious_clients_by_round=malicious_by_round,
        initial_model_hash=initial_model_hash,
    )
