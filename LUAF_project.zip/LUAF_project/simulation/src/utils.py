import json
import os
import random
from pathlib import Path
from typing import Any, Dict

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"


def ensure_dir(path: str | Path) -> Path:
    """创建目录并返回 Path 对象。"""
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def set_seed(seed: int) -> None:
    """固定随机种子，保证实验可复现。"""
    random.seed(seed)
    np.random.seed(seed)


def save_json(obj: Dict[str, Any], path: str | Path) -> None:
    """保存 JSON 配置或结果。"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def write_csv(df: pd.DataFrame, path: str | Path) -> None:
    """保存 CSV，自动创建父目录。"""
    path = Path(path)
    ensure_dir(path.parent)
    df.to_csv(path, index=False, encoding="utf-8-sig")


def simple_line_plot(df: pd.DataFrame, x: str, ys: list[str], title: str, ylabel: str, out: str | Path) -> None:
    """绘制折线图。按要求只使用 matplotlib，不使用 seaborn。"""
    plt.figure(figsize=(8, 4.8))
    for y in ys:
        if y in df.columns:
            plt.plot(df[x], df[y], marker="o", linewidth=1.8, label=y)
    plt.title(title)
    plt.xlabel(x)
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(Path(out).parent)
    plt.savefig(out, dpi=200)
    plt.close()


def bar_plot(labels: list[str], values: list[float], title: str, ylabel: str, out: str | Path, rotation: int = 20) -> None:
    """绘制柱状图。"""
    plt.figure(figsize=(8, 4.8))
    x = np.arange(len(labels))
    plt.bar(x, values)
    plt.xticks(x, labels, rotation=rotation, ha="right")
    plt.title(title)
    plt.ylabel(ylabel)
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(Path(out).parent)
    plt.savefig(out, dpi=200)
    plt.close()


def grouped_bar_plot(df: pd.DataFrame, x_col: str, group_col: str, y_col: str, title: str, ylabel: str, out: str | Path) -> None:
    """绘制分组柱状图。"""
    pivot = df.pivot(index=x_col, columns=group_col, values=y_col)
    ax = pivot.plot(kind="bar", figsize=(9, 5))
    ax.set_title(title)
    ax.set_ylabel(ylabel)
    ax.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(Path(out).parent)
    plt.savefig(out, dpi=200)
    plt.close()


def box_plot(data: list[np.ndarray], labels: list[str], title: str, ylabel: str, out: str | Path) -> None:
    """绘制箱线图，用于时延分布。"""
    plt.figure(figsize=(8, 4.8))
    plt.boxplot(data, labels=labels, showfliers=False)
    plt.title(title)
    plt.ylabel(ylabel)
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(Path(out).parent)
    plt.savefig(out, dpi=200)
    plt.close()


def resolve_out_dir(out: str | Path | None) -> Path:
    """统一解析实验输出目录。"""
    if out is None:
        out = RESULTS_DIR
    return ensure_dir(out)
