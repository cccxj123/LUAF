from __future__ import annotations

import hashlib
import os
import secrets
import time
from dataclasses import dataclass
from typing import Tuple

import numpy as np

from .config import SimConfig


try:
    # Python 3.11+ 在 OpenSSL 支持时可能包含 sm3；不支持时回退 sha256。
    hashlib.new("sm3")
    _HAS_SM3 = True
except Exception:
    _HAS_SM3 = False


def sm3_hash(data: bytes) -> bytes:
    """SM3 哈希包装。

    若当前 Python/OpenSSL 环境不支持 SM3，则回退到 SHA-256。
    论文最终实验建议使用 GmSSL、Tongsuo 或硬件国密模块替换。
    """
    if _HAS_SM3:
        h = hashlib.new("sm3")
        h.update(data)
        return h.digest()
    return hashlib.sha256(data).digest()


def hex_hash(data: bytes, n: int = 16) -> str:
    """返回短哈希字符串，便于日志展示。"""
    return sm3_hash(data).hex()[:n]


def rand_bytes(n: int = 32, rng: np.random.Generator | None = None) -> bytes:
    """生成密码学随机字节。"""
    if rng is None:
        return secrets.token_bytes(n)
    return rng.integers(0, 256, size=n, dtype=np.uint8).tobytes()


@dataclass
class LatencySample:
    """协议执行一次的时延统计，单位 ms。"""

    m1_gen_ms: float
    verify_ms: float
    nf_lookup_ms: float
    rl_lookup_ms: float
    sm2_ake_ms: float
    encrypt_ms: float
    total_ms: float


def jittered(value: float, rng: np.random.Generator, rel_std: float = 0.10) -> float:
    """对基础时延加入小幅抖动，模拟不同设备/网络状态。"""
    return max(0.0, float(rng.normal(value, max(value * rel_std, 0.001))))


def estimate_sm4_latency(update_bytes: int, cfg: SimConfig, rng: np.random.Generator) -> float:
    """估计 SM4-GCM 加密模型更新的耗时。"""
    kb = max(1, update_bytes / 1024.0)
    return jittered(kb * cfg.latency_sm4_per_kb_ms, rng, 0.15)


def simulate_protocol_latency(scheme: str, cfg: SimConfig, rng: np.random.Generator) -> LatencySample:
    """模拟一次接入流程的协议开销。

    scheme:
    - Plain-FL: 无认证密钥协商开销
    - SM2-FL: 标准 SM2-AKE
    - DynPID-SM2-FL: 动态伪名 + SM2-AKE
    - LUAF-SM2-FL: 限次匿名凭证 + NF/RL + SM2-AKE
    """
    scheme = scheme.lower()
    if scheme == "plain-fl":
        m1 = verify = nf = rl = ake = 0.0
    elif scheme == "sm2-fl":
        m1 = jittered(0.20, rng)
        verify = jittered(0.20, rng)
        nf = rl = 0.0
        ake = jittered(cfg.latency_sm2_ake_ms, rng)
    elif scheme == "dynpid-sm2-fl":
        m1 = jittered(0.35, rng)
        verify = jittered(0.50, rng)
        nf = rl = 0.0
        ake = jittered(cfg.latency_sm2_ake_dynpid_ms, rng)
    else:
        # LUAF-SM2-FL，包含匿名凭证证明验证、NF/RL 检查。
        m1 = jittered(cfg.latency_m1_gen_ms, rng)
        verify = jittered(cfg.latency_m1_verify_ms, rng)
        nf = jittered(cfg.latency_nf_lookup_ms, rng)
        rl = jittered(cfg.latency_rl_lookup_ms, rng)
        ake = jittered(cfg.latency_sm2_ake_ms, rng)

    enc = estimate_sm4_latency(cfg.model_update_bytes, cfg, rng)
    total = m1 + verify + nf + rl + ake + enc
    return LatencySample(m1, verify, nf, rl, ake, enc, total)


def message_size_bytes(scheme: str, cfg: SimConfig) -> int:
    """估算单次握手消息通信量。"""
    scheme = scheme.lower()
    if scheme == "plain-fl":
        return 0
    if scheme == "sm2-fl":
        # R_U + R_E + Cert_E + confirm 双向 + timestamp
        return cfg.bytes_ru + cfg.bytes_re + cfg.bytes_cert_edge + 2 * cfg.bytes_confirm + 2 * cfg.bytes_timestamp
    if scheme == "dynpid-sm2-fl":
        # 动态伪名 + 一次性点 + SM2-AKE
        return 32 + cfg.bytes_q + cfg.bytes_ru + cfg.bytes_re + cfg.bytes_cert_edge + 2 * cfg.bytes_confirm + 2 * cfg.bytes_timestamp
    # LUAF M1 + M2 + M3
    m1 = cfg.bytes_asid + cfg.bytes_q + cfg.bytes_ru + cfg.bytes_nf + cfg.bytes_ctx + cfg.bytes_pi + cfg.bytes_copen + cfg.bytes_timestamp
    m2 = cfg.bytes_re + cfg.bytes_cert_edge + cfg.bytes_confirm + cfg.bytes_timestamp
    m3 = cfg.bytes_confirm
    return m1 + m2 + m3
