from __future__ import annotations

import argparse
import traceback
from pathlib import Path

from experiments import exp_01_fl_baseline, exp_02_protocol_overhead, exp_03_double_spend, exp_04_revocation
from experiments import exp_05_linkability, exp_06_mobility, exp_07_poisoning_audit, exp_08_ablation
from experiments import exp_09_model_comparison
from src.reproducibility import FORMAL_SEEDS


def main() -> None:
    parser = argparse.ArgumentParser(description="Run all LUAF-SM2-FL experiments.")
    parser.add_argument("--out", default="results", help="输出目录")
    parser.add_argument("--data", default=None, help="可选真实数据集路径")
    parser.add_argument("--quick", action="store_true", help="快速模式，适合首次测试")
    parser.add_argument("--seed", type=int, default=FORMAL_SEEDS[0])
    args = parser.parse_args()

    out = Path(args.out)
    print(">>> Experiment 1: FL baseline")
    exp_01_fl_baseline.run(args.data, str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 2: Protocol overhead")
    exp_02_protocol_overhead.run(str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 3: Double-spending detection")
    exp_03_double_spend.run(str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 4: Revocation")
    exp_04_revocation.run(str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 5: Linkability")
    exp_05_linkability.run(str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 6: Mobility")
    exp_06_mobility.run(str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 7: Poisoning and audit")
    exp_07_poisoning_audit.run(args.data, str(out), quick=args.quick, seed=args.seed)
    print(">>> Experiment 8: Ablation")
    exp_08_ablation.run(str(out), seed=args.seed)
    print(">>> Experiment 9: Model comparison")
    try:
        exp_09_model_comparison.run(args.data, str(out), quick=args.quick, seed=args.seed)
    except Exception as exc:
        print(f"!!! Experiment 9 failed: {exc}")
        traceback.print_exc()
    print(f"\nAll experiments finished. Results are saved to: {out.resolve()}")


if __name__ == "__main__":
    main()
