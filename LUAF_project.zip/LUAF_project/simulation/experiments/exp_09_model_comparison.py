from __future__ import annotations

import argparse
import sys
from dataclasses import replace
from pathlib import Path
from typing import Dict, List

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from src.config import SimConfig
from src.data_loader import load_or_create_dataset, prepare_fl_dataset
from src.fl_simulator import run_fl_simulation
from src.utils import bar_plot, ensure_dir, simple_line_plot, write_csv


SCHEMES = [
    ("Softmax-Plain-FL", "Softmax", "softmax", "Plain-FL", 0.06),
    ("Softmax-LUAF-SM2-FL", "Softmax", "softmax", "LUAF-SM2-FL", 0.06),
    ("MLP-Plain-FL", "MLP", "mlp", "Plain-FL", 0.025),
    ("MLP-LUAF-SM2-FL", "MLP", "mlp", "LUAF-SM2-FL", 0.025),
]


def _quick_sample(df: pd.DataFrame, seed: int, max_rows: int = 8000) -> pd.DataFrame:
    """quick 模式下按类别近似分层抽样，避免真实数据集过大导致实验过慢。"""
    if len(df) <= max_rows:
        return df.reset_index(drop=True)

    label_col = "label_id" if "label_id" in df.columns else "label" if "label" in df.columns else None
    if label_col is None:
        return df.sample(n=max_rows, random_state=seed).reset_index(drop=True)

    parts = []
    for _, group in df.groupby(label_col):
        # 每个类别至少保留少量样本，尽量避免类别不平衡导致 AUC/F1 失真。
        n = max(2, int(round(max_rows * len(group) / len(df))))
        n = min(n, len(group))
        parts.append(group.sample(n=n, random_state=seed))
    sampled = pd.concat(parts, ignore_index=True)
    if len(sampled) > max_rows:
        sampled = sampled.sample(n=max_rows, random_state=seed)
    return sampled.sample(frac=1.0, random_state=seed).reset_index(drop=True)


def _make_config(
    quick: bool,
    rounds: int | None,
    clients: int | None,
    participation: float | None,
    seed: int,
) -> SimConfig:
    """根据 quick/full 模式生成第 9 个实验的 FL 配置。"""
    default_rounds = 5 if quick else 30
    default_clients = 10 if quick else 30
    default_local_epochs = 1 if quick else 2
    return SimConfig(
        seed=seed,
        num_rounds=rounds if rounds is not None else default_rounds,
        num_clients=clients if clients is not None else default_clients,
        participation_rate=participation if participation is not None else 0.5,
        local_epochs=default_local_epochs,
        lr=0.06,
        batch_size=32,
    )


def _normalize_metrics(metrics: pd.DataFrame, scheme_name: str, model_label: str) -> pd.DataFrame:
    """整理模拟器输出字段，形成论文表格需要的统一列名。"""
    m = metrics.copy()
    m["scheme"] = scheme_name
    m["model_type"] = model_label
    if "auc_ovr_weighted" not in m.columns:
        m["auc_ovr_weighted"] = m["auc"] if "auc" in m.columns else np.nan
    m["accepted_clients"] = m.get("accepted_clients", m.get("accepted_updates", 0))
    m["rejected_clients"] = m.get("rejected_clients", m.get("rejected_requests", 0))
    m["communication_bytes"] = m.get("communication_bytes", m.get("round_comm_bytes", 0))
    keep_cols = [
        "seed",
        "run_id",
        "dataset",
        "round",
        "scheme",
        "model_type",
        "accuracy",
        "precision_weighted",
        "recall_weighted",
        "f1_weighted",
        "auc_ovr_weighted",
        "log_loss",
        "accepted_clients",
        "rejected_clients",
        "round_latency_ms",
        "train_latency_ms",
        "protocol_latency_ms",
        "communication_bytes",
        "model_update_bytes",
        "num_model_parameters",
    ]
    return m[[c for c in keep_cols if c in m.columns]]


def _plot_metric(metrics: pd.DataFrame, metric: str, ylabel: str, title: str, out: Path) -> None:
    """绘制每轮指标折线图。"""
    pivot = metrics.pivot(index="round", columns="scheme", values=metric).reset_index()
    simple_line_plot(pivot, "round", [c for c in pivot.columns if c != "round"], title, ylabel, out)


def _final_rows(metrics: pd.DataFrame) -> pd.DataFrame:
    """提取每个方案最后一轮结果。"""
    return metrics.sort_values("round").groupby("scheme", as_index=False).tail(1)


def _plot_final_accuracy_f1(metrics: pd.DataFrame, out: Path) -> None:
    """绘制最终 Accuracy/F1 分组柱状图，便于汇报展示。"""
    final = _final_rows(metrics).set_index("scheme").loc[[s[0] for s in SCHEMES]].reset_index()
    labels = final["scheme"].tolist()
    x = np.arange(len(labels))
    width = 0.36
    acc = final["accuracy"].fillna(0.0).to_numpy()
    f1 = final["f1_weighted"].fillna(0.0).to_numpy()

    plt.figure(figsize=(10, 5))
    plt.bar(x - width / 2, acc, width, label="Accuracy")
    plt.bar(x + width / 2, f1, width, label="Weighted F1")
    plt.xticks(x, labels, rotation=20, ha="right")
    plt.ylabel("Score")
    plt.ylim(0, max(1.0, float(np.nanmax([acc.max(), f1.max()])) * 1.08))
    plt.title("Final Accuracy and F1")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    plt.savefig(out, dpi=220)
    plt.close()


def _security_overhead_by_model(metrics: pd.DataFrame) -> Dict[str, float]:
    """计算 LUAF 相对 Plain-FL 的平均协议时延增量。"""
    overhead = {}
    for model_label in ["Softmax", "MLP"]:
        plain = metrics[(metrics["model_type"] == model_label) & (metrics["scheme"].str.endswith("Plain-FL"))]
        luaf = metrics[(metrics["model_type"] == model_label) & (metrics["scheme"].str.contains("LUAF"))]
        overhead[model_label] = float(luaf["protocol_latency_ms"].mean() - plain["protocol_latency_ms"].mean())
    return overhead


def _training_overhead_by_scheme(metrics: pd.DataFrame) -> Dict[str, float]:
    """计算 MLP 相对 Softmax 的平均训练时延增量。"""
    overhead = {}
    for protocol_label in ["Plain-FL", "LUAF-SM2-FL"]:
        softmax = metrics[(metrics["model_type"] == "Softmax") & (metrics["scheme"].str.endswith(protocol_label))]
        mlp = metrics[(metrics["model_type"] == "MLP") & (metrics["scheme"].str.endswith(protocol_label))]
        overhead[protocol_label] = float(mlp["train_latency_ms"].mean() - softmax["train_latency_ms"].mean())
    return overhead


def _write_summary(metrics: pd.DataFrame, out: Path) -> None:
    """自动生成论文/汇报可引用的模型结构对比结论。"""
    final = _final_rows(metrics).set_index("scheme")
    security_overhead = _security_overhead_by_model(metrics)
    training_overhead = _training_overhead_by_scheme(metrics)
    mean_security_overhead = float(np.nanmean(list(security_overhead.values())))
    mean_training_overhead = float(np.nanmean(list(training_overhead.values())))

    softmax_score = final.loc[["Softmax-Plain-FL", "Softmax-LUAF-SM2-FL"], ["accuracy", "f1_weighted"]].mean().mean()
    mlp_score = final.loc[["MLP-Plain-FL", "MLP-LUAF-SM2-FL"], ["accuracy", "f1_weighted"]].mean().mean()
    if mlp_score > softmax_score + 0.005:
        mlp_conclusion = "MLP improves the final detection score compared with Softmax in this run."
    elif mlp_score < softmax_score - 0.005:
        mlp_conclusion = "MLP does not improve the final detection score in this run, but it validates model-structure independence."
    else:
        mlp_conclusion = "MLP and Softmax show similar final detection scores in this run."

    if mean_security_overhead < 1000.0:
        overhead_conclusion = "LUAF adds a measurable but ms-level security admission overhead under the current simulation settings."
    else:
        overhead_conclusion = "LUAF overhead is measurable and should be evaluated against the target UAV round-latency budget."

    lines: List[str] = []
    lines.append("Experiment 9: Softmax vs MLP model comparison")
    lines.append("")
    for scheme_name in [s[0] for s in SCHEMES]:
        row = final.loc[scheme_name]
        lines.append(
            f"{scheme_name}: final Accuracy={row['accuracy']:.4f}, "
            f"Weighted F1={row['f1_weighted']:.4f}"
        )
    lines.append("")
    lines.append("Average LUAF security admission overhead versus Plain-FL:")
    for model_label, value in security_overhead.items():
        lines.append(f"- {model_label}: {value:.3f} ms")
    lines.append(f"- Overall mean: {mean_security_overhead:.3f} ms")
    lines.append("")
    lines.append("Average MLP training latency increase versus Softmax:")
    for protocol_label, value in training_overhead.items():
        lines.append(f"- {protocol_label}: {value:.3f} ms")
    lines.append(f"- Overall mean: {mean_training_overhead:.3f} ms")
    lines.append("")
    lines.append("Conclusion:")
    lines.append(f"- {mlp_conclusion}")
    lines.append(f"- {overhead_conclusion}")
    lines.append("- LUAF-SM2-FL runs with both Softmax and MLP, showing that the secure admission framework is not tied to a specific FL model structure.")
    lines.append("")
    lines.append(
        "Note: Softmax is used as a lightweight FL baseline for tabular UAV intrusion-detection features. "
        "The added MLP, Input -> Dense(64) -> ReLU -> Dense(32) -> ReLU -> Softmax, "
        "tests whether LUAF-SM2-FL remains applicable when the local model is moderately more expressive."
    )
    (out / "summary_model_comparison.txt").write_text("\n".join(lines), encoding="utf-8")


def run(
    data_path: str | None,
    out_dir: str,
    quick: bool = False,
    rounds: int | None = None,
    clients: int | None = None,
    participation: float | None = None,
    seed: int = 20260529,
) -> None:
    """实验 9：比较 Softmax/MLP 与 Plain-FL/LUAF-SM2-FL 的组合。"""
    out = ensure_dir(Path(out_dir) / "exp_09_model_comparison")
    cfg = _make_config(quick, rounds, clients, participation, seed)

    df = load_or_create_dataset(data_path, seed=cfg.seed)
    if quick:
        df = _quick_sample(df, seed=cfg.seed)
    dataset = prepare_fl_dataset(df, cfg)

    all_metrics = []
    for scheme_name, model_label, model_type, protocol_scheme, lr in SCHEMES:
        # MLP 使用略小学习率，配合 ReLU 和梯度裁剪，降低数值震荡风险。
        scheme_cfg = replace(cfg, lr=lr)
        res = run_fl_simulation(
            dataset,
            scheme_cfg,
            scheme=protocol_scheme,
            model_type=model_type,
            l2=1e-4 if model_type == "mlp" else 0.0,
            include_training_in_round_latency=True,
            use_actual_model_update_bytes=True,
        )
        metrics = _normalize_metrics(res.metrics_by_round, scheme_name, model_label)
        all_metrics.append(metrics)

        events = res.event_log.copy()
        if events.empty:
            events = pd.DataFrame(columns=["round", "client", "event", "reason", "scheme", "model_type"])
        events["scheme"] = scheme_name
        events["model_type"] = model_label
        write_csv(events, out / f"events_{scheme_name}.csv")

    metrics_all = pd.concat(all_metrics, ignore_index=True)
    write_csv(metrics_all, out / "model_comparison_metrics.csv")

    _plot_metric(metrics_all, "accuracy", "Accuracy", "Model Accuracy by Round", out / "plot_model_accuracy.png")
    _plot_metric(metrics_all, "f1_weighted", "Weighted F1", "Model F1 by Round", out / "plot_model_f1_weighted.png")
    _plot_metric(metrics_all, "log_loss", "Log Loss", "Model Log Loss by Round", out / "plot_model_log_loss.png")
    _plot_metric(metrics_all, "round_latency_ms", "Latency (ms)", "Round Latency by Model", out / "plot_model_round_latency_ms.png")
    _plot_metric(metrics_all, "communication_bytes", "Bytes", "Communication Bytes by Round", out / "plot_model_comm_bytes.png")
    _plot_final_accuracy_f1(metrics_all, out / "plot_final_bar_accuracy_f1.png")

    overhead = _security_overhead_by_model(metrics_all)
    bar_plot(
        list(overhead.keys()),
        list(overhead.values()),
        "LUAF Security Overhead by Model",
        "Extra protocol latency (ms)",
        out / "plot_security_overhead_vs_model.png",
        rotation=0,
    )
    _write_summary(metrics_all, out)


def main() -> None:
    parser = argparse.ArgumentParser(description="Experiment 9: Softmax vs MLP model comparison.")
    parser.add_argument("--data", default=None, help="CSV dataset path; empty means synthetic dataset.")
    parser.add_argument("--out", default="results", help="Output directory.")
    parser.add_argument("--quick", action="store_true", help="Run a short sampled experiment.")
    parser.add_argument("--rounds", type=int, default=None, help="FL rounds.")
    parser.add_argument("--clients", type=int, default=None, help="Number of UAV clients.")
    parser.add_argument("--participation", type=float, default=None, help="Client participation rate.")
    parser.add_argument("--seed", type=int, default=20260529, help="Random seed.")
    args = parser.parse_args()
    run(args.data, args.out, args.quick, args.rounds, args.clients, args.participation, args.seed)


if __name__ == "__main__":
    main()
