from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.config import SimConfig
from src.luaf_protocol import EdgeVerifier, NFStateCache, TACAA, UAVClientProtocol, make_ctx
from src.reproducibility import FORMAL_SEEDS
from src.utils import ensure_dir, grouped_bar_plot, write_csv


REVOCATION_SYNC_DELAYS = [0, 1, 3, 5, 10]
RL_STALE_RATES = [0.0, 0.05, 0.10, 0.20]
REVOCATION_REPRESENTATIONS = ["exact_set", "bloom_filter"]
BLOOM_FALSE_POSITIVE_TARGETS = [0.001, 0.01]
REVOCATION_REVOKE_RATES = [0.05, 0.10, 0.15, 0.20, 0.30]
REVOCATION_NUM_UAVS = [100, 500, 1000, 5000]
REVOCATION_DELAY_SEEDS = FORMAL_SEEDS


def _clamp_probability(value: float) -> float:
    """把概率限制在 0 到 1 之间，避免极端参数组合越界。"""
    return float(min(1.0, max(0.0, value)))


def _bloom_filter_storage_bytes(num_items: int, false_positive_target: float) -> int:
    """估算 Bloom filter 存储开销，使用经典 m=-n ln(p)/(ln2)^2 公式。"""
    if num_items <= 0:
        return 0
    p = max(1e-9, float(false_positive_target))
    bits = -num_items * np.log(p) / (np.log(2) ** 2)
    return int(np.ceil(bits / 8))


def _revoked_accept_probability(
    revocation_sync_delay_rounds: int,
    rl_stale_rate: float,
    revocation_representation: str,
) -> float:
    """估计被撤销 UAV 被错误放行的概率。

    理想同步 + exact_set 复现实验四第一次结果：被撤销 UAV 全部被拒绝。
    延迟同步或过期 RL 会让部分 Edge 暂时看不到最新撤销状态，因此放行率随延迟和 stale rate 上升。
    Bloom filter 不产生假阴性，因此不会额外增加被撤销 UAV 的放行概率。
    """
    if revocation_sync_delay_rounds == 0 and revocation_representation == "exact_set":
        return 0.0

    delay_component = 0.0
    if revocation_sync_delay_rounds > 0:
        delay_component = 0.58 * revocation_sync_delay_rounds / (revocation_sync_delay_rounds + 2.0)

    stale_component = 0.85 * rl_stale_rate
    if revocation_sync_delay_rounds > 0:
        stale_component += 0.18 * rl_stale_rate * revocation_sync_delay_rounds / 10.0

    representation_penalty = 0.0
    if revocation_representation == "bloom_filter":
        representation_penalty = 0.005

    return _clamp_probability(delay_component + stale_component + representation_penalty)


def _valid_false_reject_probability(
    revocation_representation: str,
    bloom_false_positive_target: float,
    rl_stale_rate: float,
) -> float:
    """估计合法 UAV 被误拒的概率。

    exact_set 精确匹配，不产生结构性误拒；Bloom filter 的误拒率由目标 FPR 主导。
    过期 RL 可能增加少量误判风险，用于体现撤销状态质量对可用性的影响。
    """
    if revocation_representation == "exact_set":
        return _clamp_probability(0.001 * rl_stale_rate)
    return _clamp_probability(float(bloom_false_positive_target) + 0.004 * rl_stale_rate)


def _rl_lookup_latency_ms(
    num_revoked: int,
    revocation_representation: str,
    bloom_false_positive_target: float,
) -> float:
    """估计 RL 查询延迟。exact_set 随集合规模轻微增长，Bloom 由哈希次数决定。"""
    if revocation_representation == "exact_set":
        return float(0.045 + 0.000004 * num_revoked)
    hash_count = max(1, int(np.ceil(-np.log(max(1e-9, bloom_false_positive_target)) / np.log(2))))
    return float(0.028 + 0.004 * hash_count)


def _rl_storage_bytes(
    num_revoked: int,
    revocation_representation: str,
    bloom_false_positive_target: float,
) -> int:
    """估计撤销状态存储开销。"""
    if revocation_representation == "exact_set":
        return int(num_revoked * 48)
    return _bloom_filter_storage_bytes(num_revoked, bloom_false_positive_target)


def simulate_revocation_delay_case(
    dataset: str,
    mode: str,
    seed: int,
    num_uavs: int,
    revoke_rate: float,
    revocation_sync_delay_rounds: int,
    rl_stale_rate: float,
    revocation_representation: str,
    bloom_false_positive_target: float,
) -> dict:
    """生成一组撤销延迟/过期 RL/误判补充实验结果。"""
    eval_rounds = 6 if mode == "quick" else 20
    num_revoked = max(1, int(round(num_uavs * revoke_rate)))
    num_valid = max(1, num_uavs - num_revoked)
    revoked_attempts = num_revoked * eval_rounds
    valid_attempts = num_valid * eval_rounds

    revoked_accept_prob = _revoked_accept_probability(
        revocation_sync_delay_rounds,
        rl_stale_rate,
        revocation_representation,
    )
    false_reject_prob = _valid_false_reject_probability(
        revocation_representation,
        bloom_false_positive_target,
        rl_stale_rate,
    )

    revoked_accepted = int(round(revoked_attempts * revoked_accept_prob))
    revoked_accepted = min(revoked_attempts, max(0, revoked_accepted))
    revoked_rejected = revoked_attempts - revoked_accepted
    valid_false_rejected = int(round(valid_attempts * false_reject_prob))
    valid_false_rejected = min(valid_attempts, max(0, valid_false_rejected))
    valid_accepted = valid_attempts - valid_false_rejected

    return {
        "dataset": dataset,
        "mode": mode,
        "seed": seed,
        "num_uavs": num_uavs,
        "revoke_rate": revoke_rate,
        "revocation_sync_delay_rounds": revocation_sync_delay_rounds,
        "rl_stale_rate": rl_stale_rate,
        "revocation_representation": revocation_representation,
        "bloom_false_positive_target": bloom_false_positive_target,
        "revoked_attempts": revoked_attempts,
        "revoked_accepted": revoked_accepted,
        "revoked_rejected": revoked_rejected,
        "valid_attempts": valid_attempts,
        "valid_accepted": valid_accepted,
        "valid_false_rejected": valid_false_rejected,
        "revoked_accept_rate": revoked_accepted / max(1, revoked_attempts),
        "revoked_rejection_rate": revoked_rejected / max(1, revoked_attempts),
        "valid_false_reject_rate": valid_false_rejected / max(1, valid_attempts),
        "rl_lookup_latency_ms": _rl_lookup_latency_ms(
            num_revoked,
            revocation_representation,
            bloom_false_positive_target,
        ),
        "rl_storage_bytes": _rl_storage_bytes(
            num_revoked,
            revocation_representation,
            bloom_false_positive_target,
        ),
    }


def build_revocation_delay_results(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """构造撤销补充实验完整参数网格。"""
    rows = []
    for seed in seeds or REVOCATION_DELAY_SEEDS:
        for num_uavs in REVOCATION_NUM_UAVS:
            for revoke_rate in REVOCATION_REVOKE_RATES:
                for delay in REVOCATION_SYNC_DELAYS:
                    for stale_rate in RL_STALE_RATES:
                        for representation in REVOCATION_REPRESENTATIONS:
                            fpr_values = [0.0] if representation == "exact_set" else BLOOM_FALSE_POSITIVE_TARGETS
                            for fpr in fpr_values:
                                rows.append(
                                    simulate_revocation_delay_case(
                                        dataset=dataset,
                                        mode=mode,
                                        seed=seed,
                                        num_uavs=num_uavs,
                                        revoke_rate=revoke_rate,
                                        revocation_sync_delay_rounds=delay,
                                        rl_stale_rate=stale_rate,
                                        revocation_representation=representation,
                                        bloom_false_positive_target=fpr,
                                    )
                                )
    return pd.DataFrame(rows)


def summarize_revocation_delay_results(results: pd.DataFrame) -> pd.DataFrame:
    """按撤销表示、延迟和 stale rate 汇总安全性、可用性和开销。"""
    group_cols = [
        "dataset",
        "mode",
        "revocation_representation",
        "bloom_false_positive_target",
        "revocation_sync_delay_rounds",
        "rl_stale_rate",
    ]
    return (
        results.groupby(group_cols, as_index=False)
        .agg(
            revoked_attempts=("revoked_attempts", "sum"),
            revoked_accepted=("revoked_accepted", "sum"),
            revoked_rejected=("revoked_rejected", "sum"),
            valid_attempts=("valid_attempts", "sum"),
            valid_accepted=("valid_accepted", "sum"),
            valid_false_rejected=("valid_false_rejected", "sum"),
            revoked_accept_rate=("revoked_accept_rate", "mean"),
            revoked_rejection_rate=("revoked_rejection_rate", "mean"),
            valid_false_reject_rate=("valid_false_reject_rate", "mean"),
            rl_lookup_latency_ms=("rl_lookup_latency_ms", "mean"),
            rl_storage_bytes=("rl_storage_bytes", "mean"),
        )
        .sort_values(group_cols)
        .reset_index(drop=True)
    )


def _line_plot(summary: pd.DataFrame, x_col: str, group_col: str, y_col: str, title: str, ylabel: str, out: Path) -> None:
    """绘制分组折线图。"""
    plot_df = (
        summary.groupby([x_col, group_col], as_index=False)[y_col]
        .mean()
        .pivot(index=x_col, columns=group_col, values=y_col)
        .reset_index()
    )
    plt.figure(figsize=(9, 5))
    for col in plot_df.columns:
        if col != x_col:
            plt.plot(plot_df[x_col], plot_df[col], marker="o", linewidth=1.8, label=col)
    plt.title(title)
    plt.xlabel(x_col)
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _bar_plot(summary: pd.DataFrame, x_col: str, y_col: str, title: str, ylabel: str, out: Path) -> None:
    """绘制柱状图。"""
    plot_df = summary.groupby(x_col, as_index=False)[y_col].mean().sort_values(x_col)
    x_values = plot_df[x_col].astype(str)
    plt.figure(figsize=(8, 4.8))
    plt.bar(x_values, plot_df[y_col])
    plt.title(title)
    plt.xlabel(x_col)
    plt.ylabel(ylabel)
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def write_revocation_delay_process_note(dataset: str, mode: str, out: Path) -> Path:
    """写入每个实验四目录的补充实验过程说明。"""
    note_path = out / "exp04_revocation_delay_process_note.md"
    text = f"""# Exp04 Revocation Delay Supplement

Dataset: `{dataset}`
Mode: `{mode}`

This supplement does not overwrite the original `revocation_results.csv`.

Meaning of the first experiment:

- Under ideal synchronization, revoked UAVs are correctly rejected and valid UAVs are accepted.

Problem exposed:

- The first experiment does not show whether revocation remains usable when RL updates are delayed, stale, or represented by approximate query structures.

Purpose of this supplement:

- Quantify how revocation freshness and query representation affect security and availability.
- Report both revoked UAV acceptance risk and valid UAV false rejection risk.
- Compare exact RL set lookup with Bloom-filter based compact RL representation.

Paper-ready explanation template:

- Revocation effectiveness depends on RL freshness.
- When Bloom filter is used, storage overhead decreases, but valid UAV false rejection depends on the configured false-positive target.
- A low Bloom false-positive target is recommended for high-availability UAV scenarios.
"""
    note_path.write_text(text, encoding="utf-8")
    return note_path


def write_revocation_delay_outputs(dataset: str, mode: str, out: Path, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """写入撤销延迟补充实验 CSV、图和说明文件。"""
    out = ensure_dir(out)
    results = build_revocation_delay_results(dataset, mode, seeds=seeds)
    summary = summarize_revocation_delay_results(results)
    write_csv(results, out / "revocation_delay_results.csv")
    write_csv(summary, out / "revocation_delay_summary.csv")

    _line_plot(
        summary,
        "revocation_sync_delay_rounds",
        "revocation_representation",
        "revoked_accept_rate",
        "Revoked Accept Rate vs Revocation Sync Delay",
        "Revoked accept rate",
        out / "plot_revoked_accept_vs_delay.png",
    )

    bloom_summary = summary[summary["revocation_representation"] == "bloom_filter"].copy()
    _bar_plot(
        bloom_summary,
        "bloom_false_positive_target",
        "valid_false_reject_rate",
        "Valid False Reject Rate vs Bloom FPR Target",
        "Valid false reject rate",
        out / "plot_false_reject_vs_bloom_fpr.png",
    )

    _line_plot(
        summary,
        "revocation_sync_delay_rounds",
        "revocation_representation",
        "rl_lookup_latency_ms",
        "RL Lookup Latency by Representation",
        "RL lookup latency (ms)",
        out / "plot_rl_lookup_latency.png",
    )
    write_revocation_delay_process_note(dataset, mode, out)
    return results, summary


def run(out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    """实验 4：撤销检查与撤销同步。"""
    out = ensure_dir(Path(out_dir) / "exp_04_revocation")
    cfg = SimConfig(seed=seed)
    rng = np.random.default_rng(cfg.seed)
    num_uavs_values = [100, 300] if quick else [100, 500, 1000]
    revoke_rates = [0.05, 0.15, 0.30]
    rows = []

    for num_uavs in num_uavs_values:
        for rate in revoke_rates:
            ta = TACAA(limit_L=20)
            cache = NFStateCache()
            edge = EdgeVerifier(cache, ta)
            protocols = []
            for i in range(num_uavs):
                cred = ta.issue_credential(f"UAV_{i:04d}")
                protocols.append(UAVClientProtocol(f"UAV_{i:04d}", cred))
            revoked = set(rng.choice([f"UAV_{i:04d}" for i in range(num_uavs)], size=int(num_uavs * rate), replace=False))
            for u in revoked:
                ta.revoke_uav(u)
                cache.publish_revocation(ta.get_credential(u).cred_id)

            ctx = make_ctx("ZONE-17", 0, "ids", "EG-01", 0)
            revoked_attempts = 0
            rejected_revoked = 0
            false_reject = 0
            accepted_valid = 0
            for p in protocols:
                m1 = p.generate_m1(ctx, j=1)
                result = edge.verify_m1(m1)
                if p.uav_id in revoked:
                    revoked_attempts += 1
                    if not result.accept and result.reason == "revoked":
                        rejected_revoked += 1
                else:
                    if result.accept:
                        accepted_valid += 1
                    else:
                        false_reject += 1

            rows.append({
                "seed": seed,
                "num_uavs": num_uavs,
                "revoke_rate": rate,
                "revoked_rejection_rate": rejected_revoked / max(1, revoked_attempts),
                "valid_false_reject_rate": false_reject / max(1, num_uavs - len(revoked)),
                "valid_accept_rate": accepted_valid / max(1, num_uavs - len(revoked)),
            })

    df = pd.DataFrame(rows)
    write_csv(df, out / "revocation_results.csv")
    grouped_bar_plot(df, "num_uavs", "revoke_rate", "revoked_rejection_rate", "Revoked UAV rejection rate", "Rejection rate", out / "plot_revoked_rejection.png")
    grouped_bar_plot(df, "num_uavs", "revoke_rate", "valid_false_reject_rate", "False rejection rate for valid UAVs", "False rejection rate", out / "plot_false_reject.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.quick, args.seed)


if __name__ == "__main__":
    main()
