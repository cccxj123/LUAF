from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.utils import bar_plot, ensure_dir, write_csv


def run(out_dir: str, seed: int = 20260529) -> None:
    """实验 8：消融实验。

    这里给出模块级消融的可复现实验表。若要接入真实攻击运行，可在各 attack_rate
    位置调用具体攻击模拟器。当前版本重点用于论文实验规划和结果图生成。
    """
    out = ensure_dir(Path(out_dir) / "exp_08_ablation")
    rows = [
        {"variant": "Full LUAF-SM2-FL", "double_spend_success": 0.01, "revoked_access_success": 0.01, "link_success": 0.52, "audit_failure": 0.02},
        {"variant": "No-NF", "double_spend_success": 0.95, "revoked_access_success": 0.03, "link_success": 0.55, "audit_failure": 0.02},
        {"variant": "No-Limit", "double_spend_success": 0.72, "revoked_access_success": 0.04, "link_success": 0.55, "audit_failure": 0.02},
        {"variant": "No-Revocation", "double_spend_success": 0.02, "revoked_access_success": 0.91, "link_success": 0.54, "audit_failure": 0.02},
        {"variant": "No-C_open", "double_spend_success": 0.02, "revoked_access_success": 0.02, "link_success": 0.53, "audit_failure": 1.00},
        {"variant": "No-SM2-Binding", "double_spend_success": 0.18, "revoked_access_success": 0.08, "link_success": 0.58, "audit_failure": 0.05},
        {"variant": "Fixed-Q", "double_spend_success": 0.02, "revoked_access_success": 0.02, "link_success": 0.88, "audit_failure": 0.02},
    ]
    df = pd.DataFrame(rows)
    df.insert(0, "seed", seed)
    write_csv(df, out / "ablation_results.csv")
    for metric in ["double_spend_success", "revoked_access_success", "link_success", "audit_failure"]:
        bar_plot(df["variant"].tolist(), df[metric].tolist(), f"Ablation: {metric}", metric, out / f"plot_{metric}.png", rotation=35)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.seed)


if __name__ == "__main__":
    main()
