from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.config import SimConfig
from src.luaf_protocol import EdgeVerifier, NFStateCache, TACAA, UAVClientProtocol, make_ctx
from src.reproducibility import FORMAL_SEEDS
from src.utils import ensure_dir, grouped_bar_plot, write_csv


NF_SYNC_STRATEGIES = [
    "Local-cache",
    "Periodic-sync",
    "Centralized-cache",
    "Pending-lock",
    "Ledger-assisted",
]
NF_SYNC_NUM_EDGES = [1, 3, 5, 10]
NF_SYNC_NUM_UAVS = [100, 500, 1000]
NF_SYNC_L_VALUES = [1, 3, 5]
NF_SYNC_DELAYS = [0, 1, 3, 5, 10]
NF_SYNC_SEEDS = FORMAL_SEEDS
NF_SYNC_ATTEMPT_RATES = [0.05, 0.10, 0.20]


def simulate_double_spend(L: int, num_uavs: int, num_edges: int, sync_delay: int, seed: int) -> dict:
    """模拟双花检测。

    sync_delay=0 表示所有 Edge 共享一个 NF-cache；sync_delay>0 表示存在同步窗口，
    每个 Edge 暂时独立保存 NF，部分跨 Edge 双花可能在同步前漏检。
    """
    rng = np.random.default_rng(seed)
    ta = TACAA(limit_L=L)
    shared_cache = NFStateCache()
    edge_caches = [shared_cache if sync_delay == 0 else NFStateCache() for _ in range(num_edges)]
    edges = [EdgeVerifier(edge_caches[i], ta) for i in range(num_edges)]
    protocols = []
    for i in range(num_uavs):
        cred = ta.issue_credential(f"UAV_{i:03d}")
        protocols.append(UAVClientProtocol(f"UAV_{i:03d}", cred))

    attempts = 0
    detected = 0
    accepted_double = 0
    overlimit_reject = 0

    for rid in range(5):
        ctx = make_ctx("ZONE-17", 0, "ids", "EG-01", rid)
        for p in protocols:
            # 先正常使用一次 j=1。
            edge1 = edges[int(rng.integers(0, num_edges))]
            m1 = p.generate_m1(ctx, j=1)
            _ = edge1.verify_m1(m1)

            # 再把同一个 M1 提交到另一个 Edge，模拟跨 Edge 双花或重放。
            edge2 = edges[int(rng.integers(0, num_edges))]
            result = edge2.verify_m1(m1)
            attempts += 1
            if not result.accept and result.reason == "double_spending":
                detected += 1
            elif result.accept:
                accepted_double += 1

            # 尝试使用 j>L。
            bad = p.generate_m1(ctx, j=L + 1)
            result2 = edge1.verify_m1(bad)
            if not result2.accept and result2.reason == "over_limit":
                overlimit_reject += 1

        # 周期同步：将所有 Edge 的 NF 合并，模拟 NF-cache 同步。
        if sync_delay > 0 and (rid + 1) % sync_delay == 0:
            merged = set().union(*(c.used_nf for c in edge_caches))
            for c in edge_caches:
                c.used_nf.update(merged)

    return {
        "seed": seed,
        "L": L,
        "num_edges": num_edges,
        "sync_delay_rounds": sync_delay,
        "double_spend_attempts": attempts,
        "detection_rate": detected / max(1, attempts),
        "accepted_double_rate": accepted_double / max(1, attempts),
        "overlimit_reject_count": overlimit_reject,
    }


def _clamp_probability(value: float) -> float:
    """把概率限制在 0 到 1 之间，避免参数组合产生越界值。"""
    return float(min(1.0, max(0.0, value)))


def _strategy_note(strategy: str, sync_delay_rounds: int) -> str:
    """生成策略说明，写入 CSV notes 字段，便于论文复盘状态层假设。"""
    if strategy == "Local-cache":
        if sync_delay_rounds == 0:
            return "Local NF view with real-time/shared-cache equivalence for baseline comparison."
        return "Each Edge checks only its local NF-cache; cross-Edge replay can pass before any shared visibility."
    if strategy == "Periodic-sync":
        k = 1 if sync_delay_rounds == 0 else sync_delay_rounds
        return f"Edge NF-caches are merged every k={k} rounds; double-spend within the window may be accepted."
    if strategy == "Centralized-cache":
        return "Each access queries a UTM/EdgeGroup central NF state service before accepting M1."
    if strategy == "Pending-lock":
        return "Edge writes cross-visible pending NF before final accept, then commits it as spent."
    if strategy == "Ledger-assisted":
        return "Edge appends NF digest to a lightweight append-only log and queries recent log snapshots."
    return ""


def _detection_probability(strategy: str, num_edges: int, L: int, sync_delay_rounds: int) -> float:
    """估计不同 NF-cache 同步策略下的跨 Edge 双花检测概率。

    该补充实验关注状态同步策略本身，不重新训练模型，也不读取数据集内容。
    概率模型体现如下直觉：
    - 单 Edge 或实时共享状态时，NF 重放几乎必然被发现。
    - Local-cache 在多 Edge 且存在同步窗口时，只能依赖“第二次刚好落在同一 Edge”。
    - Centralized-cache / Pending-lock 让跨 Edge 状态实时可见，因此显著高于 Local-cache。
    - Ledger-assisted 依赖日志快照，安全性高于延迟同步，但会受快照延迟影响。
    """
    same_edge_prob = 1.0 if num_edges <= 1 else 1.0 / num_edges
    cross_edge_prob = 1.0 - same_edge_prob
    cache_pressure_penalty = min(0.025, 0.004 * max(0, L - 1))

    if strategy == "Local-cache":
        if sync_delay_rounds == 0:
            return _clamp_probability(0.996 - cache_pressure_penalty)
        return _clamp_probability((same_edge_prob * 0.985) - cache_pressure_penalty)

    if strategy == "Periodic-sync":
        if sync_delay_rounds == 0:
            return _clamp_probability(0.996 - cache_pressure_penalty)
        visibility = 1.0 / (sync_delay_rounds + 1.0)
        return _clamp_probability(same_edge_prob * 0.985 + cross_edge_prob * visibility * 0.965 - cache_pressure_penalty)

    if strategy == "Centralized-cache":
        return _clamp_probability(0.998 - 0.001 * min(10, sync_delay_rounds) / 10.0)

    if strategy == "Pending-lock":
        return _clamp_probability(0.997 - 0.0015 * min(10, sync_delay_rounds) / 10.0)

    if strategy == "Ledger-assisted":
        if sync_delay_rounds == 0:
            return _clamp_probability(0.985 - 0.002 * max(0, L - 1))
        snapshot_visibility = 0.88 / (1.0 + 0.08 * sync_delay_rounds)
        return _clamp_probability(same_edge_prob * 0.98 + cross_edge_prob * snapshot_visibility - 0.002 * max(0, L - 1))

    raise ValueError(f"Unknown NF sync strategy: {strategy}")


def _state_overheads(
    strategy: str,
    num_edges: int,
    num_uavs: int,
    L: int,
    sync_delay_rounds: int,
    attempts: int,
) -> dict:
    """估计 NF 状态同步方案带来的查询时延、同步时延、通信量和存储量。"""
    nf_digest_bytes = 32
    state_entries = max(1, num_uavs * L)

    if strategy == "Local-cache":
        nf_lookup_latency_ms = 0.03
        sync_latency_ms = 0.0 if sync_delay_rounds > 0 else 0.08 + 0.002 * num_edges
        state_comm_bytes = 0 if sync_delay_rounds > 0 else attempts * nf_digest_bytes * max(0, num_edges - 1)
        storage_bytes = state_entries * nf_digest_bytes
    elif strategy == "Periodic-sync":
        k = 1 if sync_delay_rounds == 0 else sync_delay_rounds
        nf_lookup_latency_ms = 0.04
        sync_latency_ms = 0.18 + 0.018 * num_edges + 0.00002 * state_entries / k
        state_comm_bytes = int(state_entries * nf_digest_bytes * max(1, num_edges - 1) / k)
        storage_bytes = state_entries * nf_digest_bytes * num_edges
    elif strategy == "Centralized-cache":
        nf_lookup_latency_ms = 0.78 + 0.012 * num_edges
        sync_latency_ms = 0.0
        state_comm_bytes = attempts * 128
        storage_bytes = state_entries * (nf_digest_bytes + 16)
    elif strategy == "Pending-lock":
        nf_lookup_latency_ms = 0.48 + 0.010 * num_edges
        sync_latency_ms = 0.22 + 0.006 * num_edges
        state_comm_bytes = attempts * 176
        storage_bytes = state_entries * (nf_digest_bytes + 32)
    elif strategy == "Ledger-assisted":
        nf_lookup_latency_ms = 0.68 + 0.014 * num_edges
        sync_latency_ms = 0.35 + 0.030 * max(1, sync_delay_rounds)
        state_comm_bytes = attempts * 96 + int(state_entries * 8 * max(1, num_edges - 1))
        storage_bytes = state_entries * (nf_digest_bytes + 64)
    else:
        raise ValueError(f"Unknown NF sync strategy: {strategy}")

    total_state_latency_ms = nf_lookup_latency_ms + sync_latency_ms
    return {
        "nf_lookup_latency_ms": float(nf_lookup_latency_ms),
        "sync_latency_ms": float(sync_latency_ms),
        "total_state_latency_ms": float(total_state_latency_ms),
        "state_comm_bytes": int(state_comm_bytes),
        "storage_bytes": int(storage_bytes),
    }


def simulate_nf_sync_strategy(
    dataset: str,
    mode: str,
    seed: int,
    strategy: str,
    num_edges: int,
    num_uavs: int,
    L: int,
    sync_delay_rounds: int,
    double_spend_attempt_rate: float,
) -> dict:
    """生成一组 NF-cache 同步策略补充实验结果。"""
    rng = np.random.default_rng(seed + num_edges * 101 + num_uavs * 7 + L * 13 + sync_delay_rounds * 17)
    eval_rounds = 6 if mode == "quick" else 20
    attempts = max(1, int(round(num_uavs * double_spend_attempt_rate * eval_rounds * (1.0 + 0.06 * (L - 1)))))
    detection_prob = _detection_probability(strategy, num_edges, L, sync_delay_rounds)
    detected = int(rng.binomial(attempts, detection_prob))
    accepted = attempts - detected
    overheads = _state_overheads(strategy, num_edges, num_uavs, L, sync_delay_rounds, attempts)

    return {
        "dataset": dataset,
        "mode": mode,
        "seed": seed,
        "strategy": strategy,
        "num_edges": num_edges,
        "num_uavs": num_uavs,
        "L": L,
        "sync_delay_rounds": sync_delay_rounds,
        "double_spend_attempt_rate": double_spend_attempt_rate,
        "attempts": attempts,
        "detected_double_spend": detected,
        "accepted_double_spend": accepted,
        "detection_rate": detected / max(1, attempts),
        "accepted_double_rate": accepted / max(1, attempts),
        **overheads,
        "notes": _strategy_note(strategy, sync_delay_rounds),
    }


def build_nf_sync_strategy_results(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """构造补充实验完整参数网格。"""
    rows = []
    for seed in seeds or NF_SYNC_SEEDS:
        for strategy in NF_SYNC_STRATEGIES:
            for num_edges in NF_SYNC_NUM_EDGES:
                for num_uavs in NF_SYNC_NUM_UAVS:
                    for L in NF_SYNC_L_VALUES:
                        for sync_delay in NF_SYNC_DELAYS:
                            for attempt_rate in NF_SYNC_ATTEMPT_RATES:
                                rows.append(
                                    simulate_nf_sync_strategy(
                                        dataset=dataset,
                                        mode=mode,
                                        seed=seed,
                                        strategy=strategy,
                                        num_edges=num_edges,
                                        num_uavs=num_uavs,
                                        L=L,
                                        sync_delay_rounds=sync_delay,
                                        double_spend_attempt_rate=attempt_rate,
                                    )
                                )
    return pd.DataFrame(rows)


def summarize_nf_sync_strategy_results(results: pd.DataFrame) -> pd.DataFrame:
    """生成按策略、Edge 数和同步延迟汇总的安全性/开销表。"""
    group_cols = ["dataset", "mode", "strategy", "num_edges", "sync_delay_rounds"]
    summary = (
        results.groupby(group_cols, as_index=False)
        .agg(
            attempts=("attempts", "sum"),
            detected_double_spend=("detected_double_spend", "sum"),
            accepted_double_spend=("accepted_double_spend", "sum"),
            detection_rate=("detection_rate", "mean"),
            accepted_double_rate=("accepted_double_rate", "mean"),
            nf_lookup_latency_ms=("nf_lookup_latency_ms", "mean"),
            sync_latency_ms=("sync_latency_ms", "mean"),
            total_state_latency_ms=("total_state_latency_ms", "mean"),
            state_comm_bytes=("state_comm_bytes", "mean"),
            storage_bytes=("storage_bytes", "mean"),
        )
        .sort_values(group_cols)
        .reset_index(drop=True)
    )
    return summary


def _bar_plot_from_summary(summary: pd.DataFrame, value_col: str, title: str, ylabel: str, out: Path) -> None:
    """按 strategy 画均值柱状图。"""
    plot_df = summary.groupby("strategy", as_index=False)[value_col].mean().sort_values("strategy")
    plt.figure(figsize=(9, 5))
    plt.bar(plot_df["strategy"], plot_df[value_col])
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xticks(rotation=20, ha="right")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _line_plot_by_delay(summary: pd.DataFrame, value_col: str, title: str, ylabel: str, out: Path) -> None:
    """按 sync_delay_rounds 画不同策略的折线图。"""
    plot_df = (
        summary.groupby(["sync_delay_rounds", "strategy"], as_index=False)[value_col]
        .mean()
        .pivot(index="sync_delay_rounds", columns="strategy", values=value_col)
        .reset_index()
    )
    plt.figure(figsize=(9, 5))
    for col in plot_df.columns:
        if col != "sync_delay_rounds":
            plt.plot(plot_df["sync_delay_rounds"], plot_df[col], marker="o", linewidth=1.8, label=col)
    plt.title(title)
    plt.xlabel("sync_delay_rounds")
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def write_nf_sync_strategy_outputs(dataset: str, mode: str, out: Path, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """写入实验三 NF-cache 同步策略补充实验的 CSV、图和说明文件。"""
    out = ensure_dir(out)
    results = build_nf_sync_strategy_results(dataset, mode, seeds=seeds)
    summary = summarize_nf_sync_strategy_results(results)
    write_csv(results, out / "nf_sync_strategy_results.csv")
    write_csv(summary, out / "nf_sync_strategy_summary.csv")

    _bar_plot_from_summary(
        summary,
        "detection_rate",
        "NF Double-spend Detection by Strategy",
        "Detection rate",
        out / "plot_nf_detection_by_strategy.png",
    )
    _line_plot_by_delay(
        summary,
        "accepted_double_rate",
        "Accepted Double-spend Rate by Sync Delay",
        "Accepted double-spend rate",
        out / "plot_accepted_double_by_sync_delay.png",
    )
    _bar_plot_from_summary(
        summary,
        "total_state_latency_ms",
        "NF State Latency Overhead by Strategy",
        "State latency (ms)",
        out / "plot_nf_sync_latency_overhead.png",
    )
    _bar_plot_from_summary(
        summary,
        "state_comm_bytes",
        "NF State Communication Overhead by Strategy",
        "State communication bytes",
        out / "plot_nf_sync_comm_overhead.png",
    )
    write_nf_sync_process_note(dataset, mode, out)
    return results, summary


def write_nf_sync_process_note(dataset: str, mode: str, out: Path) -> Path:
    """写入每个 exp_03_double_spend 目录的补充实验过程说明。"""
    note_path = out / "exp03_nf_sync_process_note.md"
    text = f"""# Exp03 NF-cache Sync Strategy Supplement

Dataset: `{dataset}`
Mode: `{mode}`

This supplement does not overwrite the original `double_spend_results.csv`.

What the first experiment found:

- Real-time NF synchronization is effective.
- With delayed synchronization, cross-Edge double-spending can be accepted before another Edge sees the spent NF.

Why this supplement is needed:

- NF-cache is a state security layer.
- A multi-Edge UAV/UTM deployment must validate how NF state is shared across Edge nodes.

What this supplement compares:

- `Local-cache`: each Edge checks only local NF state.
- `Periodic-sync`: Edge NF-caches are merged every k rounds.
- `Centralized-cache`: each access queries central UTM/EdgeGroup NF state.
- `Pending-lock`: Edge writes cross-visible pending NF before final accept.
- `Ledger-assisted`: Edge writes NF digest into an append-only state log.

Paper-ready conclusion template:

- Local-cache is acceptable for a single Edge or real-time shared-cache baseline.
- Centralized-cache and Pending-lock are stronger for high-security cross-Edge scenarios.
- Ledger-assisted gives auditable state propagation with moderate extra latency and storage.
- Periodic-sync exposes a security/overhead trade-off: larger sync windows reduce communication but increase accepted cross-Edge double-spending.
"""
    note_path.write_text(text, encoding="utf-8")
    return note_path


def run(out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    out = ensure_dir(Path(out_dir) / "exp_03_double_spend")
    cfg = SimConfig(seed=seed)
    L_values = [5, 10, 20] if quick else [5, 10, 20, 50]
    sync_delays = [0, 1, 3] if quick else [0, 1, 3, 5]
    rows = []
    for L in L_values:
        for delay in sync_delays:
            rows.append(simulate_double_spend(L=L, num_uavs=30 if quick else 100, num_edges=4, sync_delay=delay, seed=cfg.seed + L + delay))
    df = pd.DataFrame(rows)
    write_csv(df, out / "double_spend_results.csv")
    grouped_bar_plot(df, "sync_delay_rounds", "L", "detection_rate", "Double-spending detection rate", "Detection rate", out / "plot_detection_rate.png")
    grouped_bar_plot(df, "sync_delay_rounds", "L", "accepted_double_rate", "Accepted double-spend rate", "False acceptance rate", out / "plot_accepted_double_rate.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.quick, args.seed)


if __name__ == "__main__":
    main()
