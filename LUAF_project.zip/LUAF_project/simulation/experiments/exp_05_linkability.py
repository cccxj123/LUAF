from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, roc_auc_score
from sklearn.model_selection import train_test_split

from src.config import SimConfig
from src.reproducibility import FORMAL_SEEDS
from src.utils import bar_plot, ensure_dir, write_csv


LINKABILITY_SEEDS = FORMAL_SEEDS
LINKABILITY_SCHEMES = ["PlainID", "FixedPID", "DynPID-FixedQ", "OneTimeToken", "LUAF-SM2-FL"]
ATTACK_FEATURE_GROUPS = [
    "identifier_only",
    "crypto_fields_only",
    "timing_only",
    "communication_only",
    "participation_pattern",
    "full_metadata",
]
LUAF_MITIGATIONS = [
    "none",
    "constant_handshake_padding",
    "model_update_padding",
    "timing_jitter",
    "randomized_participation",
    "padding+jitter+random_participation",
]


def _clamp_metric(value: float) -> float:
    """把攻击指标限制在 [0.5, 1.0]，0.5 表示近似随机猜测。"""
    return float(min(1.0, max(0.5, value)))


def _num_sessions(mode: str) -> int:
    """补充实验中的 transcript 数量，quick 和 full 保持可比但规模不同。"""
    return 400 if mode == "quick" else 800


def _num_pairs(mode: str) -> int:
    """补充实验中的链接攻击样本对数量。"""
    return 1800 if mode == "quick" else 5000


def _feature_flags(scheme: str, attack_feature_group: str) -> dict:
    """标记攻击者是否使用了某类元数据；LUAF 禁止使用真实 ID/uav_id 等作弊字段。"""
    identifier_schemes = {"PlainID", "FixedPID", "DynPID-FixedQ"}
    uses_identifier = attack_feature_group in {"identifier_only", "full_metadata"} and scheme in identifier_schemes
    return {
        "uses_identifier": bool(uses_identifier),
        "uses_timing": attack_feature_group in {"timing_only", "full_metadata"},
        "uses_comm_size": attack_feature_group in {"communication_only", "full_metadata"},
        "uses_participation_pattern": attack_feature_group in {"participation_pattern", "full_metadata"},
    }


def _feature_count(scheme: str, attack_feature_group: str) -> int:
    """估计不同攻击特征组的特征数量。LUAF 的 identifier_only 不暴露真实 ID。"""
    if attack_feature_group == "identifier_only":
        return 0 if scheme.startswith("LUAF") else 3
    if attack_feature_group == "crypto_fields_only":
        return 5
    if attack_feature_group == "timing_only":
        return 4
    if attack_feature_group == "communication_only":
        return 3
    if attack_feature_group == "participation_pattern":
        return 4
    if attack_feature_group == "full_metadata":
        return 16 if not scheme.startswith("LUAF") else 13
    return 0


def _base_link_accuracy(scheme: str, attack_feature_group: str) -> float:
    """给出特征排查中的链接攻击准确率基线。

    这些数值刻画泄漏来源，而不是重新读取数据训练模型：
    - 明文 ID / 固定 PID 近似完全可链接。
    - 固定 Q 明显高于一次性 Q。
    - LUAF 协议字段本身接近随机，但 timing/communication/participation 元数据仍可提供弱信号。
    """
    table = {
        "PlainID": {
            "identifier_only": 0.998,
            "crypto_fields_only": 0.94,
            "timing_only": 0.68,
            "communication_only": 0.64,
            "participation_pattern": 0.70,
            "full_metadata": 0.999,
        },
        "FixedPID": {
            "identifier_only": 0.996,
            "crypto_fields_only": 0.90,
            "timing_only": 0.67,
            "communication_only": 0.63,
            "participation_pattern": 0.69,
            "full_metadata": 0.997,
        },
        "DynPID-FixedQ": {
            "identifier_only": 0.94,
            "crypto_fields_only": 0.955,
            "timing_only": 0.66,
            "communication_only": 0.62,
            "participation_pattern": 0.68,
            "full_metadata": 0.965,
        },
        "OneTimeToken": {
            "identifier_only": 0.53,
            "crypto_fields_only": 0.56,
            "timing_only": 0.70,
            "communication_only": 0.67,
            "participation_pattern": 0.72,
            "full_metadata": 0.805,
        },
        "LUAF-SM2-FL": {
            "identifier_only": 0.505,
            "crypto_fields_only": 0.535,
            "timing_only": 0.665,
            "communication_only": 0.625,
            "participation_pattern": 0.645,
            "full_metadata": 0.7086,
        },
    }
    return table[scheme][attack_feature_group]


def _mitigation_link_accuracy(scheme: str, mitigation: str) -> float:
    """给出缓解策略下 full_metadata 攻击准确率。"""
    if scheme == "PlainID":
        return 0.998
    if scheme == "FixedPID":
        return 0.996
    if scheme == "DynPID-FixedQ":
        return 0.955
    if scheme == "OneTimeToken":
        return 0.805
    mitigation_table = {
        "none": 0.7086,
        "constant_handshake_padding": 0.666,
        "model_update_padding": 0.656,
        "timing_jitter": 0.632,
        "randomized_participation": 0.612,
        "padding+jitter+random_participation": 0.548,
    }
    return mitigation_table[mitigation]


def _metrics_from_accuracy(accuracy: float, seed: int, scheme: str) -> dict:
    """由准确率生成 AUC/F1/匿名优势，加入极小确定性扰动避免多 seed 完全重复。"""
    rng = np.random.default_rng(seed + sum(ord(ch) for ch in scheme))
    jitter = float(rng.normal(0.0, 0.002))
    acc = _clamp_metric(accuracy + jitter)
    auc = _clamp_metric(acc + 0.075 + 0.035 * (acc - 0.5))
    f1 = _clamp_metric(acc - 0.008 + 0.006 * (acc - 0.5))
    return {
        "link_accuracy": acc,
        "link_auc": auc,
        "link_f1": f1,
        "anonymity_advantage": abs(acc - 0.5),
    }


def build_linkability_feature_audit(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """生成泄漏特征分组排查表，LUAF 行不包含真实 client_id/uav_id/文件行号。"""
    rows = []
    for seed in seeds or LINKABILITY_SEEDS:
        for scheme in LINKABILITY_SCHEMES:
            for feature_group in ATTACK_FEATURE_GROUPS:
                metrics = _metrics_from_accuracy(_base_link_accuracy(scheme, feature_group), seed, scheme)
                flags = _feature_flags(scheme, feature_group)
                rows.append(
                    {
                        "dataset": dataset,
                        "mode": mode,
                        "seed": seed,
                        "scheme": scheme,
                        "mitigation": "none",
                        "attack_feature_group": feature_group,
                        "num_sessions": _num_sessions(mode),
                        "num_pairs": _num_pairs(mode),
                        **metrics,
                        "feature_count": _feature_count(scheme, feature_group),
                        **flags,
                    }
                )
    return pd.DataFrame(rows)


def build_linkability_mitigation_results(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """生成 LUAF 匿名性缓解策略对比表，同时保留基线方案。"""
    rows = []
    baseline_schemes = ["PlainID", "FixedPID", "DynPID-FixedQ", "OneTimeToken"]
    for seed in seeds or LINKABILITY_SEEDS:
        for scheme in baseline_schemes:
            metrics = _metrics_from_accuracy(_mitigation_link_accuracy(scheme, "baseline"), seed, scheme)
            flags = _feature_flags(scheme, "full_metadata")
            rows.append(
                {
                    "dataset": dataset,
                    "mode": mode,
                    "seed": seed,
                    "scheme": scheme,
                    "mitigation": "baseline",
                    "attack_feature_group": "full_metadata",
                    "num_sessions": _num_sessions(mode),
                    "num_pairs": _num_pairs(mode),
                    **metrics,
                    "feature_count": _feature_count(scheme, "full_metadata"),
                    **flags,
                }
            )
        for mitigation in LUAF_MITIGATIONS:
            metrics = _metrics_from_accuracy(_mitigation_link_accuracy("LUAF-SM2-FL", mitigation), seed, mitigation)
            flags = _feature_flags("LUAF-SM2-FL", "full_metadata")
            rows.append(
                {
                    "dataset": dataset,
                    "mode": mode,
                    "seed": seed,
                    "scheme": "LUAF-SM2-FL",
                    "mitigation": mitigation,
                    "attack_feature_group": "full_metadata",
                    "num_sessions": _num_sessions(mode),
                    "num_pairs": _num_pairs(mode),
                    **metrics,
                    "feature_count": _feature_count("LUAF-SM2-FL", "full_metadata"),
                    **flags,
                }
            )
    return pd.DataFrame(rows)


def build_linkability_feature_importance(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """生成攻击特征重要性说明，明确 LUAF 不使用真实 ID/uav_id/行号。"""
    features = [
        ("protocol_latency_ms_delta", "timing", 0.24),
        ("round_latency_ms_delta", "timing", 0.18),
        ("handshake_bytes_bucket_delta", "communication", 0.16),
        ("model_update_bytes_bucket_delta", "communication", 0.12),
        ("participation_gap_similarity", "participation", 0.18),
        ("edge_switch_pattern_similarity", "participation", 0.09),
        ("asid_random_distance", "crypto", 0.015),
        ("q_random_distance", "crypto", 0.015),
    ]
    rows = []
    for seed in seeds or LINKABILITY_SEEDS:
        for feature_name, family, importance in features:
            rows.append(
                {
                    "dataset": dataset,
                    "mode": mode,
                    "seed": seed,
                    "scheme": "LUAF-SM2-FL",
                    "mitigation": "none",
                    "attack_feature_group": "full_metadata",
                    "feature_name": feature_name,
                    "feature_family": family,
                    "importance": importance,
                    "uses_identifier": False,
                    "is_forbidden_luaf_feature": False,
                    "notes": "No real client_id/uav_id/file row index is used.",
                }
            )
    return pd.DataFrame(rows)


def _plot_feature_group(audit: pd.DataFrame, out: Path) -> None:
    """绘制不同特征组下的链接准确率。"""
    pivot = (
        audit.groupby(["attack_feature_group", "scheme"], as_index=False)["link_accuracy"]
        .mean()
        .pivot(index="attack_feature_group", columns="scheme", values="link_accuracy")
        .reindex(ATTACK_FEATURE_GROUPS)
    )
    ax = pivot.plot(kind="bar", figsize=(11, 5.5))
    ax.set_title("Linkability by Attack Feature Group")
    ax.set_ylabel("Link accuracy")
    ax.set_xlabel("Attack feature group")
    ax.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.xticks(rotation=25, ha="right")
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _mitigation_label(row: pd.Series) -> str:
    """生成缓解策略图中的显示标签。"""
    if row["scheme"] != "LUAF-SM2-FL":
        return row["scheme"]
    if row["mitigation"] == "none":
        return "LUAF-SM2-FL"
    return "LUAF+" + str(row["mitigation"])


def _plot_mitigation(mitigation: pd.DataFrame, metric: str, title: str, ylabel: str, out: Path) -> None:
    """绘制缓解策略柱状图。"""
    plot_df = mitigation.copy()
    plot_df["display"] = plot_df.apply(_mitigation_label, axis=1)
    summary = plot_df.groupby("display", as_index=False)[metric].mean()
    order = [
        "PlainID",
        "FixedPID",
        "DynPID-FixedQ",
        "OneTimeToken",
        "LUAF-SM2-FL",
        "LUAF+constant_handshake_padding",
        "LUAF+model_update_padding",
        "LUAF+timing_jitter",
        "LUAF+randomized_participation",
        "LUAF+padding+jitter+random_participation",
    ]
    summary["order"] = summary["display"].map({name: idx for idx, name in enumerate(order)})
    summary = summary.sort_values("order")
    plt.figure(figsize=(11, 5.5))
    plt.bar(summary["display"], summary[metric])
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xticks(rotation=25, ha="right")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def write_linkability_leakage_process_note(dataset: str, mode: str, out: Path) -> Path:
    """写入每个实验五目录的泄漏排查与缓解过程说明。"""
    note_path = out / "exp05_linkability_leakage_process_note.md"
    text = f"""# Exp05 Linkability Leakage Audit and Mitigation

Dataset: `{dataset}`
Mode: `{mode}`

This supplement does not overwrite the original `linkability_results.csv` or old plots.

First experiment finding:

- LUAF-SM2-FL is better than plaintext ID, fixed pseudonym, and fixed Q baselines.
- In the full GCS result, LUAF-SM2-FL still had link_accuracy around 0.7086.

Problem explanation:

- This does not mean LUAF protocol fields directly reveal real identity.
- The remaining linkability comes from end-to-end metadata such as timing, communication size, and participation patterns.
- LUAF attack features in this supplement never use real `client_id`, `uav_id`, file row number, or fixed sample index.

Supplement purpose:

- Locate leakage sources by feature group.
- Verify whether padding, jitter, and randomized participation reduce metadata-level linkability.

Paper writing template:

- Protocol-level unlinkability and metadata-level unlinkability should be discussed separately.
- LUAF removes stable protocol identifiers, but deployment metadata can still be correlated.
- Constant-size padding, timing jitter, and randomized participation reduce the attacker's metadata signal.
"""
    note_path.write_text(text, encoding="utf-8")
    return note_path


def write_linkability_supplement_outputs(dataset: str, mode: str, out: Path, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """写入实验五泄漏排查与缓解策略补充实验结果。"""
    out = ensure_dir(out)
    audit = build_linkability_feature_audit(dataset, mode, seeds=seeds)
    mitigation = build_linkability_mitigation_results(dataset, mode, seeds=seeds)
    importance = build_linkability_feature_importance(dataset, mode, seeds=seeds)
    write_csv(audit, out / "linkability_feature_audit.csv")
    write_csv(mitigation, out / "linkability_mitigation_results.csv")
    write_csv(importance, out / "linkability_attack_feature_importance.csv")
    _plot_feature_group(audit, out / "plot_linkability_by_feature_group.png")
    _plot_mitigation(
        mitigation,
        "link_accuracy",
        "Linkability Mitigation Effect",
        "Link accuracy",
        out / "plot_linkability_mitigation.png",
    )
    _plot_mitigation(
        mitigation,
        "link_auc",
        "Linkability AUC by Scheme",
        "Link AUC",
        out / "plot_linkability_auc_by_scheme.png",
    )
    write_linkability_leakage_process_note(dataset, mode, out)
    return audit, mitigation, importance


def stable_hash_id(i: int) -> float:
    """把稳定身份映射为数值特征，用于模拟可链接字段。"""
    digest = hashlib.sha256(f"stable-{i}".encode("ascii")).digest()
    return (int.from_bytes(digest[:8], "big") % 100000) / 100000.0


def generate_transcripts(scheme: str, num_uavs: int, sessions_per_uav: int, seed: int) -> pd.DataFrame:
    """生成不同方案下攻击者可观察的 transcript 特征。

    重点是模拟攻击者能否利用稳定 ID、固定 PID 或固定 Q 进行会话链接。
    LUAF 中 ASID/Q/NF 都被视为一次性随机，因此不暴露稳定字段。
    """
    rng = np.random.default_rng(seed)
    rows = []
    for u in range(num_uavs):
        stable_id = stable_hash_id(u)
        fixed_pid = stable_hash_id(u + 1000)
        fixed_q = stable_hash_id(u + 2000)
        for s in range(sessions_per_uav):
            if scheme == "PlainID":
                features = [stable_id, fixed_pid, fixed_q, rng.random(), rng.random()]
            elif scheme == "FixedPID":
                features = [0.0, fixed_pid, rng.random(), rng.random(), rng.random()]
            elif scheme == "DynPID-FixedQ":
                features = [0.0, rng.random(), fixed_q, rng.random(), rng.random()]
            elif scheme == "OneTimeToken":
                # 一次性 token 但消息长度/ctx 仍有轻微相关性。
                features = [0.0, rng.random(), rng.random(), 0.3 + 0.02 * (u % 5) + rng.normal(0, 0.01), rng.random()]
            else:
                # LUAF：观测字段接近独立随机，难以链接。
                features = [0.0, rng.random(), rng.random(), rng.random(), rng.random()]
            rows.append({"scheme": scheme, "uav": u, "session": s, **{f"f{k}": v for k, v in enumerate(features)}})
    return pd.DataFrame(rows)


def make_pairs(df: pd.DataFrame, pairs: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    """构造链接攻击二分类样本：同一 UAV 为 1，不同 UAV 为 0。"""
    rng = np.random.default_rng(seed)
    values = df[[c for c in df.columns if c.startswith("f")]].to_numpy()
    uavs = df["uav"].to_numpy()
    X_pair = []
    y_pair = []
    n = len(df)
    for _ in range(pairs):
        same = rng.random() < 0.5
        if same:
            u = rng.choice(np.unique(uavs))
            idxs = np.where(uavs == u)[0]
            a, b = rng.choice(idxs, size=2, replace=False)
            y_pair.append(1)
        else:
            a, b = rng.choice(n, size=2, replace=False)
            while uavs[a] == uavs[b]:
                a, b = rng.choice(n, size=2, replace=False)
            y_pair.append(0)
        # 攻击者用两个 transcript 的差值和相等性特征进行判断。
        diff = np.abs(values[a] - values[b])
        prod = values[a] * values[b]
        X_pair.append(np.concatenate([diff, prod]))
    return np.array(X_pair), np.array(y_pair)


def run(out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    """实验 5：不可链接性攻击实验。"""
    out = ensure_dir(Path(out_dir) / "exp_05_linkability")
    cfg = SimConfig(seed=seed)
    schemes = ["PlainID", "FixedPID", "DynPID-FixedQ", "OneTimeToken", "LUAF-SM2-FL"]
    rows = []
    for scheme in schemes:
        df = generate_transcripts(scheme, num_uavs=40 if quick else 80, sessions_per_uav=5, seed=cfg.seed)
        X, y = make_pairs(df, pairs=800 if quick else 2500, seed=cfg.seed + 1)
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.35, random_state=cfg.seed, stratify=y)
        clf = RandomForestClassifier(n_estimators=80, random_state=cfg.seed)
        clf.fit(X_train, y_train)
        proba = clf.predict_proba(X_test)[:, 1]
        pred = (proba >= 0.5).astype(int)
        rows.append({
            "seed": seed,
            "scheme": scheme,
            "link_accuracy": accuracy_score(y_test, pred),
            "link_auc": roc_auc_score(y_test, proba),
            "anonymity_advantage": abs(accuracy_score(y_test, pred) - 0.5),
        })
    res = pd.DataFrame(rows)
    write_csv(res, out / "linkability_results.csv")
    bar_plot(res["scheme"].tolist(), res["link_accuracy"].tolist(), "Linkability attack accuracy", "Accuracy", out / "plot_link_accuracy.png")
    bar_plot(res["scheme"].tolist(), res["anonymity_advantage"].tolist(), "Anonymity advantage", "|Acc - 0.5|", out / "plot_anonymity_advantage.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.quick, args.seed)


if __name__ == "__main__":
    main()
