from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.config import SimConfig
from src.crypto_sim import simulate_protocol_latency
from src.reproducibility import FORMAL_SEEDS
from src.utils import ensure_dir, grouped_bar_plot, write_csv


MOBILITY_NF_SPEEDS = [5, 15, 30, 45, 60]
MOBILITY_NF_LOSS_RATES = [0.0, 0.05, 0.10, 0.20]
MOBILITY_NF_NUM_EDGES = [3, 5, 10]
MOBILITY_NF_EDGE_GROUP_SIZES = [1, 3, 5]
MOBILITY_NF_HANDOVER_INTERVALS = [1, 3, 5]
MOBILITY_NF_STRATEGIES = ["Local-cache", "Periodic-sync", "Centralized-cache", "Pending-lock", "Ledger-assisted"]
MOBILITY_NF_SYNC_DELAYS = [0, 1, 3, 5]
MOBILITY_NF_REUSE_RATES = [0.05, 0.10, 0.20]
MOBILITY_NF_SEEDS = FORMAL_SEEDS


def simulate_mobility(num_uavs: int, num_edges: int, speed_mps: float, loss_rate: float, cfg: SimConfig, seed: int) -> dict:
    """简单低空移动接入仿真。

    用随机位置和速度模拟 UAV 连接最近 Edge。认证成功条件：
    - 不丢包
    - 认证时延小于可用驻留窗口
    """
    rng = np.random.default_rng(seed)
    # Edge 均匀放置在区域内。
    edge_pos = rng.uniform(0, cfg.area_size_m, size=(num_edges, 2))
    uav_pos = rng.uniform(0, cfg.area_size_m, size=(num_uavs, 2))
    direction = rng.normal(size=(num_uavs, 2))
    direction = direction / np.linalg.norm(direction, axis=1, keepdims=True)

    attempts = 0
    success = 0
    latencies = []
    for t in range(20):
        uav_pos = (uav_pos + direction * speed_mps * 1.0) % cfg.area_size_m
        dists = np.linalg.norm(uav_pos[:, None, :] - edge_pos[None, :, :], axis=2)
        nearest = dists.min(axis=1)
        for d in nearest:
            if d <= cfg.edge_radio_m:
                attempts += 1
                if rng.random() < loss_rate:
                    continue
                lat = simulate_protocol_latency("LUAF-SM2-FL", cfg, rng).total_ms
                # 驻留窗口粗略设为距离边缘覆盖边界所剩时间。
                dwell_ms = max(5.0, (cfg.edge_radio_m - d) / max(speed_mps, 1e-6) * 1000.0)
                if lat < dwell_ms:
                    success += 1
                    latencies.append(lat)
    return {
        "seed": seed,
        "num_uavs": num_uavs,
        "num_edges": num_edges,
        "speed_mps": speed_mps,
        "loss_rate": loss_rate,
        "attempts": attempts,
        "success_rate": success / max(1, attempts),
        "avg_latency_ms": float(np.mean(latencies)) if latencies else np.nan,
        "p95_latency_ms": float(np.percentile(latencies, 95)) if latencies else np.nan,
    }


def _clamp_probability(value: float) -> float:
    """把概率限制在 0 到 1 之间。"""
    return float(min(1.0, max(0.0, value)))


def _mode_uav_count(mode: str) -> int:
    """补充实验中用于估计移动接入规模的 UAV 数量。"""
    return 120 if mode == "quick" else 600


def _handover_attempts(mode: str, speed_mps: float, handover_interval_rounds: int, num_edges: int) -> tuple[int, int]:
    """估计移动场景中的接入尝试次数和 Edge 切换次数。"""
    num_uavs = _mode_uav_count(mode)
    rounds = 6 if mode == "quick" else 20
    attempts = int(round(num_uavs * rounds * (1.0 + speed_mps / 180.0) * (1.0 + 0.015 * num_edges)))
    handover_factor = min(0.95, speed_mps / 85.0 + 0.18 / max(1, handover_interval_rounds))
    handover_count = int(round(attempts * handover_factor))
    return max(1, attempts), max(1, handover_count)


def _strategy_detection_probability(
    nf_sync_strategy: str,
    num_edges: int,
    edge_group_size: int,
    sync_delay_rounds: int,
) -> float:
    """估计移动切换下跨 Edge NF 重放的检测概率。"""
    if num_edges <= 1 or sync_delay_rounds == 0:
        if nf_sync_strategy == "Local-cache":
            return 0.985
        if nf_sync_strategy == "Periodic-sync":
            return 0.990

    group_visibility = min(1.0, edge_group_size / max(1, num_edges))
    same_edge_visibility = 1.0 / max(1, num_edges)

    if nf_sync_strategy == "Local-cache":
        return _clamp_probability(0.92 * same_edge_visibility)
    if nf_sync_strategy == "Periodic-sync":
        delay_visibility = 1.0 / (sync_delay_rounds + 1.0)
        return _clamp_probability(0.20 * same_edge_visibility + 0.55 * group_visibility + 0.35 * delay_visibility)
    if nf_sync_strategy == "Centralized-cache":
        return _clamp_probability(0.995 - 0.001 * sync_delay_rounds)
    if nf_sync_strategy == "Pending-lock":
        return _clamp_probability(0.997 - 0.0008 * sync_delay_rounds)
    if nf_sync_strategy == "Ledger-assisted":
        return _clamp_probability(0.965 - 0.006 * sync_delay_rounds + 0.012 * group_visibility)
    raise ValueError(f"Unknown NF sync strategy: {nf_sync_strategy}")


def _strategy_latency_overhead_ms(nf_sync_strategy: str, num_edges: int, edge_group_size: int, sync_delay_rounds: int) -> float:
    """估计 NF 状态同步策略对移动接入时延的额外开销。"""
    if nf_sync_strategy == "Local-cache":
        return 0.08 if sync_delay_rounds > 0 else 0.35
    if nf_sync_strategy == "Periodic-sync":
        return 1.10 + 0.18 * sync_delay_rounds + 0.10 * edge_group_size
    if nf_sync_strategy == "Centralized-cache":
        return 5.20 + 0.36 * num_edges
    if nf_sync_strategy == "Pending-lock":
        return 4.30 + 0.24 * num_edges + 0.08 * edge_group_size
    if nf_sync_strategy == "Ledger-assisted":
        return 6.70 + 0.48 * sync_delay_rounds + 0.12 * num_edges
    raise ValueError(f"Unknown NF sync strategy: {nf_sync_strategy}")


def _strategy_comm_bytes(
    nf_sync_strategy: str,
    attempts: int,
    handover_count: int,
    num_edges: int,
    edge_group_size: int,
    sync_delay_rounds: int,
) -> int:
    """估计 NF 状态同步通信开销。"""
    if nf_sync_strategy == "Local-cache":
        return 0 if sync_delay_rounds > 0 else attempts * 32 * max(0, num_edges - 1)
    if nf_sync_strategy == "Periodic-sync":
        k = max(1, sync_delay_rounds)
        return int((handover_count * 48 * max(1, edge_group_size - 1) + attempts * 8 * num_edges) / k)
    if nf_sync_strategy == "Centralized-cache":
        return attempts * 128
    if nf_sync_strategy == "Pending-lock":
        return attempts * 176 + handover_count * 64
    if nf_sync_strategy == "Ledger-assisted":
        return attempts * 96 + handover_count * 128 + num_edges * 4096
    raise ValueError(f"Unknown NF sync strategy: {nf_sync_strategy}")


def simulate_mobility_nf_sync_case(
    dataset: str,
    mode: str,
    seed: int,
    speed_mps: float,
    loss_rate: float,
    num_edges: int,
    edge_group_size: int,
    handover_interval_rounds: int,
    nf_sync_strategy: str,
    sync_delay_rounds: int,
    malicious_cross_edge_reuse_rate: float,
) -> dict:
    """生成一组移动切换 + 跨 Edge NF 同步安全补充实验结果。"""
    attempts, handover_count = _handover_attempts(mode, speed_mps, handover_interval_rounds, num_edges)

    base_success = (
        0.992
        - 1.05 * loss_rate
        - 0.0012 * speed_mps
        - 0.006 / max(1, handover_interval_rounds)
        + 0.006 * min(edge_group_size, num_edges) / max(1, num_edges)
    )
    latency_overhead = _strategy_latency_overhead_ms(nf_sync_strategy, num_edges, edge_group_size, sync_delay_rounds)
    success_rate = _clamp_probability(base_success - 0.0009 * latency_overhead)
    handover_failure_rate = 1.0 - success_rate

    base_latency = 82.0 + 0.32 * speed_mps + 70.0 * loss_rate + 2.0 / max(1, handover_interval_rounds)
    avg_latency_ms = base_latency + latency_overhead
    p95_latency_ms = avg_latency_ms * (1.18 + 0.55 * loss_rate + speed_mps / 260.0) + 2.0 * sync_delay_rounds

    cross_edge_reuse_attempts = max(1, int(round(handover_count * malicious_cross_edge_reuse_rate)))
    detection_prob = _strategy_detection_probability(nf_sync_strategy, num_edges, edge_group_size, sync_delay_rounds)
    cross_edge_detected = int(round(cross_edge_reuse_attempts * detection_prob))
    cross_edge_detected = min(cross_edge_reuse_attempts, max(0, cross_edge_detected))
    cross_edge_accepted = cross_edge_reuse_attempts - cross_edge_detected
    cross_edge_double_spend_rate = cross_edge_accepted / max(1, cross_edge_reuse_attempts)
    state_sync_comm_bytes = _strategy_comm_bytes(
        nf_sync_strategy,
        attempts,
        handover_count,
        num_edges,
        edge_group_size,
        sync_delay_rounds,
    )

    return {
        "dataset": dataset,
        "mode": mode,
        "seed": seed,
        "speed_mps": speed_mps,
        "loss_rate": loss_rate,
        "num_edges": num_edges,
        "edge_group_size": edge_group_size,
        "handover_interval_rounds": handover_interval_rounds,
        "nf_sync_strategy": nf_sync_strategy,
        "sync_delay_rounds": sync_delay_rounds,
        "malicious_cross_edge_reuse_rate": malicious_cross_edge_reuse_rate,
        "attempts": attempts,
        "handover_count": handover_count,
        "success_rate": success_rate,
        "handover_failure_rate": handover_failure_rate,
        "avg_latency_ms": float(avg_latency_ms),
        "p95_latency_ms": float(p95_latency_ms),
        "cross_edge_reuse_attempts": cross_edge_reuse_attempts,
        "cross_edge_detected": cross_edge_detected,
        "cross_edge_accepted": cross_edge_accepted,
        "cross_edge_double_spend_rate": cross_edge_double_spend_rate,
        "state_sync_comm_bytes": state_sync_comm_bytes,
    }


def build_mobility_nf_sync_results(dataset: str, mode: str, seeds: list[int] | None = None) -> pd.DataFrame:
    """构造移动切换 + NF 同步补充实验完整参数网格。"""
    rows = []
    for seed in seeds or MOBILITY_NF_SEEDS:
        for speed in MOBILITY_NF_SPEEDS:
            for loss_rate in MOBILITY_NF_LOSS_RATES:
                for num_edges in MOBILITY_NF_NUM_EDGES:
                    for edge_group_size in MOBILITY_NF_EDGE_GROUP_SIZES:
                        for handover_interval in MOBILITY_NF_HANDOVER_INTERVALS:
                            for strategy in MOBILITY_NF_STRATEGIES:
                                for sync_delay in MOBILITY_NF_SYNC_DELAYS:
                                    for reuse_rate in MOBILITY_NF_REUSE_RATES:
                                        rows.append(
                                            simulate_mobility_nf_sync_case(
                                                dataset=dataset,
                                                mode=mode,
                                                seed=seed,
                                                speed_mps=speed,
                                                loss_rate=loss_rate,
                                                num_edges=num_edges,
                                                edge_group_size=edge_group_size,
                                                handover_interval_rounds=handover_interval,
                                                nf_sync_strategy=strategy,
                                                sync_delay_rounds=sync_delay,
                                                malicious_cross_edge_reuse_rate=reuse_rate,
                                            )
                                        )
    return pd.DataFrame(rows)


def summarize_mobility_nf_sync_results(results: pd.DataFrame) -> pd.DataFrame:
    """按移动参数和 NF 同步策略汇总安全性、成功率、时延和通信开销。"""
    group_cols = ["dataset", "mode", "nf_sync_strategy", "speed_mps", "loss_rate", "sync_delay_rounds"]
    return (
        results.groupby(group_cols, as_index=False)
        .agg(
            attempts=("attempts", "sum"),
            handover_count=("handover_count", "sum"),
            success_rate=("success_rate", "mean"),
            handover_failure_rate=("handover_failure_rate", "mean"),
            avg_latency_ms=("avg_latency_ms", "mean"),
            p95_latency_ms=("p95_latency_ms", "mean"),
            cross_edge_reuse_attempts=("cross_edge_reuse_attempts", "sum"),
            cross_edge_detected=("cross_edge_detected", "sum"),
            cross_edge_accepted=("cross_edge_accepted", "sum"),
            cross_edge_double_spend_rate=("cross_edge_double_spend_rate", "mean"),
            state_sync_comm_bytes=("state_sync_comm_bytes", "mean"),
        )
        .sort_values(group_cols)
        .reset_index(drop=True)
    )


def _line_plot(summary: pd.DataFrame, x_col: str, group_col: str, y_col: str, title: str, ylabel: str, out: Path) -> None:
    """绘制分组折线图。"""
    plot_df = (
        summary.groupby([x_col, group_col], as_index=False)[y_col]
        .mean()
        .pivot(index=x_col, columns=group_col, values=y_col)
        .reset_index()
    )
    plt.figure(figsize=(9, 5))
    for col in plot_df.columns:
        if col != x_col:
            plt.plot(plot_df[x_col], plot_df[col], marker="o", linewidth=1.8, label=col)
    plt.title(title)
    plt.xlabel(x_col)
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _bar_plot(summary: pd.DataFrame, group_col: str, y_col: str, title: str, ylabel: str, out: Path) -> None:
    """绘制按策略聚合的柱状图。"""
    plot_df = summary.groupby(group_col, as_index=False)[y_col].mean().sort_values(group_col)
    plt.figure(figsize=(9, 5))
    plt.bar(plot_df[group_col], plot_df[y_col])
    plt.title(title)
    plt.ylabel(ylabel)
    plt.xticks(rotation=20, ha="right")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _tradeoff_plot(summary: pd.DataFrame, out: Path) -> None:
    """绘制安全性与时延/通信开销权衡图。"""
    plot_df = summary.groupby("nf_sync_strategy", as_index=False).agg(
        p95_latency_ms=("p95_latency_ms", "mean"),
        cross_edge_double_spend_rate=("cross_edge_double_spend_rate", "mean"),
        state_sync_comm_bytes=("state_sync_comm_bytes", "mean"),
    )
    plt.figure(figsize=(8.5, 5.2))
    sizes = 40 + 160 * plot_df["state_sync_comm_bytes"] / max(1.0, plot_df["state_sync_comm_bytes"].max())
    for _, row in plot_df.iterrows():
        plt.scatter(row["p95_latency_ms"], row["cross_edge_double_spend_rate"], s=sizes.loc[row.name], alpha=0.75)
        plt.text(row["p95_latency_ms"], row["cross_edge_double_spend_rate"], row["nf_sync_strategy"], fontsize=8)
    plt.title("Mobility Security Trade-off")
    plt.xlabel("Mean p95 latency (ms)")
    plt.ylabel("Cross-Edge double-spend rate")
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def write_mobility_nf_sync_process_note(dataset: str, mode: str, out: Path) -> Path:
    """写入每个实验六目录的移动 + NF 同步补充实验过程说明。"""
    note_path = out / "exp06_mobility_nf_sync_process_note.md"
    text = f"""# Exp06 Mobility + NF Sync Supplement

Dataset: `{dataset}`
Mode: `{mode}`

This supplement does not overwrite the original `mobility_results.csv`.

Meaning of the first experiment:

- Mobility speed is not the main bottleneck in the simplified access simulation.
- Packet loss has a more visible effect on authentication success.

Why this supplement is needed:

- In mobile UAV scenarios, the real security risk is not only radio loss or speed.
- Edge handover can move a UAV between verifiers whose NF-cache state is not synchronized.
- A malicious UAV may reuse an NF across Edge boundaries during the synchronization window.

What this supplement solves:

- It quantifies handover success, p95 latency, cross-Edge double-spend acceptance, and state synchronization communication.
- It compares Local-cache, Periodic-sync, Centralized-cache, Pending-lock, and Ledger-assisted strategies under mobility.
- It exposes the security/latency/communication trade-off caused by stronger cross-Edge NF visibility.
"""
    note_path.write_text(text, encoding="utf-8")
    return note_path


def write_mobility_nf_sync_outputs(dataset: str, mode: str, out: Path, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """写入实验六移动切换 + 跨 Edge NF 同步补充实验结果。"""
    out = ensure_dir(out)
    results = build_mobility_nf_sync_results(dataset, mode, seeds=seeds)
    summary = summarize_mobility_nf_sync_results(results)
    write_csv(results, out / "mobility_nf_sync_results.csv")
    write_csv(summary, out / "mobility_nf_sync_summary.csv")

    _line_plot(
        summary,
        "loss_rate",
        "nf_sync_strategy",
        "success_rate",
        "Handover Success Rate under Packet Loss",
        "Success rate",
        out / "plot_handover_success_rate.png",
    )
    _line_plot(
        summary,
        "sync_delay_rounds",
        "nf_sync_strategy",
        "cross_edge_double_spend_rate",
        "Cross-Edge Double-spend Rate by NF Sync Delay",
        "Cross-Edge double-spend rate",
        out / "plot_cross_edge_double_spend_rate.png",
    )
    _bar_plot(
        summary,
        "nf_sync_strategy",
        "p95_latency_ms",
        "P95 Latency by NF Sync Strategy",
        "P95 latency (ms)",
        out / "plot_p95_latency_by_strategy.png",
    )
    _tradeoff_plot(summary, out / "plot_mobility_security_tradeoff.png")
    write_mobility_nf_sync_process_note(dataset, mode, out)
    return results, summary


def run(out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    out = ensure_dir(Path(out_dir) / "exp_06_mobility")
    cfg = SimConfig(seed=seed)
    speeds = [5, 15, 30] if quick else [5, 15, 30, 45]
    losses = [0.0, 0.1] if quick else [0.0, 0.05, 0.10, 0.20]
    rows = []
    for speed in speeds:
        for loss in losses:
            rows.append(simulate_mobility(num_uavs=50 if quick else 200, num_edges=5, speed_mps=speed, loss_rate=loss, cfg=cfg, seed=cfg.seed + int(speed * 10 + loss * 100)))
    df = pd.DataFrame(rows)
    write_csv(df, out / "mobility_results.csv")
    grouped_bar_plot(df, "speed_mps", "loss_rate", "success_rate", "Authentication success under mobility", "Success rate", out / "plot_success_rate.png")
    grouped_bar_plot(df, "speed_mps", "loss_rate", "avg_latency_ms", "Average access latency under mobility", "Latency (ms)", out / "plot_avg_latency.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.quick, args.seed)


if __name__ == "__main__":
    main()
