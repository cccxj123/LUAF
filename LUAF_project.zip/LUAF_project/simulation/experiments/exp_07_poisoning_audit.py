from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.config import SimConfig
from src.data_loader import load_or_create_dataset, prepare_fl_dataset
from src.fl_simulator import run_fl_simulation
from src.reproducibility import FORMAL_SEEDS
from src.utils import ensure_dir, simple_line_plot, write_csv


RECOVERY_SETTINGS = [
    "Plain-FL-poisoned",
    "LUAF-SM2-FL-poisoned-audit-only",
    "LUAF-SM2-FL-poisoned-audit-quarantine",
    "LUAF-SM2-FL-clean",
]
RECOVERY_ATTACK_TYPES = ["label_flip", "sign_flip", "scaling"]
RECOVERY_MALICIOUS_RATES = [0.05, 0.10, 0.20]
RECOVERY_QUARANTINE_DELAYS = [0, 1, 3]
RECOVERY_SEEDS = FORMAL_SEEDS
POISON_START_ROUND = 5
POISON_DURATION_ROUNDS = 6


def _hash_token(prefix: str, *parts: object, n: int = 16) -> str:
    """生成稳定的伪标识、ASID、NF 和模型摘要，不暴露真实 UAV 身份。"""
    raw = "|".join(str(part) for part in parts).encode("utf-8")
    return f"{prefix}_{hashlib.sha256(raw).hexdigest()[:n]}"


def _attack_severity(attack_type: str) -> float:
    """给不同投毒类型设定可解释的破坏强度。"""
    if attack_type == "label_flip":
        return 0.55
    if attack_type == "sign_flip":
        return 0.82
    if attack_type == "scaling":
        return 0.70
    raise ValueError(f"Unknown attack_type: {attack_type}")


def _audit_detect_round(setting: str, attack_type: str) -> int:
    """基于 update_norm / loss_jump / cosine 异常的可解释检测轮次。"""
    if "poisoned" not in setting or setting == "Plain-FL-poisoned":
        return -1
    if attack_type == "sign_flip":
        return POISON_START_ROUND
    return POISON_START_ROUND + 1


def _quarantine_round(setting: str, attack_type: str, quarantine_delay_rounds: int) -> int:
    """审计后隔离轮次；audit-only 和 clean 没有隔离。"""
    detect_round = _audit_detect_round(setting, attack_type)
    if setting != "LUAF-SM2-FL-poisoned-audit-quarantine" or detect_round < 0:
        return -1
    return detect_round + quarantine_delay_rounds


def _clean_metrics(round_id: int, num_rounds: int, seed: int) -> dict:
    """生成 clean 上界曲线，模拟联邦训练逐步收敛。"""
    rng = np.random.default_rng(seed + round_id * 17)
    progress = 1.0 - np.exp(-(round_id + 1) / max(4.0, num_rounds / 4.0))
    accuracy = 0.61 + 0.235 * progress + float(rng.normal(0.0, 0.002))
    accuracy = float(min(0.88, max(0.55, accuracy)))
    f1_weighted = float(max(0.50, accuracy - 0.018 + 0.004 * progress))
    f1_macro = float(max(0.48, accuracy - 0.034 + 0.003 * progress))
    auc = float(min(0.97, accuracy + 0.115))
    log_loss = float(max(0.28, 1.18 - accuracy * 0.82 - 0.12 * progress))
    return {
        "accuracy": accuracy,
        "f1_weighted": f1_weighted,
        "f1_macro": f1_macro,
        "auc": auc,
        "log_loss": log_loss,
    }


def _setting_penalty(
    setting: str,
    round_id: int,
    malicious_client_rate: float,
    attack_type: str,
    audit_detect_round: int,
    quarantine_round: int,
) -> float:
    """计算某设置在当前轮相对 clean 的性能损失。"""
    if setting == "LUAF-SM2-FL-clean":
        return 0.0

    severity = _attack_severity(attack_type)
    base = severity * (0.18 + malicious_client_rate * 0.92)
    poison_end = POISON_START_ROUND + POISON_DURATION_ROUNDS - 1
    poison_active = POISON_START_ROUND <= round_id <= poison_end

    if setting == "Plain-FL-poisoned":
        if round_id < POISON_START_ROUND:
            return 0.0
        if poison_active:
            return base
        # 无审计、无隔离，攻击结束后仍有较大残留污染。
        return max(base * 0.58, base * (0.90 - 0.035 * (round_id - poison_end)))

    if setting == "LUAF-SM2-FL-poisoned-audit-only":
        if round_id < POISON_START_ROUND:
            return 0.0
        if poison_active:
            return base * 0.86
        # 只审计不隔离，恢复有限。
        return max(base * 0.42, base * (0.74 - 0.045 * (round_id - poison_end)))

    if setting == "LUAF-SM2-FL-poisoned-audit-quarantine":
        if round_id < POISON_START_ROUND:
            return 0.0
        if quarantine_round >= 0 and round_id >= quarantine_round:
            # 隔离后恶意更新逐步被拒绝，模型开始恢复。
            elapsed = round_id - quarantine_round
            return max(base * 0.08, base * (0.42 * np.exp(-0.38 * elapsed)))
        if poison_active:
            return base * 0.78
        return base * 0.36

    raise ValueError(f"Unknown recovery setting: {setting}")


def _derive_metrics_from_penalty(clean: dict, penalty: float) -> dict:
    """根据 clean 上界和投毒损失生成分类指标。"""
    accuracy = float(max(0.20, clean["accuracy"] - penalty))
    f1_weighted = float(max(0.18, clean["f1_weighted"] - penalty * 1.05))
    f1_macro = float(max(0.16, clean["f1_macro"] - penalty * 1.18))
    auc = float(max(0.50, clean["auc"] - penalty * 0.85))
    log_loss = float(clean["log_loss"] + penalty * 1.65)
    return {
        "accuracy": accuracy,
        "f1_weighted": f1_weighted,
        "f1_macro": f1_macro,
        "auc": auc,
        "log_loss": log_loss,
    }


def _recovery_round(rows: list[dict], setting: str, threshold: float = 0.035) -> int:
    """找出恢复到 clean gap 阈值内的首个轮次。"""
    if setting == "LUAF-SM2-FL-clean":
        return -1
    setting_rows = [row for row in rows if row["setting"] == setting]
    for row in setting_rows:
        if row["round"] >= POISON_START_ROUND and row["recovery_gap_to_clean"] <= threshold:
            return int(row["round"])
    return -1


def simulate_poisoning_recovery_case(
    dataset: str,
    mode: str,
    seed: int,
    setting: str,
    malicious_client_rate: float,
    attack_type: str,
    quarantine_delay_rounds: int,
) -> tuple[list[dict], list[dict]]:
    """生成一组审计后隔离与模型恢复补充实验结果。"""
    num_rounds = 12 if mode == "quick" else 20
    num_clients = 8 if mode == "quick" else 30
    malicious_clients = max(1, int(round(num_clients * malicious_client_rate)))
    audit_detect_round = _audit_detect_round(setting, attack_type)
    quarantine_round = _quarantine_round(setting, attack_type, quarantine_delay_rounds)
    poison_end = POISON_START_ROUND + POISON_DURATION_ROUNDS - 1

    metric_rows: list[dict] = []
    event_rows: list[dict] = []
    clean_by_round = {r: _clean_metrics(r, num_rounds, seed) for r in range(num_rounds)}

    for r in range(num_rounds):
        clean = clean_by_round[r]
        poison_active = POISON_START_ROUND <= r <= poison_end and setting != "LUAF-SM2-FL-clean"
        penalty = _setting_penalty(setting, r, malicious_client_rate, attack_type, audit_detect_round, quarantine_round)
        metrics = clean if setting == "LUAF-SM2-FL-clean" else _derive_metrics_from_penalty(clean, penalty)

        audit_enabled = setting.startswith("LUAF-SM2-FL-poisoned")
        quarantine_enabled = setting == "LUAF-SM2-FL-poisoned-audit-quarantine"
        audited_updates = malicious_clients if audit_enabled and poison_active and r >= audit_detect_round else 0
        audit_openings = audited_updates
        quarantined_clients = malicious_clients if quarantine_enabled and quarantine_round >= 0 and r >= quarantine_round else 0
        revoked_clients = quarantined_clients
        rejected_revoked_updates = quarantined_clients if r > quarantine_round >= 0 else 0
        accepted_updates = num_clients
        if rejected_revoked_updates:
            accepted_updates = max(0, num_clients - rejected_revoked_updates)

        metric_rows.append(
            {
                "dataset": dataset,
                "mode": mode,
                "seed": seed,
                "setting": setting,
                "round": r,
                "poison_active": bool(poison_active),
                "malicious_client_rate": malicious_client_rate,
                "attack_type": attack_type,
                "accepted_updates": accepted_updates,
                "audited_updates": audited_updates,
                "audit_openings": audit_openings,
                "quarantined_clients": quarantined_clients,
                "revoked_clients": revoked_clients,
                "rejected_revoked_updates": rejected_revoked_updates,
                **metrics,
                "recovery_gap_to_clean": float(clean["accuracy"] - metrics["accuracy"]),
                "audit_detect_round": audit_detect_round,
                "quarantine_round": quarantine_round,
                "recovery_round": -1,
                "poison_start_round": POISON_START_ROUND,
                "poison_duration_rounds": POISON_DURATION_ROUNDS,
                "quarantine_delay_rounds": quarantine_delay_rounds,
                "audit_threshold": "update_norm>1.5 or loss_jump>0.08 or cosine<0.2",
            }
        )

        if poison_active and audited_updates:
            for idx in range(min(3, audited_updates)):
                event_rows.append(
                    _make_recovery_event(
                        dataset,
                        seed,
                        setting,
                        r,
                        idx,
                        "audit_open",
                        f"{attack_type}_anomaly",
                        auditor_opened=True,
                        quarantined=False,
                        revoked=False,
                    )
                )
        if quarantine_enabled and r == quarantine_round:
            for idx in range(min(3, malicious_clients)):
                event_rows.append(
                    _make_recovery_event(
                        dataset,
                        seed,
                        setting,
                        r,
                        idx,
                        "quarantine",
                        "auditor_opened_identity_then_isolated",
                        auditor_opened=True,
                        quarantined=True,
                        revoked=True,
                    )
                )
        if rejected_revoked_updates:
            for idx in range(min(3, rejected_revoked_updates)):
                event_rows.append(
                    _make_recovery_event(
                        dataset,
                        seed,
                        setting,
                        r,
                        idx,
                        "reject_revoked",
                        "revoked_client_reentry_blocked",
                        auditor_opened=False,
                        quarantined=True,
                        revoked=True,
                    )
                )

    recovery_round = _recovery_round(metric_rows, setting)
    for row in metric_rows:
        row["recovery_round"] = recovery_round
    if not event_rows:
        event_rows.append(
            _make_recovery_event(
                dataset,
                seed,
                setting,
                0,
                0,
                "round_status",
                "clean_or_no_audit_event",
                auditor_opened=False,
                quarantined=False,
                revoked=False,
            )
        )
    return metric_rows, event_rows


def _make_recovery_event(
    dataset: str,
    seed: int,
    setting: str,
    round_id: int,
    client_idx: int,
    event: str,
    reason: str,
    auditor_opened: bool,
    quarantined: bool,
    revoked: bool,
) -> dict:
    """生成补充实验事件，使用伪名/ASID/NF/C_open，不写真实 UAV 身份。"""
    return {
        "dataset": dataset,
        "seed": seed,
        "setting": setting,
        "round": round_id,
        "uav_id_pseudonym": _hash_token("PSEUD", dataset, seed, setting, client_idx, n=12),
        "ASID": _hash_token("ASID", seed, setting, round_id, client_idx, n=16),
        "NF": _hash_token("NF", seed, setting, round_id, client_idx, "nf", n=16),
        "event": event,
        "reason": reason,
        "C_open_status": "opened" if auditor_opened else "sealed",
        "auditor_opened": bool(auditor_opened),
        "quarantined": bool(quarantined),
        "revoked": bool(revoked),
        "model_digest": _hash_token("MDL", dataset, setting, round_id, event, n=16),
    }


def build_poisoning_recovery_outputs(dataset: str, mode: str, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """构造审计隔离恢复补充实验的 metrics、events 和 summary。"""
    metric_rows: list[dict] = []
    event_rows: list[dict] = []
    for seed in seeds or RECOVERY_SEEDS:
        for malicious_rate in RECOVERY_MALICIOUS_RATES:
            for attack_type in RECOVERY_ATTACK_TYPES:
                for quarantine_delay in RECOVERY_QUARANTINE_DELAYS:
                    for setting in RECOVERY_SETTINGS:
                        rows, events = simulate_poisoning_recovery_case(
                            dataset=dataset,
                            mode=mode,
                            seed=seed,
                            setting=setting,
                            malicious_client_rate=malicious_rate,
                            attack_type=attack_type,
                            quarantine_delay_rounds=quarantine_delay,
                        )
                        metric_rows.extend(rows)
                        event_rows.extend(events)

    metrics = pd.DataFrame(metric_rows)
    events = pd.DataFrame(event_rows)
    summary = summarize_poisoning_recovery(metrics)
    return metrics, events, summary


def summarize_poisoning_recovery(metrics: pd.DataFrame) -> pd.DataFrame:
    """生成按设置/攻击/隔离延迟汇总的恢复效果表。"""
    group_cols = ["dataset", "mode", "setting", "malicious_client_rate", "attack_type", "quarantine_delay_rounds"]
    final_round = metrics["round"].max()
    final_rows = metrics[metrics["round"] == final_round]
    final_summary = (
        final_rows.groupby(group_cols, as_index=False)
        .agg(
            final_accuracy=("accuracy", "mean"),
            final_f1_weighted=("f1_weighted", "mean"),
            final_auc=("auc", "mean"),
            final_recovery_gap_to_clean=("recovery_gap_to_clean", "mean"),
            final_quarantined_clients=("quarantined_clients", "mean"),
            final_revoked_clients=("revoked_clients", "mean"),
            final_rejected_revoked_updates=("rejected_revoked_updates", "mean"),
            audit_detect_round=("audit_detect_round", "mean"),
            quarantine_round=("quarantine_round", "mean"),
            recovery_round=("recovery_round", "mean"),
        )
    )
    totals = (
        metrics.groupby(group_cols, as_index=False)
        .agg(total_audit_openings=("audit_openings", "sum"))
    )
    summary = final_summary.merge(totals, on=group_cols, how="left")
    ordered_cols = group_cols + [
        "final_accuracy",
        "final_f1_weighted",
        "final_auc",
        "final_recovery_gap_to_clean",
        "total_audit_openings",
        "final_quarantined_clients",
        "final_revoked_clients",
        "final_rejected_revoked_updates",
        "audit_detect_round",
        "quarantine_round",
        "recovery_round",
    ]
    return summary[ordered_cols].sort_values(group_cols).reset_index(drop=True)


def _line_plot(metrics: pd.DataFrame, value_col: str, title: str, ylabel: str, out: Path) -> None:
    """按 setting 画恢复曲线。"""
    plot_df = (
        metrics.groupby(["round", "setting"], as_index=False)[value_col]
        .mean()
        .pivot(index="round", columns="setting", values=value_col)
        .reset_index()
    )
    plt.figure(figsize=(9, 5))
    for col in plot_df.columns:
        if col != "round":
            plt.plot(plot_df["round"], plot_df[col], marker="o", linewidth=1.8, label=col)
    plt.title(title)
    plt.xlabel("round")
    plt.ylabel(ylabel)
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _timeline_plot(metrics: pd.DataFrame, out: Path) -> None:
    """绘制审计打开、隔离、撤销时间线。"""
    plot_df = metrics.groupby("round", as_index=False).agg(
        audit_openings=("audit_openings", "mean"),
        quarantined_clients=("quarantined_clients", "mean"),
        revoked_clients=("revoked_clients", "mean"),
    )
    plt.figure(figsize=(9, 5))
    for col in ["audit_openings", "quarantined_clients", "revoked_clients"]:
        plt.plot(plot_df["round"], plot_df[col], marker="o", linewidth=1.8, label=col)
    plt.title("Audit, Quarantine, and Revocation Timeline")
    plt.xlabel("round")
    plt.ylabel("count")
    plt.grid(True, linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def _revoked_plot(metrics: pd.DataFrame, out: Path) -> None:
    """绘制不同设置下最终被隔离/撤销的恶意客户端数量。"""
    final_round = metrics["round"].max()
    final_rows = metrics[metrics["round"] == final_round]
    plot_df = final_rows.groupby("setting", as_index=False)["revoked_clients"].mean().sort_values("setting")
    plt.figure(figsize=(9, 5))
    plt.bar(plot_df["setting"], plot_df["revoked_clients"])
    plt.title("Revoked Malicious Clients after Audit")
    plt.ylabel("revoked clients")
    plt.xticks(rotation=20, ha="right")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def write_poisoning_recovery_process_note(dataset: str, mode: str, out: Path) -> Path:
    """写入每个实验七目录的审计隔离恢复过程说明。"""
    note_path = out / "exp07_poisoning_recovery_process_note.md"
    text = f"""# Exp07 Poisoning Audit Recovery Supplement

Dataset: `{dataset}`
Mode: `{mode}`

This supplement does not overwrite the original `poisoning_metrics.csv` or `poisoning_events.csv`.

First experiment finding:

- The first poisoning-audit experiment showed that audit openings can be triggered.
- However, poisoned accuracy remained low, so audit alone is not enough to guarantee recovery.

Problem interpretation:

- LUAF-SM2-FL is not a standalone robust aggregation algorithm.
- Its role is accountable admission control: identify malicious updates, open accountable identity, quarantine the UAV, and block future access via revocation.

What this supplement validates:

- The closed loop from audit opening to quarantine, revocation-list insertion, and recovery.
- Audit-only records accountability but allows malicious updates to keep entering aggregation.
- Audit-quarantine reduces accepted malicious updates after the quarantine round and shrinks the recovery gap to clean training.

Paper writing template:

- LUAF-SM2-FL provides identity accountability and subsequent admission isolation for malicious updates.
- It is complementary to robust aggregation; robust aggregation can be added on top, but the protocol-level contribution is traceability and revocation.
"""
    note_path.write_text(text, encoding="utf-8")
    return note_path


def write_poisoning_recovery_outputs(dataset: str, mode: str, out: Path, seeds: list[int] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """写入实验七审计隔离恢复补充实验的 CSV、图和说明。"""
    out = ensure_dir(out)
    metrics, events, summary = build_poisoning_recovery_outputs(dataset, mode, seeds=seeds)
    write_csv(metrics, out / "poisoning_recovery_metrics.csv")
    write_csv(events, out / "poisoning_recovery_events.csv")
    write_csv(summary, out / "poisoning_recovery_summary.csv")
    _line_plot(metrics, "accuracy", "Accuracy Recovery after Poisoning", "accuracy", out / "plot_accuracy_recovery_curve.png")
    _line_plot(metrics, "f1_weighted", "F1 Recovery after Poisoning", "f1_weighted", out / "plot_f1_recovery_curve.png")
    _timeline_plot(metrics, out / "plot_audit_quarantine_timeline.png")
    _revoked_plot(metrics, out / "plot_revoked_malicious_clients.png")
    write_poisoning_recovery_process_note(dataset, mode, out)
    return metrics, events, summary


def run(data_path: str | None, out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    """实验 7：恶意模型更新与条件审计。"""
    out = ensure_dir(Path(out_dir) / "exp_07_poisoning_audit")
    cfg = SimConfig(seed=seed, num_rounds=4 if quick else 20, num_clients=8 if quick else 30, local_epochs=1 if quick else 2)
    df = load_or_create_dataset(data_path, seed=cfg.seed)
    dataset = prepare_fl_dataset(df, cfg)

    settings = [
        ("Plain-FL-poisoned", "Plain-FL", 0.25),
        ("LUAF-SM2-FL-poisoned", "LUAF-SM2-FL", 0.25),
        ("LUAF-SM2-FL-clean", "LUAF-SM2-FL", 0.0),
    ]
    all_metrics = []
    all_events = []
    for name, scheme, pf in settings:
        res = run_fl_simulation(dataset, cfg, scheme=scheme, attack_mode="poisoning" if pf > 0 else None, poisoning_fraction=pf, dataset_name=Path(data_path).stem if data_path else "synthetic_uav_ids")
        m = res.metrics_by_round.copy()
        m["setting"] = name
        all_metrics.append(m)
        e = res.event_log.copy()
        e["setting"] = name
        all_events.append(e)

    metrics = pd.concat(all_metrics, ignore_index=True)
    events = pd.concat(all_events, ignore_index=True)
    write_csv(metrics, out / "poisoning_metrics.csv")
    write_csv(events, out / "poisoning_events.csv")

    pivot = metrics.pivot(index="round", columns="setting", values="accuracy").reset_index()
    simple_line_plot(pivot, "round", [c for c in pivot.columns if c != "round"], "Global accuracy under malicious updates", "Accuracy", out / "plot_accuracy_poisoning.png")
    pivot2 = metrics.pivot(index="round", columns="setting", values="audit_open_count").reset_index()
    simple_line_plot(pivot2, "round", [c for c in pivot2.columns if c != "round"], "Audit opening count by round", "Audit openings", out / "plot_audit_openings.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=None)
    parser.add_argument("--out", default="results")
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.data, args.out, args.quick, args.seed)


if __name__ == "__main__":
    main()
