from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.config import SimConfig
from src.data_loader import load_or_create_dataset, prepare_fl_dataset
from src.fl_simulator import run_fl_simulation
from src.reproducibility import config_dict, environment_snapshot
from src.utils import ensure_dir, save_json, simple_line_plot, write_csv


def apply_exp01_latency_correction(metrics: pd.DataFrame) -> pd.DataFrame:
    """修正实验一每轮耗时口径，并保留旧 protocol-only round_latency_ms。

    旧版 round_latency_ms 近似等于 protocol_latency_ms，没有包含本地训练和聚合耗时。
    新口径中 round_latency_ms 表示 total_round_latency_ms，便于旧绘图代码和论文表格继续使用。
    """
    corrected = metrics.copy()
    required = {"train_latency_ms", "protocol_latency_ms", "round_latency_ms"}
    missing = sorted(required - set(corrected.columns))
    if missing:
        raise ValueError(f"exp_01 metrics missing required latency columns: {missing}")

    train = pd.to_numeric(corrected["train_latency_ms"], errors="coerce").fillna(0.0)
    protocol = pd.to_numeric(corrected["protocol_latency_ms"], errors="coerce").fillna(0.0)
    if "legacy_protocol_only_round_latency_ms" not in corrected.columns:
        corrected["legacy_protocol_only_round_latency_ms"] = pd.to_numeric(
            corrected["round_latency_ms"], errors="coerce"
        ).fillna(protocol)

    total = train + protocol
    corrected["total_round_latency_ms"] = total
    corrected["round_latency_ms"] = total
    corrected["security_overhead_ratio"] = np.divide(
        protocol,
        total,
        out=np.zeros(len(corrected), dtype=float),
        where=total.to_numpy() != 0,
    )
    return corrected


def plot_train_vs_protocol_latency(metrics: pd.DataFrame, out: Path) -> None:
    """绘制各方案训练耗时与协议耗时的平均堆叠柱状图。"""
    summary = (
        metrics.groupby("scheme", as_index=False)[["train_latency_ms", "protocol_latency_ms"]]
        .mean()
        .sort_values("scheme")
    )
    x = np.arange(len(summary))
    plt.figure(figsize=(9, 5))
    plt.bar(x, summary["train_latency_ms"], label="train_latency_ms")
    plt.bar(x, summary["protocol_latency_ms"], bottom=summary["train_latency_ms"], label="protocol_latency_ms")
    plt.xticks(x, summary["scheme"], rotation=20, ha="right")
    plt.ylabel("Latency (ms)")
    plt.title("Mean Train vs Protocol Latency")
    plt.grid(True, axis="y", linestyle="--", linewidth=0.5, alpha=0.6)
    plt.legend()
    plt.tight_layout()
    ensure_dir(out.parent)
    plt.savefig(out, dpi=200)
    plt.close()


def plot_security_overhead_ratio(metrics: pd.DataFrame, out: Path) -> None:
    """绘制协议耗时占总 round_latency_ms 的比例。"""
    pivot = metrics.pivot(index="round", columns="scheme", values="security_overhead_ratio").reset_index()
    simple_line_plot(
        pivot,
        "round",
        [c for c in pivot.columns if c != "round"],
        "Security Overhead Ratio by Round",
        "protocol_latency_ms / total_round_latency_ms",
        out,
    )


def write_exp01_latency_plots(metrics: pd.DataFrame, out: Path) -> None:
    """写出实验一延迟相关图表。"""
    pivot = metrics.pivot(index="round", columns="scheme", values="round_latency_ms").reset_index()
    simple_line_plot(
        pivot,
        "round",
        [c for c in pivot.columns if c != "round"],
        "FL round_latency_ms by round",
        "round_latency_ms",
        out / "plot_round_latency_ms.png",
    )
    plot_train_vs_protocol_latency(metrics, out / "plot_train_vs_protocol_latency.png")
    plot_security_overhead_ratio(metrics, out / "plot_security_overhead_ratio.png")


def run(data_path: str | None, out_dir: str, quick: bool = False, seed: int = 20260529) -> None:
    """实验 1：FL 基础性能。

    对比 Plain-FL、SM2-FL、DynPID-SM2-FL、LUAF-SM2-FL 的全局模型收敛表现。
    """
    out = ensure_dir(Path(out_dir) / "exp_01_fl_baseline")
    cfg = SimConfig(seed=seed, num_rounds=4 if quick else 20, num_clients=8 if quick else 30, local_epochs=1 if quick else 2)
    df = load_or_create_dataset(data_path, seed=cfg.seed)
    dataset = prepare_fl_dataset(df, cfg)
    dataset_name = Path(data_path).stem if data_path else "synthetic_uav_ids"

    all_metrics = []
    for scheme in ["Plain-FL", "SM2-FL", "DynPID-SM2-FL", "LUAF-SM2-FL"]:
        res = run_fl_simulation(dataset, cfg, scheme=scheme, dataset_name=dataset_name)
        all_metrics.append(res.metrics_by_round)
        write_csv(res.event_log, out / f"events_{scheme}.csv")
        save_json(
            {
                "seed": seed,
                "dataset": dataset_name,
                "scheme": scheme,
                "initial_model_hash": res.initial_model_hash,
                "selected_clients_by_round": res.selected_clients_by_round,
                "malicious_clients_by_round": res.malicious_clients_by_round,
            },
            out / f"selection_evidence_{scheme}.json",
        )

    metrics = pd.concat(all_metrics, ignore_index=True)
    metrics = apply_exp01_latency_correction(metrics)
    write_csv(metrics, out / "fl_baseline_metrics.csv")
    np.save(out / "split_train_indices.npy", dataset.train_indices)
    np.save(out / "split_val_indices.npy", dataset.val_indices)
    np.save(out / "split_test_indices.npy", dataset.test_indices)
    save_json(dataset.client_partition, out / "client_partition.json")
    save_json(
        {
            "seed": seed,
            "dataset": dataset_name,
            "config": config_dict(cfg),
            "split_hash": dataset.split_hash,
            "partition_hash": dataset.partition_hash,
            "feature_names": dataset.feature_names,
            "label_names": dataset.label_names,
            "environment": environment_snapshot(),
            "output_contract": {
                "metrics": "fl_baseline_metrics.csv",
                "events": "events_<scheme>.csv",
                "selection": "selection_evidence_<scheme>.json",
                "split_indices": ["split_train_indices.npy", "split_val_indices.npy", "split_test_indices.npy"],
            },
        },
        out / "config.json",
    )

    # 为每个 scheme 生成指标折线图。
    for metric in ["accuracy", "f1_weighted", "log_loss", "round_latency_ms"]:
        pivot = metrics.pivot(index="round", columns="scheme", values=metric).reset_index()
        simple_line_plot(pivot, "round", [c for c in pivot.columns if c != "round"], f"FL {metric} by round", metric, out / f"plot_{metric}.png")
    write_exp01_latency_plots(metrics, out)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default=None, help="CSV 数据集路径；为空则使用随包 synthetic_uav_ids.csv")
    parser.add_argument("--out", default="results", help="输出目录")
    parser.add_argument("--quick", action="store_true", help="快速运行模式")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.data, args.out, args.quick, seed=args.seed)


if __name__ == "__main__":
    main()
