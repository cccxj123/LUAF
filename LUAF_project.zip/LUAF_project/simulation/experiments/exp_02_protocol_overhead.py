from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from src.config import SimConfig
from src.crypto_sim import message_size_bytes, simulate_protocol_latency
from src.reproducibility import make_rng
from src.utils import bar_plot, box_plot, ensure_dir, write_csv


def run(out_dir: str, trials: int = 300, quick: bool = False, seed: int = 20260529) -> None:
    """实验 2：协议性能开销。"""
    out = ensure_dir(Path(out_dir) / "exp_02_protocol_overhead")
    cfg = SimConfig(seed=seed)
    if quick:
        trials = 80
    rng = make_rng(seed, "protocol_jitter", "exp02")
    schemes = ["Plain-FL", "SM2-FL", "DynPID-SM2-FL", "LUAF-SM2-FL"]
    rows = []
    latency_data = []

    for scheme in schemes:
        totals = []
        for _ in range(trials):
            lat = simulate_protocol_latency(scheme, cfg, rng)
            rows.append({
                "seed": seed,
                "scheme": scheme,
                "m1_gen_ms": lat.m1_gen_ms,
                "verify_ms": lat.verify_ms,
                "nf_lookup_ms": lat.nf_lookup_ms,
                "rl_lookup_ms": lat.rl_lookup_ms,
                "sm2_ake_ms": lat.sm2_ake_ms,
                "encrypt_ms": lat.encrypt_ms,
                "total_ms": lat.total_ms,
                "handshake_bytes": message_size_bytes(scheme, cfg),
            })
            totals.append(lat.total_ms)
        latency_data.append(np.array(totals))

    df = pd.DataFrame(rows)
    write_csv(df, out / "protocol_overhead_raw.csv")
    summary = df.groupby("scheme").agg(avg_total_ms=("total_ms", "mean"), p95_total_ms=("total_ms", lambda x: np.percentile(x, 95)), handshake_bytes=("handshake_bytes", "mean")).reset_index()
    write_csv(summary, out / "protocol_overhead_summary.csv")

    box_plot(latency_data, schemes, "Protocol latency distribution", "Latency (ms)", out / "plot_latency_box.png")
    bar_plot(summary["scheme"].tolist(), summary["handshake_bytes"].tolist(), "Handshake communication overhead", "Bytes", out / "plot_handshake_bytes.png")
    bar_plot(summary["scheme"].tolist(), summary["avg_total_ms"].tolist(), "Average secure access latency", "Latency (ms)", out / "plot_avg_latency.png")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default="results")
    parser.add_argument("--trials", type=int, default=300)
    parser.add_argument("--quick", action="store_true")
    parser.add_argument("--seed", type=int, default=20260529)
    args = parser.parse_args()
    run(args.out, args.trials, args.quick, args.seed)


if __name__ == "__main__":
    main()
