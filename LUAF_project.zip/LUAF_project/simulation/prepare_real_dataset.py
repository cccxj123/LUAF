from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.io_utils import guess_label_column, read_table_robust, safe_filename


PROTECTED_COLUMNS = {"label", "uav_id"}


def _strip_column_names(df: pd.DataFrame) -> pd.DataFrame:
    """清理列名首尾空格和 BOM，避免 Label、 Label、\ufeffLabel 被当成不同列。"""
    cleaned = df.copy()
    new_columns: list[str] = []
    for idx, col in enumerate(cleaned.columns):
        name = str(col).strip().replace("\ufeff", "")
        if not name or name.lower().startswith("unnamed:"):
            name = f"unnamed_{idx}"
        new_columns.append(name)
    cleaned.columns = new_columns
    return cleaned


def _drop_duplicate_columns(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """删除重复列名，只保留第一次出现的列，防止后续清洗时同名列产生歧义。"""
    duplicate_mask = df.columns.duplicated()
    duplicate_columns = [str(col) for col in df.columns[duplicate_mask]]
    if duplicate_columns:
        df = df.loc[:, ~duplicate_mask].copy()
    return df, duplicate_columns


def _column_key(name: str) -> str:
    """把列名转换成小写下划线形式，便于做关键词匹配。"""
    value = str(name).strip().lower().replace("\ufeff", "")
    value = re.sub(r"[^a-z0-9]+", "_", value)
    return re.sub(r"_+", "_", value).strip("_")


def _column_tokens(name: str) -> list[str]:
    """按非字母数字字符切分列名，用于识别 ip、id、mac 等独立字段。"""
    return re.findall(r"[a-z0-9]+", str(name).lower())


def _is_bad_training_column(column: str) -> bool:
    """判断列是否明显不适合作为训练特征。

    这些字段通常是唯一标识、地址或时间戳，会导致模型学习到采集环境/样本顺序，
    而不是学习 UAV 入侵检测本身的流量特征。
    """
    if column in PROTECTED_COLUMNS:
        return False

    key = _column_key(column)
    tokens = _column_tokens(column)
    compact = "".join(tokens)

    # label_id 是目标标签的另一种编码。规范化后已经有 label，因此剩余 label_id 不应作为特征泄漏给模型。
    if key == "label_id":
        return True

    if "flow_id" in key or "flowid" in compact:
        return True

    if "timestamp" in key or "time" in key or "date" in key:
        return True

    if "uuid" in tokens or "uuid" in key:
        return True

    if "mac" in tokens or "mac" in key:
        return True

    if "address" in key or "addr" in tokens:
        return True

    # IP、源/目的 IP 等网络地址字段一般是高基数标识，不作为训练特征。
    if "ip" in tokens or key in {"src_ip", "dst_ip", "source_ip", "destination_ip", "ip_address"}:
        return True

    # 单独的 id、xxx_id、id_xxx 通常是样本或实体标识；label/uav_id 已在前面保护。
    if "id" in tokens or key.endswith("_id") or key.startswith("id_") or key == "id":
        return True

    return False


def _clean_string_series(series: pd.Series) -> pd.Series:
    """把字符串特征中的空字符串、常见空值文本统一视为缺失值。"""
    cleaned = series.astype("string").str.strip()
    lower = cleaned.str.lower()
    empty_like = cleaned.isna() | lower.isin({"", "nan", "none", "null", "na", "n/a"})
    return cleaned.mask(empty_like)


def _can_be_numeric(series: pd.Series) -> tuple[bool, pd.Series]:
    """判断一列是否可以整体作为数值列处理，并返回数值化后的结果。"""
    if pd.api.types.is_bool_dtype(series):
        return True, series.astype(float)

    numeric = pd.to_numeric(series, errors="coerce")
    numeric = numeric.replace([np.inf, -np.inf], np.nan)

    if pd.api.types.is_numeric_dtype(series):
        return True, numeric

    cleaned = _clean_string_series(series)
    non_missing_count = int(cleaned.notna().sum())
    if non_missing_count == 0:
        return True, numeric

    numeric_count = int(numeric.notna().sum())
    return numeric_count == non_missing_count, numeric


def _make_unique_columns(columns: list[str]) -> list[str]:
    """为自动生成的列名追加后缀，避免 one-hot 后出现同名列。"""
    counts: dict[str, int] = {}
    unique_columns: list[str] = []
    for col in columns:
        base = col or "feature"
        count = counts.get(base, 0)
        unique_columns.append(base if count == 0 else f"{base}_{count}")
        counts[base] = count + 1
    return unique_columns


def _fill_numeric_missing(df: pd.DataFrame, feature_columns: list[str]) -> pd.DataFrame:
    """把所有特征列强制转为数值，并用中位数填补缺失；整列缺失则填 0。"""
    filled = df.copy()
    for col in feature_columns:
        values = pd.to_numeric(filled[col], errors="coerce")
        values = values.replace([np.inf, -np.inf], np.nan)
        if values.isna().all():
            fill_value = 0.0
        else:
            median_value = values.median()
            fill_value = 0.0 if pd.isna(median_value) else float(median_value)
        filled[col] = values.fillna(fill_value)
    return filled


def prepare_dataset(
    input_path: str | Path,
    output_path: str | Path,
    label: str | None = None,
    num_uavs: int = 30,
    max_onehot: int = 20,
    report: str | Path | None = None,
) -> dict[str, Any]:
    """把单个真实 UAV 数据集转换为 label + uav_id + 数值特征的标准 CSV。"""
    input_path = Path(input_path)
    output_path = Path(output_path)

    df, source_type, used_encoding = read_table_robust(input_path)
    raw_rows, raw_cols = df.shape
    df = _strip_column_names(df)

    df, duplicate_columns = _drop_duplicate_columns(df)
    dropped_columns: list[str] = list(duplicate_columns)

    label_column = guess_label_column(df, user_label=label)
    if label_column != "label":
        if "label" in df.columns:
            dropped_columns.append("label")
            df = df.drop(columns=["label"])
        df = df.rename(columns={label_column: "label"})

    # 标签作为目标列保留；去掉首尾空白可以避免 "Normal" 和 "Normal " 被视为两类。
    df["label"] = _clean_string_series(df["label"]).fillna("unknown").astype(str)

    if "uav_id" not in df.columns:
        # 原始数据没有 UAV 身份时，循环生成固定数量的 UAV 客户端编号，供联邦学习划分使用。
        df.insert(1, "uav_id", [f"UAV_{idx % num_uavs:03d}" for idx in range(len(df))])
    else:
        df["uav_id"] = _clean_string_series(df["uav_id"]).fillna("UAV_UNKNOWN").astype(str)

    empty_columns = [
        col
        for col in df.columns
        if col not in PROTECTED_COLUMNS and df[col].replace("", np.nan).isna().all()
    ]
    if empty_columns:
        dropped_columns.extend(empty_columns)
        df = df.drop(columns=empty_columns)

    bad_columns = [col for col in df.columns if _is_bad_training_column(str(col))]
    if bad_columns:
        dropped_columns.extend(bad_columns)
        df = df.drop(columns=bad_columns)

    df = df.replace([np.inf, -np.inf], np.nan)

    onehot_columns: list[str] = []
    high_cardinality_columns: list[str] = []
    numeric_feature_frames: list[pd.DataFrame] = [df[["label", "uav_id"]].copy()]

    for col in [c for c in df.columns if c not in PROTECTED_COLUMNS]:
        can_be_numeric, numeric_values = _can_be_numeric(df[col])
        if can_be_numeric:
            numeric_feature_frames.append(pd.DataFrame({col: numeric_values}))
            continue

        cleaned = _clean_string_series(df[col])
        unique_count = int(cleaned.nunique(dropna=True))
        if 0 < unique_count <= max_onehot:
            onehot_columns.append(col)
            prefix = safe_filename(col)
            dummies = pd.get_dummies(cleaned, prefix=prefix, dummy_na=False, dtype=int)
            dummies.columns = _make_unique_columns([safe_filename(name) for name in dummies.columns])
            numeric_feature_frames.append(dummies)
        else:
            high_cardinality_columns.append(col)

    if high_cardinality_columns:
        dropped_columns.extend(high_cardinality_columns)

    normalized = pd.concat(numeric_feature_frames, axis=1)
    normalized, final_duplicate_columns = _drop_duplicate_columns(normalized)
    if final_duplicate_columns:
        dropped_columns.extend(final_duplicate_columns)

    feature_columns = [col for col in normalized.columns if col not in PROTECTED_COLUMNS]
    if not feature_columns:
        raise ValueError("转换后没有可用数值特征，请检查数据列或调整清洗规则。")

    normalized = _fill_numeric_missing(normalized, feature_columns)

    # 固定输出列顺序，便于后续实验代码和人工检查读取。
    normalized = normalized[["label", "uav_id"] + feature_columns]
    output_path.parent.mkdir(parents=True, exist_ok=True)
    normalized.to_csv(output_path, index=False, encoding="utf-8-sig")

    label_distribution = normalized["label"].value_counts(dropna=False).head(30)
    report_data: dict[str, Any] = {
        "input_path": str(input_path),
        "output_path": str(output_path),
        "source_type": source_type,
        "used_encoding": used_encoding,
        "label_column": label_column,
        "raw_rows": int(raw_rows),
        "raw_cols": int(raw_cols),
        "final_rows": int(normalized.shape[0]),
        "final_cols": int(normalized.shape[1]),
        "dropped_columns": [str(col) for col in dropped_columns],
        "onehot_columns": [str(col) for col in onehot_columns],
        "label_distribution_top30": {str(k): int(v) for k, v in label_distribution.items()},
    }

    if report:
        report_path = Path(report)
        report_path.parent.mkdir(parents=True, exist_ok=True)
        if report_path.suffix.lower() == ".csv":
            pd.DataFrame([report_data]).to_csv(report_path, index=False, encoding="utf-8-sig")
        else:
            report_path.write_text(json.dumps(report_data, ensure_ascii=False, indent=2), encoding="utf-8")

    print_conversion_summary(report_data)
    return report_data


def print_conversion_summary(report_data: dict[str, Any]) -> None:
    """打印转换摘要，方便在命令行快速确认编码、标签和清洗结果。"""
    print("=" * 72)
    print("真实 UAV 数据集规范化完成")
    print(f"输入路径: {report_data['input_path']}")
    print(f"输出路径: {report_data['output_path']}")
    print(f"原始行列数: {report_data['raw_rows']} x {report_data['raw_cols']}")
    print(f"最终行列数: {report_data['final_rows']} x {report_data['final_cols']}")
    print(f"使用编码: {report_data['used_encoding']}")
    print(f"标签列: {report_data['label_column']}")
    print(f"删除列({len(report_data['dropped_columns'])}): {report_data['dropped_columns']}")
    print(f"one-hot 列({len(report_data['onehot_columns'])}): {report_data['onehot_columns']}")
    print("标签分布前 30 项:")
    for label, count in report_data["label_distribution_top30"].items():
        print(f"  {label}: {count}")
    print("=" * 72)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="规范化真实 UAV CSV/XLSX 数据集。")
    parser.add_argument("--input", required=True, help="原始 CSV/XLSX 路径")
    parser.add_argument("--output", required=True, help="输出规范化 CSV 路径")
    parser.add_argument("--label", default=None, help="手动指定标签列名称")
    parser.add_argument("--num-uavs", type=int, default=30, help="自动生成 uav_id 时使用的 UAV 数量")
    parser.add_argument("--max-onehot", type=int, default=20, help="低基数字符串字段 one-hot 的最大类别数")
    parser.add_argument("--report", default=None, help="可选：输出转换报告 JSON 或 CSV 路径")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    prepare_dataset(
        input_path=args.input,
        output_path=args.output,
        label=args.label,
        num_uavs=args.num_uavs,
        max_onehot=args.max_onehot,
        report=args.report,
    )


if __name__ == "__main__":
    main()
