from __future__ import annotations

import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from src.state_backend.etcd import EtcdStateBackend


backend = EtcdStateBackend(
    host=os.environ.get("ETCD_HOST", "127.0.0.1"),
    port=int(os.environ.get("ETCD_PORT", "2379")),
)


class Handler(BaseHTTPRequestHandler):
    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/healthz":
            body = json.dumps({"status": "ok", "rl_version": backend.get_revocation_version()}).encode()
            self.send_response(200)
        else:
            body = b'{"error":"not_found"}'
            self.send_response(404)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        return


ThreadingHTTPServer(("0.0.0.0", 8090), Handler).serve_forever()
